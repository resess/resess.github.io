def my_function(param1, param2):
    return param1 + param2
    
    
