import csv
import numpy as np
import argparse
from utility.Utility import Utility
from sklearn.cluster import SpectralClustering


# Global variable used for the utility class
ut = None

def run_clustering(relationship_graph, num_of_clusters, output, normalize, is_directed):
    adjacency_matrix, class_names = transform_graph_to_matrix(normalize, is_directed)

    number_of_clusters = int(num_of_clusters)

    X = np.array(adjacency_matrix)

    kmeans = SpectralClustering(n_clusters=number_of_clusters, affinity='precomputed', assign_labels="cluster_qr").fit(X)
    labels = kmeans.labels_

    decomposition = {}
    hyper_result = []
    for i, label in enumerate(labels):
        hyper_result.append((label, class_names[i]))

    result = ut.decontract_graph(hyper_result)

    with open(output +  "/" + "spectral_clustering_result.rsf", "w") as f:
        writer = csv.writer(f, delimiter=" ")
        for cluster in result:
            writer.writerow(cluster)

    return result


def normalize_relationship_graph(relationship_graph):
    all_weights = []
    copy_dep_graph = []
    for relationship in relationship_graph:
        weight = relationship[2]
        all_weights.append(weight)

    avg = np.average(all_weights)
    sigma = np.std(all_weights)

    for relationship in relationship_graph:
        weight = relationship[2]
        normalized_weight = sigmoid((weight - avg) / sigma)
        copy_dep_graph.append([relationship[0], relationship[1], normalized_weight])

    return copy_dep_graph


def retrieve_relationship_graph(relationship_graph_file):
    relationship_graph = []
    with open(relationship_graph_file, "r") as f:
        reader = csv.reader(f)
        for dep in reader:
            caller = dep[0]
            callee = dep[1]
            weight = float(dep[2])

            relationship_graph.append([caller, callee, weight])
    return relationship_graph

def convert_to_undirected_relationship_graph(relationship_graph):
    relationship_map = {}

    for relationship in relationship_graph:
        caller = relationship[0]
        callee = relationship[1]
        weight = relationship[2]

        node_pair = (caller, callee)
        node_pair_reverse = (callee, caller)

        if (node_pair in relationship_map ):
            relationship_map[node_pair] += weight
        elif (node_pair_reverse in relationship_map):
            relationship_map[node_pair_reverse] += weight
        else:
            relationship_map[node_pair] = weight

    undirected_relationship_graph = []
    for node_pair in relationship_map:
        undirected_relationship_graph.append([node_pair[0], node_pair[1], relationship_map[node_pair]])

    return undirected_relationship_graph


def transform_graph_to_matrix(normalize, is_directed):
    # contains a list of touples: [caller, callee, weight]
    relationship_graph = ut.contract_graph()

    class_names = get_all_unique_file_names(relationship_graph)

    # To ensure that we can create a symmetric adjacency matrix ->
    # convert relationship_graph into an undirected graph
    # please ensure this step occurs for the static graph

    if (is_directed):
        relationship_graph = convert_to_undirected_relationship_graph(relationship_graph)

    if (normalize):
        relationship_graph = normalize_relationship_graph(relationship_graph)

    relationship_map = {}

    for classA in class_names:
        relationship_map[classA] = {}
        for classB in class_names:
            relationship_map[classA][classB] = 0

    for dep in relationship_graph:
        caller = dep[0]
        callee = dep[1]
        weight = float(dep[2])

        # WARNING - please make sure the relationship_graph is undirected
        relationship_map[caller][callee] += weight
        relationship_map[callee][caller] += weight

    adjacency_matrix = []
    for classA in class_names:
        feature = []
        for classB in class_names:
            if classA == classB:
                feature.append(0)
            else:
                feature.append(relationship_map[classA][classB])
        adjacency_matrix.append(feature)


    return adjacency_matrix, class_names


def sigmoid(x):
    return np.exp(-np.logaddexp(0, -x))


def get_all_unique_file_names(relationship_graph):
    class_names = []
    for dep in relationship_graph:
        if dep[0] not in class_names:
            class_names.append(dep[0])
        if dep[1] not in class_names:
            class_names.append(dep[1])

    return class_names


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Consensus-based clustering for Spectral",
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("-g", "--relationship-graph", help="relationship graph", required=True)
    parser.add_argument("-o", "--output", help="Result output destination", required=True)
    parser.add_argument("-n", "--num-of-clusters", type=int, help="Number of clusters to use in spectral clustering", required=True)
    parser.add_argument("-c", "--consensus-groups", help="A file containing the group of entities you wish to lock together during clustering. If this is not provided, then no entities are locked together", default=None)
    parser.add_argument("-r", "--normalize", type=bool, help="Normalize the graph before clustering", default=True)
    parser.add_argument("-d", "--directed", type=bool, help="The relationship graph is a directed graph", default=False)
    args = parser.parse_args()

    relationship_graph_file = args.relationship_graph
    consensus_groups = args.consensus_groups
    output_file_name = args.output
    number_of_clusters = args.num_of_clusters
    normalize = args.normalize
    is_directed = args.directed

    ut = Utility(relationship_graph_file, consensus_groups)

    architecture = run_clustering(relationship_graph_file, number_of_clusters, output_file_name, normalize, is_directed)
