package java.lang;

import java.util.Stack;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.Set;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.lang.reflect.Field;
import java.lang.IllegalAccessException;

public class TaintDroid {

    public int taint;
    public static Map<String, Integer> statementIndexMap = new HashMap<>();
    public static AtomicInteger topStatementIndex = new AtomicInteger(0);

    public static TaintDroid newInstance() {
        return new TaintDroid();
    }

    public static void endTime(String str, long time) {
        long endTime = System.nanoTime();
        long timeDiff = endTime - time;
        System.out.format("MethodTiming: %s: %s%n", str, timeDiff);
    }

    public static void printSourceFound(String src) {
        StackTraceElement ste = Thread.currentThread().getStackTrace()[3];
        System.out.format("TaintDroid: SourceFound: %s->%s(%s), %s%n", ste.getClassName(), ste.getMethodName(), ste.getLineNumber(), src);
    }

    public static void printMethodName(String name) {
        System.out.println("MethodName: " + name);
    }

    public static void printFieldNameGet(String name) {
        StackTraceElement ste = Thread.currentThread().getStackTrace()[4];
        System.out.format("FieldGet: in method %s->%s(%s), FieldGet for %s%n", ste.getClassName(), ste.getMethodName(), ste.getLineNumber(), name);
    }

    public static void printFieldNameSet(String name) {
        StackTraceElement ste = Thread.currentThread().getStackTrace()[4];
        System.out.format("FieldSet: in method %s->%s(%s), FieldSet for %s%n", ste.getClassName(), ste.getMethodName(), ste.getLineNumber(), name);
    }

    public static void printSinkFound(String sink) {
        StackTraceElement ste = Thread.currentThread().getStackTrace()[3];
        System.out.format("TaintDroid: SinkFound: %s->%s(%s), %s%n", ste.getClassName(), ste.getMethodName(), ste.getLineNumber(), sink);
    }


    public static void create(TaintDroid taintDroid, int taintIndex) {
        taintDroid.taint = (1 << taintIndex);
        // StackTraceElement ste = Thread.currentThread().getStackTrace()[3];
        // System.out.format("TaintDroid: CreateTaint: in method %s->%s, %n", ste.getClassName(), ste.getMethodName());
    }

    public static void create(TaintDroid taintDroid, TaintDroid other) {
            taintDroid.taint = taintDroid.taint | other.taint;
            // if (other.taint != 0) {
            //     StackTraceElement ste = Thread.currentThread().getStackTrace()[3];
            //     System.out.format("TaintDroid: in method %s->%s, propagated taint%n", ste.getClassName(), ste.getMethodName());
            // }
    }

    public static void create(TaintDroid taintDroid, TaintDroid left, TaintDroid right) {
            taintDroid.taint = taintDroid.taint | left.taint | right.taint;
            // if (left.taint != 0 || right.taint != 0) {
            //     StackTraceElement ste = Thread.currentThread().getStackTrace()[3];
            //     System.out.format("TaintDroid: in method %s->%s, propagated taint%n", ste.getClassName(), ste.getMethodName());
            // }
    }


    public static void erase(TaintDroid taintDroid) {
        taintDroid.taint = 0;
    }

    public static void copy(TaintDroid first, TaintDroid second) {
            first.taint = second.taint;
    }

    public static void getReturnTaint(TaintDroid taintDroid) {
        TaintDroid retTaint = Thread.returnTaintTaintDroid;
        if (retTaint == null) {
            taintDroid.taint = 0;
        } else {
            taintDroid.taint = retTaint.taint;
            // if (retTaint.taint != 0) {
            //     StackTraceElement ste = Thread.currentThread().getStackTrace()[3];
            //     System.out.format("TaintDroid: in method %s->%s, getReturnTaint%n", ste.getClassName(), ste.getMethodName());
            // }
        }
    }

    public static void dumpTaint(TaintDroid taintDroid) {
        if (taintDroid.taint != 0) {
            System.out.format("DumpTaint: %s%n", taintDroid.taint);
        }
    }

    public static void dumpTaint(TaintDroid taintDroid, Object object) {
        dumpTaint(taintDroid);
        if (object != null) {
            dumpObjectLoop(object);
        }
    }

    public static void dumpTaint(int taintDroid) {
        if (taintDroid != 0) {
            System.out.format("DumpTaint: %s%n", taintDroid);
        }
    }

    public static void dumpTaint(int taintDroid, Object object) {
        dumpTaint(taintDroid);
        if (object != null) {
            dumpObjectLoop(object);
        }
    }


    private static void dumpObjectLoop(Object object) {
        Set<Object> visited = new HashSet<>();
        Stack<Object> stack = new Stack<>();
        Stack<String> accessPath = new Stack<>();
        stack.push(object);
        accessPath.push(object.getClass().getName());
        int counter = -1;
        while(!stack.isEmpty()) {
            Object next = stack.pop();
            String currentPath = accessPath.pop();
            if (next == null) {
                continue;
            }
            try {
                if(visited.contains(next)) {
                    continue;
                }
            } catch (Exception e) {
                continue;
            }
            counter++;
            visited.add(next);
            try {
                // System.out.println("Class-" + counter + ": " + next.getClass().toString());
                for (Field field : next.getClass().getDeclaredFields()) {
                    processField("DeclaredField", stack, counter, next, field, accessPath, currentPath);
                }
                for (Field field : next.getClass().getFields()) {
                    processField("Field", stack, counter, next, field, accessPath, currentPath);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // private static void processField(String type, Stack<Object> stack, int counter, Object next, Field field, Stack<String> accessPath, String currentPath) throws Exception {
    //     // System.out.println("    " + type + ": " + field.toString());
    //     field.setAccessible(true);
    //     if (field.getName().endsWith("_taintdroid")) {
    //         Integer taintDroid = (Integer) field.get(next);
    //         if (taintDroid != 0) {
    //             currentPath = currentPath + "/" + field.getName();
    //             System.out.println("DumpTaint: FieldAccessPath: " + currentPath);
    //             dumpTaint(taintDroid);
    //         }
    //     } else {
    //         // System.out.println("FieldInObject-" + counter +": " + field.toString());
    //         Object value = field.get(next); 
    //         if (value != null) {  
    //             stack.push(value);
    //             // currentPath = currentPath + "/" + value.getClass().getName();
    //             currentPath = value.getClass().getName();
    //             accessPath.push(currentPath);
    //         }
    //     }
    // }

    private static void processField(String type, Stack<Object> stack, int counter, Object next, Field field, Stack<String> accessPath, String currentPath) throws Exception {
        // System.out.println("    " + type + ": " + field.toString());
        field.setAccessible(true);
        if (field.getType().equals(TaintDroid.class)) {
            TaintDroid taintDroid = (TaintDroid) field.get(next);
            if (taintDroid != null && taintDroid.taint != 0) {
                currentPath = currentPath + "/" + field.getName();
                System.out.println("DumpTaint: FieldAccessPath: " + currentPath);
                dumpTaint(taintDroid);
            }
        } else {
            // System.out.println("FieldInObject-" + counter +": " + field.toString());
            Object value = field.get(next); 
            if (value != null) {  
                stack.push(value);
                // currentPath = currentPath + "/" + value.getClass().getName();
                currentPath = value.getClass().getName();
                accessPath.push(currentPath);
            }
        }
    }

    public static int parcelTaint(TaintDroid taintDroid, Object object) {
        int taint = parcelTaint(taintDroid);
        if (object != null) {
            taint |= parcelTaint(object);
        }
        return taint;
    }

    public static int parcelTaint(TaintDroid taintDroid) {
        return taintDroid.taint;
    }

    private static int parcelTaint(Object object) {
        Set<Object> visited = new HashSet<>();
        Stack<Object> stack = new Stack<>();
        Stack<String> accessPath = new Stack<>();
        stack.push(object);
        accessPath.push(object.getClass().getName());
        int counter = -1;
        int taint = 0;
        while(!stack.isEmpty()) {
            Object next = stack.pop();
            String currentPath = accessPath.pop();
            if (next == null) {
                continue;
            }
            try {
                if(visited.contains(next)) {
                    continue;
                }
            } catch (Exception e) {
                continue;
            }
            counter++;
            visited.add(next);
            try {
                // System.out.println("Class-" + counter + ": " + next.getClass().toString());
                for (Field field : next.getClass().getDeclaredFields()) {
                    taint |= parcelTaintField("DeclaredField", stack, counter, next, field, accessPath, currentPath);
                }
                for (Field field : next.getClass().getFields()) {
                    taint |= parcelTaintField("Field", stack, counter, next, field, accessPath, currentPath);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return taint;
    }

    private static int parcelTaintField(String type, Stack<Object> stack, int counter, Object next, Field field, Stack<String> accessPath, String currentPath) throws Exception {
        // System.out.println("    " + type + ": " + field.toString());
        int taint = 0;
        field.setAccessible(true);
        if (field.getType().equals(TaintDroid.class)) {
            TaintDroid taintDroid = (TaintDroid) field.get(next);
            if (taintDroid != null && taintDroid.taint != 0) {
                currentPath = currentPath + "/" + field.getName();
                // System.out.println("DumpTaint: FieldAccessPath: " + currentPath);
                taint |= parcelTaint(taintDroid);
            }
        } else {
            // System.out.println("FieldInObject-" + counter +": " + field.toString());
            Object value = field.get(next); 
            if (value != null) {  
                stack.push(value);
                // currentPath = currentPath + "/" + value.getClass().getName();
                currentPath = value.getClass().getName();
                accessPath.push(currentPath);
            }
        }
        return taint;
    }

}