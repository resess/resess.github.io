package pathtaint;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FileTaint extends TaintAnalysis {
    public static List<String> addFileTaint(String line, String instruction, MethodInfo calledMethodInfo, String[] passedRegs, Map<String, String> taintRegMap, int taintTempReg, String returnTaintReg, TaintTool tool, int signatureRegister, int methodDelta, List<String> taintedClassLines, String className) {
        String toolName = "";
        if (tool.equals(TaintTool.TaintDroid)) {
            toolName = "TaintDroid";
        } else if (tool.equals(TaintTool.PathTaint)) {
            toolName = "PathTaint";
        } else {
            throw new Error("Unsupported tool: " + tool);
        }
         
        List<String> linesToAdd = new ArrayList<>();
        String receiverReg = null;
        String receiverRegTaint = null;
        if (!instruction.contains("static") && !line.contains("{}")) { // has receiver register
            receiverReg = passedRegs[0];
            receiverRegTaint = taintRegMap.get(receiverReg);
        }
        String calledMethodClass = calledMethodInfo.getClassName();
        String calledMethodName = calledMethodInfo.getNameAndDesc();
        List<String> params = calledMethodInfo.getParams();
        if (calledMethodClass.equals("Landroid/content/SharedPreferences$Editor;")) {
            if (calledMethodName.startsWith("put")) {
                if (params.get(1).equals("Ljava/lang/String;")) {
                    System.out.println("Should add taint files to: " + line);
                    if (params.get(2).startsWith("L") || params.get(2).startsWith("[")) {
                        String newLine = "    invoke-static {" + passedRegs[0] + ", " + passedRegs[1] + ", " + receiverRegTaint + ", " + passedRegs[2] + 
                            "}, Landroid/content/SharedPreferences$Editor;->addSharedPrefsTaint(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/"+toolName+";Ljava/lang/Object;)V";
                        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                        linesToAdd = rangedInvoke.first;
                        int newMaxRegs = rangedInvoke.second;
                        return linesToAdd;
                    } else {
                        String newLine = "    invoke-static {" + passedRegs[0] + ", " + passedRegs[1] + ", " + receiverRegTaint + ", " + 
                            "}, Landroid/content/SharedPreferences$Editor;->addSharedPrefsTaint(Landroid/content/SharedPreferences$Editor;Ljava/lang/String;Ljava/lang/String;Ljava/lang/"+toolName+";)V";
                        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                        linesToAdd = rangedInvoke.first;
                        int newMaxRegs = rangedInvoke.second;
                        return linesToAdd;
                    }
                }
            }  
        }
        else if (calledMethodClass.equals("Landroid/content/SharedPreferences;")) {
            if (returnTaintReg != null) {
                if (calledMethodName.equals("getAll")) {
                    // System.out.println("----------------");
                    // System.out.println(line);
                    // System.out.println(passedRegs[0]);
                    // System.out.println(returnTaintReg);
                    String newLine = "    invoke-static {" + passedRegs[0] + ", " + returnTaintReg + 
                        "}, Landroid/content/SharedPreferences;->getSharedPrefsTaintAll(Landroid/content/SharedPreferences;Ljava/lang/"+toolName+";)V";
                    Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                    linesToAdd = rangedInvoke.first;
                    int newMaxRegs = rangedInvoke.second;
                    return linesToAdd;
                } else if (calledMethodName.startsWith("get")) {
                    // System.out.println("----------------");
                    // System.out.println(line);
                    // System.out.println(passedRegs[0]);
                    // System.out.println(returnTaintReg);
                    String newLine = "    invoke-static {" + passedRegs[0] + ", " + passedRegs[1] + ", " + returnTaintReg + 
                        "}, Landroid/content/SharedPreferences;->getSharedPrefsTaint(Landroid/content/SharedPreferences;Ljava/lang/String;Ljava/lang/"+toolName+";)V";
                    Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                    linesToAdd = rangedInvoke.first;
                    int newMaxRegs = rangedInvoke.second;
                    return linesToAdd;
                }
            }
            
        }
        
        if (calledMethodInfo.signature().equals("Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V")) {
            String newLine = "    invoke-static {" + taintRegMap.get(passedRegs[1]) + "}, Ljava/lang/Thread;->setParamTaint1(Ljava/lang/"+toolName+";)V";
            Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd = rangedInvoke.first;
            int newMaxRegs = rangedInvoke.second;
            return linesToAdd;
        } else if (calledMethodInfo.signature().equals("Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V")) {
            String newLine = "    invoke-static {" + taintRegMap.get(passedRegs[0]) + "}, Ljava/lang/Thread;->setParamTaint1(Ljava/lang/"+toolName+";)V";
            Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd = rangedInvoke.first;
            int newMaxRegs = rangedInvoke.second;
            linesToAdd.add("    const v" + taintTempReg + ", " + methodDelta);
            newLine = "    invoke-static {v" + signatureRegister + ",v" + taintTempReg + "}, Ljava/lang/Thread;->setSite(Ljava/lang/String;I)V";
            rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd.addAll(rangedInvoke.first);
            newMaxRegs = (newMaxRegs > rangedInvoke.second)? newMaxRegs : rangedInvoke.second;

            return linesToAdd;
        }

        if (calledMethodInfo.signature().startsWith("Ljava/util/Formatter;-><init>")) {
            String newLine = "    invoke-static {" + taintRegMap.get(passedRegs[1]) + "}, Ljava/lang/Thread;->setParamTaint1(Ljava/lang/"+toolName+";)V";
            Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd = rangedInvoke.first;
            int newMaxRegs = rangedInvoke.second;
            return linesToAdd;
        } else if (calledMethodInfo.signature().startsWith("Ljava/util/Formatter;->format")) {
            String newLine = "    invoke-static {" + taintRegMap.get(passedRegs[0]) + "}, Ljava/lang/Thread;->setParamTaint1(Ljava/lang/"+toolName+";)V";
            Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd = rangedInvoke.first;
            int newMaxRegs = rangedInvoke.second;
            linesToAdd.add("    const v" + taintTempReg + ", " + methodDelta);
            newLine = "    invoke-static {v" + signatureRegister + ",v" + taintTempReg + "}, Ljava/lang/Thread;->setSite(Ljava/lang/String;I)V";
            rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd.addAll(rangedInvoke.first);
            newMaxRegs = (newMaxRegs > rangedInvoke.second)? newMaxRegs : rangedInvoke.second;
            newLine = "    invoke-virtual {" + passedRegs[0] + "}, Ljava/util/Formatter;->addTaint()V";
            rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd.addAll(rangedInvoke.first);
            newMaxRegs = (newMaxRegs > rangedInvoke.second)? newMaxRegs : rangedInvoke.second;

            return linesToAdd;
        }
        
        System.out.println("Inspecting line: " + line);
        if (calledMethodClass.equals("Landroid/content/ContentResolver;")) {
            System.out.println("    Content provider class: " + calledMethodClass);
            if (calledMethodName.startsWith("insert")) {
                System.out.println("    Content provider method: " + calledMethodName);
                for (int i = taintedClassLines.size()-1; i >= 0; i--) {
                    String lineBefore = taintedClassLines.get(i);
                    System.out.println("    Checking line: " + lineBefore);
                    if (lineBefore.contains("getContentResolver()Landroid/content/ContentResolver;")) {
                        String contextParam = TaintAnalysis.parsePassedRegs(lineBefore)[0];
                        System.out.printf("ContextParam: at line %s ---> %s%n", lineBefore, contextParam);
                        linesToAdd.add("    invoke-virtual {" + contextParam + "}, Landroid/content/Context;->getFilesDir()Ljava/io/File;");
                        linesToAdd.add("    move-result-object v" + taintTempReg);
                        
                        String newLine = "    invoke-static {v" + taintTempReg + "," + taintRegMap.get(passedRegs[0]) + "}, Ljava/lang/PathTaint;->addFileTaint(Ljava/io/File;Ljava/lang/PathTaint;)V";
                        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                        linesToAdd.addAll(rangedInvoke.first);
                        int newMaxRegs = rangedInvoke.second;
                        return linesToAdd;
                    } else if (lineBefore.startsWith(".method")) {
                        break;
                    }
                }
            }
        } else if (calledMethodClass.equals("Landroid/database/sqlite/SQLiteQueryBuilder;")) {
            if (calledMethodName.startsWith("query")) {
                System.out.println("    Content provider method: " + calledMethodName);
                for (int i = taintedClassLines.size()-1; i >= 0; i--) {
                    String lineBefore = taintedClassLines.get(i);
                    System.out.println("    Checking line: " + lineBefore);
                    if (lineBefore.contains("move-object/16") && lineBefore.contains(", p0")) {
                        String contextParam = TaintAnalysis.getRegReference(lineBefore, 1);
                        addGetFileTaint(passedRegs, taintRegMap, taintTempReg, linesToAdd, lineBefore, contextParam, className);
                        return linesToAdd;
                    } else if (lineBefore.startsWith(".method")) {
                        break;
                    }
                }
            }
        }
        return linesToAdd;
    }

    private static void addGetFileTaint(String[] passedRegs, Map<String, String> taintRegMap, int taintTempReg,
            List<String> linesToAdd, String lineBefore, String contextParam, String className) {
        System.out.printf("ContextParam: at line %s ---> %s%n", lineBefore, contextParam);
        linesToAdd.add("    invoke-virtual {" + contextParam + "}, " + className + "->getContext()Landroid/content/Context;");
        linesToAdd.add("    move-result-object v" + taintTempReg);
        linesToAdd.add("    invoke-virtual/range {v" + taintTempReg + " .. v" + taintTempReg + "}, Landroid/content/Context;->getFilesDir()Ljava/io/File;");
        linesToAdd.add("    move-result-object v" + taintTempReg);

        String newLine = "    invoke-static {v" + taintTempReg + "," + taintRegMap.get(passedRegs[0]) + "}, Ljava/lang/PathTaint;->getFileTaint(Ljava/io/File;Ljava/lang/PathTaint;)V";
        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        int newMaxRegs = rangedInvoke.second;

        newLine = "    invoke-static {" + taintRegMap.get(passedRegs[0]) + "}, Ljava/lang/Thread;->setReturnTaint(Ljava/lang/PathTaint;)V";
        rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        newMaxRegs = rangedInvoke.second;
    }
}
