package pathtaint;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;


public class TaintSource {
    private static List<String> sources = new ArrayList<>();

    public static void loadSources(String sourceFile) {
        List<String> sourceList;
        try {
            sourceList = Files.readAllLines(Paths.get(sourceFile));
        } catch (IOException e) {
            throw new Error("Cannot open file: " + sourceFile);
        }

        for (String src : sourceList) {
            sources.add(src);
        }
    }

    public static boolean isSource(String signature) {
        return sources.contains(signature);
    }

    public static List<String> getSources() {
        return sources;
    }

    public static int getTaintNum(String signature) {
        return sources.indexOf(signature);
    }
}


