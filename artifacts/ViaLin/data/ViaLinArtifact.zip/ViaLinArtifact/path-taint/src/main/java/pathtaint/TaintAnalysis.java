package pathtaint;

import java.util.ArrayList;
import java.util.List;

class TaintAnalysis {

    public static final int MAX_METHOD_DELTA = 512;

    public void analyze() {
        throw new UnsupportedOperationException("Should override this method");
    }

    public void addTaint() {
        throw new UnsupportedOperationException("Should override this method");
    }

    public static String[] parsePassedRegs(String line) {
        String [] lineSplit = line.split("\\}");
        String [] regSplit = lineSplit[0].split("\\{");
        String [] passedRegs = new String[0];
        if (regSplit.length > 1) {
            passedRegs = regSplit[1].replace(" ", "").split("\\,");
        }

        passedRegs = parsePassedRegs(passedRegs);
        return passedRegs;
    }

    public static String[] parsePassedRegs(String[] passedRegs) {
        if (passedRegs.length > 0) {
            if (passedRegs[0].contains("..")) {
                passedRegs[0] = passedRegs[0].replace("..", "Z");
                String firstReg = passedRegs[0].split("Z")[0];
                String lastReg = passedRegs[0].split("Z")[1];
                int firstRegNum = getRegNumFromRef(firstReg);
                int lastRegNum = getRegNumFromRef(lastReg);
                passedRegs = new String[lastRegNum-firstRegNum+1];
                for (int i = firstRegNum; i <= lastRegNum; i++) {
                    passedRegs[i-firstRegNum] = "v" + i;
                }
            }
        }
        return passedRegs;
    }

    public static Integer addLineNumTaint(Integer taintTempReg, Integer maxRegs, int methodDelta, List<String> linesToAdd,
            String taintTargReg) {
        String newLine;
        Pair<List<String>, Integer> rangedInvoke;
        int newMaxRegs;

        int leastNibble = methodDelta % MAX_METHOD_DELTA;
        if (methodDelta > MAX_METHOD_DELTA) {
            int highHalf = methodDelta & (MAX_METHOD_DELTA-1);
            newLine = "    invoke-static {" + taintTargReg + "}, Ljava/lang/PathTaint;->setSite" + highHalf + "(Ljava/lang/PathTaint;)V";
            rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd.addAll(rangedInvoke.first);
            newMaxRegs = rangedInvoke.second;
            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;

            newLine = "    invoke-static {" + taintTargReg + "}, Ljava/lang/PathTaint;->shiftSite(Ljava/lang/PathTaint;)V";
            rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd.addAll(rangedInvoke.first);
            newMaxRegs = rangedInvoke.second;
            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
            int maxVal = (((MAX_METHOD_DELTA-1)*MAX_METHOD_DELTA) + MAX_METHOD_DELTA);
            if (methodDelta > maxVal) {
                throw new Error(String.format("delta %s higher than MAX_METHOD_DELTA %s", leastNibble, MAX_METHOD_DELTA));
            }
        }
        
        newLine = "    invoke-static {" + taintTargReg + "}, Ljava/lang/PathTaint;->setSite" + leastNibble + "(Ljava/lang/PathTaint;)V";
        rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;


        return maxRegs;
    }


    protected static Pair<List<String>, Integer> makeInvokeToRange(String line, int taintTempReg) {
        taintTempReg = taintTempReg +1;
        List<String> lines = new ArrayList<>();
        int maxRegs = 0;
        String calledMethod = "L"+line.split(", L", 2)[1];
        String instruction = getToken(line, 0);

        MethodInfo calledMethodInfo = new MethodInfo(calledMethod, instruction.contains("static"));
        String [] lineSplit = line.split("\\}");

        String [] regSplit = lineSplit[0].split("\\{");
        String [] passedRegs = new String[0];
        if (regSplit.length < 2) {
            lines.add(line);
            return new Pair<List<String>, Integer>(lines, 0);
        }

        passedRegs = regSplit[1].replace(" ", "").split("\\,");
        
        if (passedRegs[0].contains("..")) {
            lines.add(line);
            return new Pair<List<String>, Integer>(lines, 0);
        }

        StringBuilder sb = new StringBuilder();
        sb.append("    ");

        if (passedRegs.length == 0){
            sb.append(instruction);
            sb.append(" {");
        } else if(passedRegs.length == 1 && getRegNumFromRef(passedRegs[0]) < 8) {
            sb.append(instruction);
            sb.append(" {");
            sb.append(passedRegs[0]);
        } else if(passedRegs.length == 2 && getRegNumFromRef(passedRegs[0]) < 8 && getRegNumFromRef(passedRegs[1]) < 8) {
            sb.append(instruction);
            sb.append(" {");
            sb.append(passedRegs[0]);
            sb.append(", ");
            sb.append(passedRegs[1]);
        } else if(passedRegs.length == 3 && getRegNumFromRef(passedRegs[0]) < 8 && getRegNumFromRef(passedRegs[1]) < 8 && getRegNumFromRef(passedRegs[2]) < 8) {
            sb.append(instruction);
            sb.append(" {");
            sb.append(passedRegs[0]);
            sb.append(", ");
            sb.append(passedRegs[1]);
            sb.append(", ");
            sb.append(passedRegs[2]);
        } else if(passedRegs.length == 4 && getRegNumFromRef(passedRegs[0]) < 8 && getRegNumFromRef(passedRegs[1]) < 8 && getRegNumFromRef(passedRegs[2]) < 8 && getRegNumFromRef(passedRegs[3]) < 8) {
            sb.append(instruction);
            sb.append(" {");
            sb.append(passedRegs[0]);
            sb.append(", ");
            sb.append(passedRegs[1]);
            sb.append(", ");
            sb.append(passedRegs[2]);
            sb.append(", ");
            sb.append(passedRegs[3]);
        } else {  // if (passedRegs.length > 2) {
            if (!instruction.contains("range")) {
                instruction = instruction + "/range";
            }

            sb.append(instruction);
            sb.append(" {");

            for (int i = 0; i < passedRegs.length; i++) {
                String mod = "";
                if (taintTempReg+i+2 > 15) {
                    mod = "/16";
                }

                String param = calledMethodInfo.getParams().get(i);
                String moveInstruction = "move-object";
                if (param.equals("Z") || param.equals("C") || param.equals("B") || param.equals("S") || param.equals("I") || param.equals("F")) {
                    moveInstruction = "move";
                } else if (param.equals("J") || param.equals("D")) {
                    moveInstruction = "move-wide";
                } else if (param.equals("*")) {
                    moveInstruction = null;
                }

                if (moveInstruction != null) {
                    String move = "    " + moveInstruction + mod + " v" + String.valueOf(taintTempReg+i+2) + ", " + passedRegs[i];
                    lines.add(move);
                }
            }

            maxRegs = taintTempReg + 2 + passedRegs.length;
            sb.append("v"+String.valueOf(taintTempReg+2));
            sb.append(" .. ");
            sb.append("v"+String.valueOf(taintTempReg + 1 + passedRegs.length));
        }

        sb.append("}");
        sb.append(lineSplit[1]);
        lines.add(sb.toString());

        return new Pair<List<String>, Integer>(lines, maxRegs);
    }

    protected static String getLastToken(String line) {
        String[] split = line.split("\\s+");
        return split[split.length-1];
    }

    protected static String getToken(String line, int n) {
        String[] split = line.trim().split("\\s+");
        return split[n];
    }

    protected static String replaceToken(String line, String token, int n) {
        String[] split = line.trim().split("\\s+");
        if (n < 0) {
            n = n + split.length;
        }
        split[n] = token;
        StringBuilder newLine = new StringBuilder(split[0]);
        for (int i = 1; i < split.length; i++) {
            newLine.append(' ');
            newLine.append(split[i]);
        }
        return newLine.toString();
    }

    protected static MethodInfo getMethodInfo(String className, String line) {
        String methodName = className + "->" + getLastToken(line);
        boolean isStatic = line.contains(" static ");
        MethodInfo methodInfo = new MethodInfo(methodName, isStatic);
        return methodInfo;
    }

    protected static String getRegReference(String line, int n) {
        return getToken(line, n).replace(",", "");
    }

    protected static String getRegTypeFromRef(String regRef) {
        return regRef.substring(0, 1);
    }

    protected static int getRegNumFromRef(String regRef) {
        return Integer.parseInt(regRef.substring(1));
    }


    protected static int getRegNum(MethodInfo methodInfo, String line, int n, String regType) {
        int regNum = Integer.parseInt(getRegReference(line, n).substring(1));
        if (regType.equals("p")) {
            regNum += methodInfo.getNumBaseParams();
        }
        return regNum;
    }

    protected static String getRegType(String line, int n) {
        return getRegReference(line, n).substring(0, 1);
    }


    protected boolean isNop(String instruction) {
        return instruction.equals("nop");
    }

    protected boolean isMove(String instruction) {
        return instruction.equals("move");
    }

    protected boolean isMoveFrom16(String instruction) {
        return instruction.equals("move/from16");
    }

    protected boolean isMove16(String instruction) {
        return instruction.equals("move/16");
    }

    protected boolean isMoveWide(String instruction) {
        return instruction.equals("move-wide");
    }

    protected boolean isMoveWideFrom16(String instruction) {
        return instruction.equals("move-wide/from16");
    }

    protected boolean isMoveWide16(String instruction) {
        return instruction.equals("move-wide/16");
    }

    protected boolean isMoveObject(String instruction) {
        return instruction.equals("move-object");
    }

    protected boolean isMoveObjectFrom16(String instruction) {
        return instruction.equals("move-object/from16");
    }

    protected boolean isMoveObject16(String instruction) {
        return instruction.equals("move-object/16");
    }

    protected boolean isMoveResult(String instruction) {
        return instruction.equals("move-result");
    }

    protected boolean isMoveResultWide(String instruction) {
        return instruction.equals("move-result-wide");
    }

    protected boolean isMoveResultObject(String instruction) {
        return instruction.equals("move-result-object");
    }

    protected boolean isMoveException(String instruction) {
        return instruction.equals("move-exception");
    }

    protected boolean isReturnVoid(String instruction) {
        return instruction.equals("return-void");
    }

    protected boolean isReturn(String instruction) {
        return instruction.equals("return");
    }

    protected boolean isReturnWide(String instruction) {
        return instruction.equals("return-wide");
    }

    protected boolean isReturnObject(String instruction) {
        return instruction.equals("return-object");
    }

    protected boolean isConst4(String instruction) {
        return instruction.equals("const/4");
    }

    protected boolean isConst16(String instruction) {
        return instruction.equals("const/16");
    }

    protected boolean isConst(String instruction) {
        return instruction.equals("const");
    }

    protected boolean isConstHigh16(String instruction) {
        return instruction.equals("const/high16");
    }

    protected boolean isConstWide16(String instruction) {
        return instruction.equals("const-wide/16");
    }

    protected boolean isConstWide32(String instruction) {
        return instruction.equals("const-wide/32");
    }

    protected boolean isConstWide(String instruction) {
        return instruction.equals("const-wide");
    }

    protected boolean isConstWideHigh16(String instruction) {
        return instruction.equals("const-wide/high16");
    }

    protected boolean isConstString(String instruction) {
        return instruction.equals("const-string");
    }

    protected boolean isConstStringJumbo(String instruction) {
        return instruction.equals("const-string/jumbo");
    }

    protected boolean isConstClass(String instruction) {
        return instruction.equals("const-class");
    }

    protected boolean isMonitorEnter(String instruction) {
        return instruction.equals("monitor-enter");
    }

    protected boolean isMonitorExit(String instruction) {
        return instruction.equals("monitor-exit");
    }

    protected boolean isCheckCast(String instruction) {
        return instruction.equals("check-cast");
    }

    protected boolean isInstanceOf(String instruction) {
        return instruction.equals("instance-of");
    }

    protected boolean isArrayLength(String instruction) {
        return instruction.equals("array-length");
    }

    protected boolean isNewInstance(String instruction) {
        return instruction.equals("new-instance");
    }

    protected boolean isNewArray(String instruction) {
        return instruction.equals("new-array");
    }

    protected boolean isFilledNewArray(String instruction) {
        return instruction.equals("filled-new-array");
    }

    protected boolean isFilledNewArrayRange(String instruction) {
        return instruction.equals("filled-new-array/range");
    }

    protected boolean isFillArrayData(String instruction) {
        return instruction.equals("fill-array-data");
    }

    protected boolean isThrow(String instruction) {
        return instruction.equals("throw");
    }

    protected boolean isGoto(String instruction) {
        return instruction.equals("goto");
    }

    protected boolean isGoto16(String instruction) {
        return instruction.equals("goto/16");
    }

    protected boolean isGoto32(String instruction) {
        return instruction.equals("goto/32");
    }

    protected boolean isPackedSwitch(String instruction) {
        return instruction.equals("packed-switch");
    }

    protected boolean isSparseSwitch(String instruction) {
        return instruction.equals("sparse-switch");
    }

    protected boolean isCmpkind(String instruction) {
        if(instruction.equals("cmpl-float")) {
            return true;
        }
        if(instruction.equals("cmpg-float")) {
            return true;
        }
        if(instruction.equals("cmpl-double")) {
            return true;
        }
        if(instruction.equals("cmpg-double")) {
            return true;
        }
        if(instruction.equals("cmp-long")) {
            return true;
        }
        return false;
    }

    protected boolean isIfTest(String instruction) {
        if (instruction.equals("if-eq")) {
            return true;
        }
        if (instruction.equals("if-ne")) {
            return true;
        }
        if (instruction.equals("if-lt")) {
            return true;
        }
        if (instruction.equals("if-ge")) {
            return true;
        }
        if (instruction.equals("if-gt")) {
            return true;
        }
        if (instruction.equals("if-le")) {
            return true;
        }
        return false;
    }

    protected boolean isIfTestz(String instruction) {
        if (instruction.equals("if-eqz")) {
            return true;
        }
        if (instruction.equals("if-nez")) {
            return true;
        }
        if (instruction.equals("if-ltz")) {
            return true;
        }
        if (instruction.equals("if-gez")) {
            return true;
        }
        if (instruction.equals("if-gtz")) {
            return true;
        }
        if (instruction.equals("if-lez")) {
            return true;
        }
        return false;
    }

    protected boolean isArrayOp(String instruction) {
        if(instruction.equals("aget")) {
            return true;
        }
        if(instruction.equals("aget-wide")) {
            return true;
        }
        if(instruction.equals("aget-object")) {
            return true;
        }
        if(instruction.equals("aget-boolean")) {
            return true;
        }
        if(instruction.equals("aget-byte")) {
            return true;
        }
        if(instruction.equals("aget-char")) {
            return true;
        }
        if(instruction.equals("aget-short")) {
            return true;
        }
        if(instruction.equals("aput")) {
            return true;
        }
        if(instruction.equals("aput-wide")) {
            return true;
        }
        if(instruction.equals("aput-object")) {
            return true;
        }
        if(instruction.equals("aput-boolean")) {
            return true;
        }
        if(instruction.equals("aput-byte")) {
            return true;
        }
        if(instruction.equals("aput-char")) {
            return true;
        }
        if(instruction.equals("aput-short")) {
            return true;
        }
        return false;
    }

    protected boolean isIinstanceOp(String instruction) {
        if(instruction.equals("iget")) {
            return true;
        }
        if(instruction.equals("iget-wide")) {
            return true;
        }
        if(instruction.equals("iget-object")) {
            return true;
        }
        if(instruction.equals("iget-boolean")) {
            return true;
        }
        if(instruction.equals("iget-byte")) {
            return true;
        }
        if(instruction.equals("iget-char")) {
            return true;
        }
        if(instruction.equals("iget-short")) {
            return true;
        }
        if(instruction.equals("iput")) {
            return true;
        }
        if(instruction.equals("iput-wide")) {
            return true;
        }
        if(instruction.equals("iput-object")) {
            return true;
        }
        if(instruction.equals("iput-boolean")) {
            return true;
        }
        if(instruction.equals("iput-byte")) {
            return true;
        }
        if(instruction.equals("iput-char")) {
            return true;
        }
        if(instruction.equals("iput-short")) {
            return true;
        }
        return false;
    }

    protected boolean isSstaticOp(String instruction) {
        if(instruction.equals("sget")) {
            return true;
        }
        if(instruction.equals("sget-wide")) {
            return true;
        }
        if(instruction.equals("sget-object")) {
            return true;
        }
        if(instruction.equals("sget-boolean")) {
            return true;
        }
        if(instruction.equals("sget-byte")) {
            return true;
        }
        if(instruction.equals("sget-char")) {
            return true;
        }
        if(instruction.equals("sget-short")) {
            return true;
        }
        if(instruction.equals("sput")) {
            return true;
        }
        if(instruction.equals("sput-wide")) {
            return true;
        }
        if(instruction.equals("sput-object")) {
            return true;
        }
        if(instruction.equals("sput-boolean")) {
            return true;
        }
        if(instruction.equals("sput-byte")) {
            return true;
        }
        if(instruction.equals("sput-char")) {
            return true;
        }
        if(instruction.equals("sput-short")) {
            return true;
        }
        return false;
    }


    protected boolean isInvokeKind(String instruction) {
        if(instruction.equals("invoke-virtual")) {
            return true;
        }
        if(instruction.equals("invoke-super")) {
            return true;
        }
        if(instruction.equals("invoke-direct")) {
            return true;
        }
        if(instruction.equals("invoke-static")) {
            return true;
        }
        if(instruction.equals("invoke-interface")) {
            return true;
        }
        return false;
    }

    protected boolean isInvokeKindRange(String instruction) {
        if(instruction.equals("invoke-virtual/range")) {
            return true;
        }
        if(instruction.equals("invoke-super/range")) {
            return true;
        }
        if(instruction.equals("invoke-direct/range")) {
            return true;
        }
        if(instruction.equals("invoke-static/range")) {
            return true;
        }
        if(instruction.equals("invoke-interface/range")) {
            return true;
        }
        return false;
    }

    protected boolean isUnOp(String instruction) {
        if (instruction.equals("neg-int")) {
            return true;
        }
        if (instruction.equals("not-int")) {
            return true;
        }
        if (instruction.equals("neg-long")) {
            return true;
        }
        if (instruction.equals("not-long")) {
            return true;
        }
        if (instruction.equals("neg-float")) {
            return true;
        }
        if (instruction.equals("neg-double")) {
            return true;
        }
        if (instruction.equals("int-to-long")) {
            return true;
        }
        if (instruction.equals("int-to-float")) {
            return true;
        }
        if (instruction.equals("int-to-double")) {
            return true;
        }
        if (instruction.equals("long-to-int")) {
            return true;
        }
        if (instruction.equals("long-to-float")) {
            return true;
        }
        if (instruction.equals("long-to-double")) {
            return true;
        }
        if (instruction.equals("float-to-int")) {
            return true;
        }
        if (instruction.equals("float-to-long")) {
            return true;
        }
        if (instruction.equals("float-to-double")) {
            return true;
        }
        if (instruction.equals("double-to-int")) {
            return true;
        }
        if (instruction.equals("double-to-long")) {
            return true;
        }
        if (instruction.equals("double-to-float")) {
            return true;
        }
        if (instruction.equals("int-to-byte")) {
            return true;
        }
        if (instruction.equals("int-to-char")) {
            return true;
        }
        if (instruction.equals("int-to-short")) {
            return true;
        }
        return false;
    }


    protected boolean isBinOp(String instruction) {
        if(instruction.equals("add-int")) {
            return true;
        }
        if(instruction.equals("sub-int")) {
            return true;
        }
        if(instruction.equals("mul-int")) {
            return true;
        }
        if(instruction.equals("div-int")) {
            return true;
        }
        if(instruction.equals("rem-int")) {
            return true;
        }
        if(instruction.equals("and-int")) {
            return true;
        }
        if(instruction.equals("or-int")) {
            return true;
        }
        if(instruction.equals("xor-int")) {
            return true;
        }
        if(instruction.equals("shl-int")) {
            return true;
        }
        if(instruction.equals("shr-int")) {
            return true;
        }
        if(instruction.equals("ushr-int")) {
            return true;
        }
        if(instruction.equals("add-long")) {
            return true;
        }
        if(instruction.equals("sub-long")) {
            return true;
        }
        if(instruction.equals("mul-long")) {
            return true;
        }
        if(instruction.equals("div-long")) {
            return true;
        }
        if(instruction.equals("rem-long")) {
            return true;
        }
        if(instruction.equals("and-long")) {
            return true;
        }
        if(instruction.equals("or-long")) {
            return true;
        }
        if(instruction.equals("xor-long")) {
            return true;
        }
        if(instruction.equals("shl-long")) {
            return true;
        }
        if(instruction.equals("shr-long")) {
            return true;
        }
        if(instruction.equals("ushr-long")) {
            return true;
        }
        if(instruction.equals("add-float")) {
            return true;
        }
        if(instruction.equals("sub-float")) {
            return true;
        }
        if(instruction.equals("mul-float")) {
            return true;
        }
        if(instruction.equals("div-float")) {
            return true;
        }
        if(instruction.equals("rem-float")) {
            return true;
        }
        if(instruction.equals("add-double")) {
            return true;
        }
        if(instruction.equals("sub-double")) {
            return true;
        }
        if(instruction.equals("mul-double")) {
            return true;
        }
        if(instruction.equals("div-double")) {
            return true;
        }
        if(instruction.equals("rem-double")) {
            return true;
        }
        return false;
    }

    protected boolean isBinOp2addr(String instruction) {
        if(instruction.equals("add-int/2addr")) {
            return true;
        }
        if(instruction.equals("sub-int/2addr")) {
            return true;
        }
        if(instruction.equals("mul-int/2addr")) {
            return true;
        }
        if(instruction.equals("div-int/2addr")) {
            return true;
        }
        if(instruction.equals("rem-int/2addr")) {
            return true;
        }
        if(instruction.equals("and-int/2addr")) {
            return true;
        }
        if(instruction.equals("or-int/2addr")) {
            return true;
        }
        if(instruction.equals("xor-int/2addr")) {
            return true;
        }
        if(instruction.equals("shl-int/2addr")) {
            return true;
        }
        if(instruction.equals("shr-int/2addr")) {
            return true;
        }
        if(instruction.equals("ushr-int/2addr")) {
            return true;
        }
        if(instruction.equals("add-long/2addr")) {
            return true;
        }
        if(instruction.equals("sub-long/2addr")) {
            return true;
        }
        if(instruction.equals("mul-long/2addr")) {
            return true;
        }
        if(instruction.equals("div-long/2addr")) {
            return true;
        }
        if(instruction.equals("rem-long/2addr")) {
            return true;
        }
        if(instruction.equals("and-long/2addr")) {
            return true;
        }
        if(instruction.equals("or-long/2addr")) {
            return true;
        }
        if(instruction.equals("xor-long/2addr")) {
            return true;
        }
        if(instruction.equals("shl-long/2addr")) {
            return true;
        }
        if(instruction.equals("shr-long/2addr")) {
            return true;
        }
        if(instruction.equals("ushr-long/2addr")) {
            return true;
        }
        if(instruction.equals("add-float/2addr")) {
            return true;
        }
        if(instruction.equals("sub-float/2addr")) {
            return true;
        }
        if(instruction.equals("mul-float/2addr")) {
            return true;
        }
        if(instruction.equals("div-float/2addr")) {
            return true;
        }
        if(instruction.equals("rem-float/2addr")) {
            return true;
        }
        if(instruction.equals("add-double/2addr")) {
            return true;
        }
        if(instruction.equals("sub-double/2addr")) {
            return true;
        }
        if(instruction.equals("mul-double/2addr")) {
            return true;
        }
        if(instruction.equals("div-double/2addr")) {
            return true;
        }
        if(instruction.equals("rem-double/2addr")) {
            return true;
        }
        return false;
    }

    protected boolean isBinOpLit16(String instruction) {
        if(instruction.equals("add-int/lit16")) {
            return true;
        }
        if(instruction.equals("rsub-int")) {
            return true;
        }
        if(instruction.equals("mul-int/lit16")) {
            return true;
        }
        if(instruction.equals("div-int/lit16")) {
            return true;
        }
        if(instruction.equals("rem-int/lit16")) {
            return true;
        }
        if(instruction.equals("and-int/lit16")) {
            return true;
        }
        if(instruction.equals("or-int/lit16")) {
            return true;
        }
        if(instruction.equals("xor-int/lit16")) {
            return true;
        }
        return false;
    }

    protected boolean isBinOpLit8(String instruction) {
        if(instruction.equals("add-int/lit8")) {
            return true;
        }
        if(instruction.equals("rsub-int/lit8")) {
            return true;
        }
        if(instruction.equals("mul-int/lit8")) {
            return true;
        }
        if(instruction.equals("div-int/lit8")) {
            return true;
        }
        if(instruction.equals("rem-int/lit8")) {
            return true;
        }
        if(instruction.equals("and-int/lit8")) {
            return true;
        }
        if(instruction.equals("or-int/lit8")) {
            return true;
        }
        if(instruction.equals("xor-int/lit8")) {
            return true;
        }
        if(instruction.equals("shl-int/lit8")) {
            return true;
        }
        if(instruction.equals("shr-int/lit8")) {
            return true;
        }
        if(instruction.equals("ushr-int/lit8")) {
            return true;
        }
        return false;
    }

    protected boolean isInvokePolymorphic(String instruction) {
        return instruction.equals("invoke-polymorphic");
    }

    protected boolean isInvokePolymorphicRange(String instruction) {
        return instruction.equals("invoke-polymorphic/range");
    }

    protected boolean isInvokeCustom(String instruction) {
        return instruction.equals("invoke-custom");
    }

    protected boolean isInvokeCustomRange(String instruction) {
        return instruction.equals("invoke-custom/range");
    }

    protected boolean isConstMethodHandle(String instruction) {
        return instruction.equals("const-method-handle");
    }

    protected boolean isConstMethodType(String instruction) {
        return instruction.equals("const-method-type");
    }


    protected List<String> unOpRegTypes(String instruction) {
        List<String> types = new ArrayList<>();
        if (instruction.equals("neg-int")) {
            types.add("I");
            types.add("I");
            return types;
        }
        if (instruction.equals("not-int")) {
            types.add("I");
            types.add("I");
            return types;
        }
        if (instruction.equals("neg-long")) {
            types.add("J");
            types.add("J");
            return types;
        }
        if (instruction.equals("not-long")) {
            types.add("J");
            types.add("J");
            return types;
        }
        if (instruction.equals("neg-float")) {
            types.add("F");
            types.add("F");
            return types;
        }
        if (instruction.equals("neg-double")) {
            types.add("D");
            types.add("D");
            return types;
        }
        if (instruction.equals("int-to-long")) {
            types.add("I");
            types.add("J");
            return types;
        }
        if (instruction.equals("int-to-float")) {
            types.add("I");
            types.add("F");
            return types;
        }
        if (instruction.equals("int-to-double")) {
            types.add("I");
            types.add("D");
            return types;
        }
        if (instruction.equals("long-to-int")) {
            types.add("J");
            types.add("I");
            return types;
        }
        if (instruction.equals("long-to-float")) {
            types.add("J");
            types.add("F");
            return types;
        }
        if (instruction.equals("long-to-double")) {
            types.add("J");
            types.add("D");
            return types;
        }
        if (instruction.equals("float-to-int")) {
            types.add("F");
            types.add("I");
            return types;
        }
        if (instruction.equals("float-to-long")) {
            types.add("F");
            types.add("J");
            return types;
        }
        if (instruction.equals("float-to-double")) {
            types.add("F");
            types.add("D");
            return types;
        }
        if (instruction.equals("double-to-int")) {
            types.add("D");
            types.add("I");
            return types;
        }
        if (instruction.equals("double-to-long")) {
            types.add("D");
            types.add("J");
            return types;
        }
        if (instruction.equals("double-to-float")) {
            types.add("D");
            types.add("F");
            return types;
        }
        if (instruction.equals("int-to-byte")) {
            types.add("I");
            types.add("B");
            return types;
        }
        if (instruction.equals("int-to-char")) {
            types.add("I");
            types.add("C");
            return types;
        }
        if (instruction.equals("int-to-short")) {
            types.add("I");
            types.add("S");
            return types;
        }
        throw new Error("Not an unop");
    }

    public boolean targetIsWide(String instruction) {
        return instruction.contains("-wide") || instruction.contains("-long") || instruction.contains("-double");
    }

    public String getOppositeConditional(String instruction) {
        
        if (instruction.equals("if-eq")) {
            return "if-ne";
        }
        if (instruction.equals("if-ne")) {
            return "if-eq";
        }
        if (instruction.equals("if-lt")) {
            return "if-ge";
        }
        if (instruction.equals("if-ge")) {
            return "if-lt";
        }
        if (instruction.equals("if-gt")) {
            return "if-le";
        }
        if (instruction.equals("if-le")) {
            return "if-gt";
        }

        if (instruction.equals("if-eqz")) {
            return "if-nez";
        }
        if (instruction.equals("if-nez")) {
            return "if-eqz";
        }
        if (instruction.equals("if-ltz")) {
            return "if-gez";
        }
        if (instruction.equals("if-gez")) {
            return "if-ltz";
        }
        if (instruction.equals("if-gtz")) {
            return "if-lez";
        }
        if (instruction.equals("if-lez")) {
            return "if-gtz";
        }
        throw new Error("Not a conditional");
    }

    public int getSizeBit(String instruction) {
        int num16Bits = 0;
        if (isNop(instruction)) {
            num16Bits = 1;
        } else if (isMove(instruction) || isMoveWide(instruction) || isMoveObject(instruction) ) {
            num16Bits = 1;
        } else if (isMoveFrom16(instruction) || isMoveWideFrom16(instruction) || isMoveObjectFrom16(instruction)) {
            num16Bits = 2;
        } else if (isMove16(instruction) || isMoveWide16(instruction) || isMoveObject16(instruction)) {
            num16Bits = 3;
        } else if (isMoveResult(instruction) || isMoveResultWide(instruction) || isMoveResultObject(instruction)) {
            num16Bits = 1;
        } else if (isMoveException(instruction)) {
            num16Bits = 1;
        } else if (isReturnVoid(instruction)) {
            num16Bits = 1;
        } else if (isReturn(instruction) || isReturnWide(instruction) || isReturnObject(instruction)) {
            num16Bits = 1;
        } else if (isConst4(instruction)) {
            num16Bits = 1;
        } else if (isConst16(instruction) || isConstHigh16(instruction) || isConstWide16(instruction) || isConstWideHigh16(instruction)
                || isConstString(instruction) || isConstClass(instruction)) {
            num16Bits = 2;
        } else if (isConst(instruction) || isConstWide32(instruction) || isConstStringJumbo(instruction)) {
            num16Bits = 3;
        } else if (isConstWide(instruction)) {
            num16Bits = 5;
        } else if (isMonitorEnter(instruction) || isMonitorExit(instruction)) {
            num16Bits = 1;
        } else if (isCheckCast(instruction)) {
            num16Bits = 2;
        } else if (isInstanceOf(instruction)) {
            num16Bits = 2;
        } else if (isArrayLength(instruction)) {
            num16Bits = 1;
        } else if (isNewInstance(instruction) || isNewArray(instruction)) {
            num16Bits = 2;
        } else if (isFilledNewArray(instruction) || isFilledNewArrayRange(instruction) || isFillArrayData(instruction)) {
            num16Bits = 3;
        } else if (isThrow(instruction)) {
            num16Bits = 1;
        } else if (isGoto(instruction)) {
            num16Bits = 1;
        } else if (isGoto16(instruction)) {
            num16Bits = 2;
        } else if (isGoto32(instruction)) {
            num16Bits = 3;
        } else if (isPackedSwitch(instruction) || isSparseSwitch(instruction)) {
            num16Bits = 3;
        } else if (isCmpkind(instruction)) {
            num16Bits = 2;
        } else if (isIfTest(instruction) || isIfTestz(instruction)) {
            num16Bits = 2;
        } else if (isArrayOp(instruction)) {
            num16Bits = 2;
        } else if (isIinstanceOp(instruction)) {
            num16Bits = 2;
        } else if (isSstaticOp(instruction)) {
            num16Bits = 2;
        } else if (isInvokeKind(instruction) || isInvokeKindRange(instruction) ||  
            isInvokeCustom(instruction) || isInvokeCustomRange(instruction)) {
            num16Bits = 3;
        } else if (isInvokePolymorphic(instruction) || isInvokePolymorphicRange(instruction)) {
            num16Bits = 4;
        } else if (isUnOp(instruction)) {
            num16Bits = 1;
        } else if (isBinOp(instruction)) {
            num16Bits = 2;
        } else if (isBinOp2addr(instruction)) {
            num16Bits = 1;
        } else if (isBinOpLit16(instruction) || isBinOpLit8(instruction)) {
            num16Bits = 2;
        } else if (isConstMethodHandle(instruction) || isConstMethodType(instruction)) {
            num16Bits = 2;
        } else {
            throw new Error("Invalid instruction: " + instruction);
        }
        
        return num16Bits;
    }

}