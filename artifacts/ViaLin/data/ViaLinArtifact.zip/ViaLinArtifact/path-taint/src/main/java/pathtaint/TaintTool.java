package pathtaint;

public enum TaintTool {
    PathTaint, TaintDroid, TaintDroidS, Original, Coverage
}
