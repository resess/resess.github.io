package pathtaint;


import java.io.File;
import java.io.IOException;
import java.lang.Iterable;
import java.lang.String;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

import org.jf.dexlib2.AccessFlags;
import org.jf.dexlib2.DexFileFactory;
import org.jf.dexlib2.Opcodes;
import org.jf.dexlib2.builder.MutableMethodImplementation;
import org.jf.dexlib2.iface.ClassDef;
import org.jf.dexlib2.iface.DexFile;
import org.jf.dexlib2.iface.Field;
import org.jf.dexlib2.iface.Method;
import org.jf.dexlib2.iface.MethodImplementation;
import org.jf.dexlib2.immutable.ImmutableClassDef;
import org.jf.dexlib2.immutable.ImmutableMethod;
import org.jf.dexlib2.rewriter.ClassDefRewriter;
import org.jf.dexlib2.rewriter.DexRewriter;
import org.jf.dexlib2.rewriter.RewriterModule;
import org.jf.dexlib2.rewriter.Rewriter;
import org.jf.dexlib2.rewriter.Rewriters;




public class PathTaint {
 
  private static final List<ClassDef> classes = Lists.newArrayList();

  public static DexFile addField(DexFile dexFile, final String className, final Field field) {
    DexRewriter rewriter = new DexRewriter(new RewriterModule() {
      @Override public Rewriter<ClassDef> getClassDefRewriter(Rewriters rewriters) {
        return new ClassDefRewriter(rewriters) {
          @Override public ClassDef rewrite(ClassDef classDef) {
            if (classDef.getType().equals(className)) {
              return new RewrittenClassDef(classDef) {
                @Override public Iterable<? extends Field> getInstanceFields() {
                  if ((field.getAccessFlags() & AccessFlags.STATIC.getValue()) == 0) {
                    return Iterables.concat(super.getInstanceFields(), ImmutableList.of(field));
                  }
                  return super.getInstanceFields();
                }

                @Override public Iterable<? extends Field> getStaticFields() {
                  if ((field.getAccessFlags() & AccessFlags.STATIC.getValue()) != 0) {
                    return Iterables.concat(super.getStaticFields(), ImmutableList.of(field));
                  }
                  return super.getStaticFields();
                }
              };
            }
            return super.rewrite(classDef);
          }
        };
      }
    });

    return rewriter.getDexFileRewriter().rewrite(dexFile);
  }

  public static void main(String args[]) throws IOException {
    if (args.length < 4) {
      System.out.println("Usage: mode inFile.dex tempDir analysisDir");
      return;
    }

    List<String> inFiles = new ArrayList<>();
    String mode = args[0];
    String isFrameWorkStr = args[1];
    String toolStr = args[2];
    String outDir = args[3];
    String analysisDir = args[4];
    String srcFile = args[5];
    String sinkFile = args[6];

    System.out.println("Src: " + srcFile);
    System.out.println("Sink: " + sinkFile);

    for (int i = 7; i < args.length; i++) {
      inFiles.add(args[i]);
    }


    TaintTool tool;
    if (toolStr.equals("pt")) {
      tool = TaintTool.PathTaint;
    } else if (toolStr.equals("td")) {
      tool = TaintTool.TaintDroid;
    } else if (toolStr.equals("tdS")) {
      tool = TaintTool.TaintDroidS;
    } else if (toolStr.equals("orig")) {
      tool = TaintTool.Original;
    } else if (toolStr.equals("cov")) {
      tool = TaintTool.Coverage;
    } else {
      throw new Error("Unsuporrted tool type");
    }

    boolean isFramework = Boolean.valueOf(isFrameWorkStr);

    TaintInjector injector = new TaintInjector(inFiles, outDir, analysisDir, srcFile, sinkFile, tool, isFramework);
    if (mode.equals("t")) { // taint
      injector.inject();
    } else if (mode.equals("a")) { // analyze
      injector.analyze();
    } else {
      throw new Error("Unupported mode " + mode);
    }
  }
  
  private static DexFile readDexFile(String fileName) throws IOException {
    File srcFile = new File(fileName);
    return DexFileFactory.loadDexFile(srcFile, Opcodes.forApi(27));
  }

  private static void taintDexFile(DexFile dexFile) {
    
    
    try {
      ForkJoinPool taintPool = new ForkJoinPool(16);
      taintPool.submit(() ->
          dexFile.getClasses().parallelStream().forEach(classDef ->
          classes.add(taintDexClass(classDef)))
      ).get();
    } catch (InterruptedException e) {
      e.printStackTrace();
    } catch (ExecutionException e) {
      e.printStackTrace();
    }
  }
  
  private static ClassDef taintDexClass(ClassDef classDef) {
    // System.out.println("Tainting class: " + classDef);
    return new ImmutableClassDef(classDef.getType(),
      classDef.getAccessFlags(),
      classDef.getSuperclass(),
      classDef.getInterfaces(),
      classDef.getSourceFile(),
      classDef.getAnnotations(),
      classDef.getFields(),
      classDef.getMethods());
      // taintDexMethods(classDef));
  }

  private static List<Method> taintDexMethods(ClassDef classDef) {
    List<Method> taintedMethods = Lists.newArrayList();
    for (Method method: classDef.getMethods()) {
      MethodImplementation implementation = method.getImplementation();
      MutableMethodImplementation mutableImplementation = new MutableMethodImplementation(implementation);
      // List<BuilderInstruction> instructions = mutableImplementation.getInstructions();
      // Reference fieldRef = null;

      // int ni_index = -1;
      // int object_register = -1;
      // for (int i = 0; i < instructions.size(); i++) {
      //   Instruction instruction = instructions.get(i);
      //   if (fieldRef != null && object_register >= 0 && i == (ni_index + 2)) {
      //     System.out.println("add instruction");
      //     mutableImplementation.addInstruction(i, new BuilderInstruction22c(Opcode.IPUT, object_register, object_register, fieldRef));
      //     ni_index = -1;
      //     object_register = -1;
      //   }
      //   if (instruction.getOpcode() == Opcode.NEW_INSTANCE) {
      //     BuilderInstruction21c old_instruction = (BuilderInstruction21c) instruction;
      //     object_register = old_instruction.getRegisterA();
      //     fieldRef = old_instruction.getReference();
      //     int ref_type = old_instruction.getReferenceType();
      //     ni_index = i;
      //   }
      // }

      taintedMethods.add(new ImmutableMethod(
        method.getDefiningClass(),
        method.getName(),
        method.getParameters(),
        method.getReturnType(),
        method.getAccessFlags(),
        method.getAnnotations(),
        null, mutableImplementation));
    }
    return taintedMethods;
  }
}