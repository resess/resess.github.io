package pathtaint;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.simple.*;


public class TaintDroid extends TaintAnalysis {
    
    enum ClassRegion {
        Header, StaticFields, InstanceFields, Methods
    }

    private List<String> smaliFiles;
    private ClassAnalysis classAnalysis;
    private final Map<String, JSONObject> classToMethodIndexMap;
    private final String analysisDir;
    private Statistics statistics;
    private boolean isFramework;


    private static Set<String> forbiddenClasses = ClassTaint.forbiddenClasses;

    // private static final Set<String> allowed = new HashSet<>(Arrays.asList(
    //     "L"));

    private static final String [] ignoreArray = ClassTaint.ignoreArray;

    private static final Set<String> ignoreClass = new HashSet<>(Arrays.asList(ignoreArray)); 
    private static final Set<String> ignore = new HashSet<>(Arrays.asList(ignoreArray));
    private static final boolean TAINT_FIELDS = true;
    private static final boolean TAINT_METHODS = true;



    public TaintDroid(String dexDir, List<String> smaliFiles, String analysisDir, boolean isFramework) {
        this.smaliFiles = smaliFiles;
        this.classAnalysis = new ClassAnalysis(analysisDir);
        this.classToMethodIndexMap = new HashMap<>();
        this.analysisDir = analysisDir;
        this.statistics = new Statistics();
        this.isFramework = isFramework;
    }

    private boolean isIgnored(Set<String> classNames) {
        for (String className : classNames) {
            if (className.startsWith("[")) { // TODO: remove
                return true;
            }
            for (String c : ignore) {
                if (className.startsWith(c)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean isIgnored(String className) {

        if (className.startsWith("[")) { // TODO: remove
            return true;
        }
        for (String c : ignore) {
            if (className.startsWith(c)) {
                return true;
            }
        }


        return false;
    }

    private boolean isIgnoredClass(String className) {
        // for (String c : allowed) {
        //     if (className.startsWith(c)) {
        //         return false;
        //     }
        // }
        for (String c : ignoreClass) {
            if (className.startsWith(c)) {
                return true;
            }
        }
        return false;
    }

    public void addTaint() {
        for (String file : smaliFiles) {
            // ClassInfo classInfo = ClassInfo.getClassInfo(file);
            addTaintToClassFile(file, null);
        }
        if (!smaliFiles.isEmpty()) {
            saveDexInfo();
        }
        statistics.print();
    }

    private void addTaintToClassFile(String file, ClassInfo classInfo) {

        // if (isFramework) { // TODO: remove if tainting framework
        //     return;
        // }

        List<String> classLines;
        try {
            classLines = Files.readAllLines(Paths.get(file));
        } catch (IOException e) {
            throw new Error("Cannot open class file: " + file);
        }

        String className = getLastToken(classLines.get(0));

        
        // if (className.equals("Ljava/lang/PathTaint;") || className.equals("Ljava/lang/Object;") || className.equals("Ljava/lang/Class;")) {
        //     return;
        // }
        // if (className.equals("Ljava/util/Date;") || className.startsWith("Ljava/net")) {
        // } else if (className.startsWith("L")) {
        //     return;
        // }


        if (className.equals("Ljava/lang/TaintDroid;")) {
            return;
        }

        if (forbiddenClasses.contains(className) || isIgnoredClass(className)) {
            // System.out.println("Ignored class: " + className);
            return;
        }

        // System.out.println("Tainted class: " + className);

        JSONObject classIndex = new JSONObject();
        classToMethodIndexMap.put(className, classIndex);

        MethodInfo methodInfo = null;
        Integer taintTempReg = null;
        Integer signatureRegister = null;
        Integer timerRegister = null;
        Integer maxRegs = 0;
        Integer methodDelta = 0;
        List<String> taintedClassLines = new ArrayList<>();
        List<String> taintFieldMethods = new ArrayList<>();
        Map<Integer, Integer> newParams = new HashMap<>();
        Map<String, String> taintRegMap = new HashMap<>();
        Set<String> taintedMethods = new HashSet<>();

        boolean instrument = true;
        boolean inAnnon = false;
        Stack<String> tryCatches = new Stack<>();
        String lastCalled = null;
        JSONObject methodIndex = null;

        for (int lineNum = 0; lineNum < classLines.size(); lineNum++) {
            
            String line = classLines.get(lineNum);
            List<String> linesToAdd = new ArrayList<>();
            linesToAdd.add(line);

            
            if (line.trim().startsWith(".annotation")) {
                inAnnon = true;
            }
            if (line.trim().startsWith(".end annotation")) {
                inAnnon = false;
            }
            if (line.startsWith("    :try_start")) {
                tryCatches.push(line);
            }
            if (line.startsWith("    :try_end")) {
                tryCatches.pop();
            }


            if (instrument && !inAnnon) { 

                if (line.isEmpty()) {
                    // pass
                } else if (line.startsWith(".field")) {
                    if (TAINT_FIELDS && !forbiddenClasses.contains(className) && ! isIgnored(className)) {
                        addTaintField(linesToAdd, line, className, taintFieldMethods);
                    }
                } else if (line.startsWith("    invoke")) {
                    methodDelta++;
                    methodIndex.put(methodDelta, line);
                    linesToAdd.clear();
                    line = changeParamsToLocals(newParams, line, taintTempReg);
                    linesToAdd.add(line);
                    int newMaxRegs = injectTaintSink(line, linesToAdd, methodInfo, taintTempReg+1, taintRegMap, signatureRegister, methodDelta, className);
                    maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                    taintTempReg = maxRegs;
                    if (!line.startsWith("    invoke-polymorphic")) { // TODO: model poly too and remove this if
                        newMaxRegs = addTaintToCallParams(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg+1, taintRegMap, signatureRegister, methodDelta);
                        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                        taintTempReg = maxRegs;
                        lastCalled = line;
                    }
                } else if (line.startsWith("    .registers")) {
                    addTaintRegisters(line, linesToAdd, methodInfo);
                    int firstTaintReg = methodInfo.getBaseNumRegs();

                    signatureRegister = firstTaintReg + methodInfo.getNumBaseLocalRegs() + methodInfo.getNumBaseParams() + 1;
                    timerRegister = signatureRegister + 1;
                    taintTempReg = timerRegister + 2;
                    maxRegs = taintTempReg + 2;

                    // if (!isFramework) {
                    //     addStartTimer(linesToAdd, timerRegister, taintTempReg, methodInfo);
                    // }
                    

                    for (int i = 0; i < methodInfo.getBaseNumRegs() + 1; i++) {
                        taintRegMap.put("v" + i, "v" + String.valueOf(firstTaintReg + i));
                    }

                    String v0MoveInstruction = null;
                    String regToUseForInit = "v0";

                    for (int i = 0; i < methodInfo.getParams().size(); i++ ) {
                        
                        String paramType = methodInfo.getParams().get(i);
                        int paramReg = methodInfo.getNumBaseLocalRegs() + i;

                        newParams.put(i, paramReg);

                        String moveInstruction = getMoveInstructionByType(paramType);

                        if (moveInstruction != null) {
                            linesToAdd.add("    " + moveInstruction + " v" + paramReg + ", p" + i);
                            
                            if (paramReg == getRegNumFromRef(regToUseForInit)) {
                                v0MoveInstruction = moveInstruction;
                            }
                        }
                    }

                    

                    boolean alreadyMovedV0 = false;

                    if (TAINT_METHODS && !forbiddenClasses.contains(className) && !isIgnored(classAnalysis.getClassOfMethod(methodInfo.getClassName(), methodInfo.getNameAndDesc())) && !methodInfo.getNameAndDesc().equals("<init>()V")) { // TODO: remove the "on"  && !methodInfo.getMethodName().startsWith("on") && !methodInfo.getDesc().equals("(Landroid/view/View;)V") 
                        // move taint params to taint regs
                        if (v0MoveInstruction != null) {
                            linesToAdd.add("    " + v0MoveInstruction + " v" + taintTempReg + ", " + regToUseForInit);
                            alreadyMovedV0 = true;
                        }
                        for (int i = 0; i < methodInfo.getParams().size(); i++) {
                            int paramReg = methodInfo.getNumBaseLocalRegs() + i;
                            linesToAdd.add("    invoke-static {}, Ljava/lang/Thread;->getParamTaintTaintDroid" + i + "int()I");
                            linesToAdd.add("    move-result " + regToUseForInit);
                            linesToAdd.add("    move/16 " + taintRegMap.get("v"+paramReg) + ", " + regToUseForInit);
                            taintRegMap.put("p" + i, taintRegMap.get("v"+paramReg));
                        }
                        int paramReg = methodInfo.getNumBaseLocalRegs() + methodInfo.getParams().size();
                        
                        linesToAdd.add("    const " + regToUseForInit + ", 0");
                        linesToAdd.add("    move/16 " + taintRegMap.get("v"+paramReg) + ", " + regToUseForInit);

                        if (paramReg == getRegNumFromRef(regToUseForInit)) {
                            v0MoveInstruction = "move/16";
                        }
                    } else {
                        for (int i = 0; i < methodInfo.getParams().size(); i++) {
                            int paramReg = methodInfo.getNumBaseLocalRegs() + i;
                            eraseTaintV0(regToUseForInit, taintTempReg, linesToAdd, taintRegMap.get("v"+paramReg));
                            taintRegMap.put("p" + i, taintRegMap.get("v"+paramReg));
                        }
                        int paramReg = methodInfo.getNumBaseLocalRegs() + methodInfo.getParams().size();
                        eraseTaintV0(regToUseForInit,taintTempReg, linesToAdd, taintRegMap.get("v"+paramReg));
                        if (v0MoveInstruction != null) {
                            linesToAdd.add("    " + v0MoveInstruction + " v" + taintTempReg + ", " + regToUseForInit);
                            alreadyMovedV0 = true;
                        }
                        linesToAdd.add("    const " + regToUseForInit + ", 0");
                        linesToAdd.add("    move/16 " + taintRegMap.get("v"+paramReg) + ", " + regToUseForInit);
                    }

                    // Init taint registers, must be done after moving parameters
                    if (v0MoveInstruction != null && !alreadyMovedV0) {
                        linesToAdd.add("    " + v0MoveInstruction + " v" + taintTempReg + ", "+regToUseForInit);
                    }

                    linesToAdd.add("    const-string/jumbo "+regToUseForInit+", \"" + methodInfo.signature() + "\"");
                    linesToAdd.add("    move-object/16 " + "v" + String.valueOf(signatureRegister) + ", "+regToUseForInit);

                    // linesToAdd.add("    invoke-static {" + regToUseForInit + "}, Ljava/lang/TaintDroid;->printMethodName(Ljava/lang/String;)V");


                    for (int i = 0; i < methodInfo.getNumBaseLocalRegs(); i++) {
                        linesToAdd.add("    const " + regToUseForInit + ", 0");
                        linesToAdd.add("    move/16 " + "v" + String.valueOf(firstTaintReg + i) + ", "+regToUseForInit);
                    }
                    if (TAINT_METHODS && !forbiddenClasses.contains(className) && !isIgnored(classAnalysis.getClassOfMethod(methodInfo.getClassName(), methodInfo.getNameAndDesc())) && !methodInfo.getNameAndDesc().equals("<init>()V")) { // TODO: remove the "on" && !methodInfo.getMethodName().startsWith("on")  && !methodInfo.getDesc().equals("(Landroid/view/View;)V")
                    } else {
                        for (int i = methodInfo.getNumBaseLocalRegs(); i < methodInfo.getBaseNumRegs(); i++) {
                            linesToAdd.add("    const " + regToUseForInit + ", 0");
                            linesToAdd.add("    move/16 " + "v" + String.valueOf(firstTaintReg + i) + ", "+regToUseForInit);
                        }
                    }
                    if (v0MoveInstruction != null) {
                        linesToAdd.add("    " + v0MoveInstruction + " "+regToUseForInit+", v" + taintTempReg);
                    }

                    if (methodInfo.getNameAndDesc().equals("doInBackground([Ljava/lang/Object;)Ljava/lang/Object;")) {
                        String targetTaintReg = taintRegMap.get("p1");
                        linesToAdd.add("    invoke-static {}, Ljava/lang/Thread;->getAsyncTaskParamTaintDroidInt()I");
                        linesToAdd.add("    move-result " + targetTaintReg);
                    } else if (methodInfo.getNameAndDesc().equals("invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;")) {
                        String targetTaintReg = taintRegMap.get("p3");
                        if(methodInfo.isStatic()) {
                            targetTaintReg = taintRegMap.get("p2");
                        }
                        linesToAdd.add("    invoke-static {}, Ljava/lang/Thread;->getAsyncTaskParamTaintDroidInt()I");
                        linesToAdd.add("    move-result " + targetTaintReg);
                    }
                    

                } else if (line.startsWith(".method")) {
                    if (!line.contains(" native ")) {
                        methodInfo = getMethodInfo(className, line);
                        // boolean taintedMethod = addTaintToMethodParams(line, linesToAdd, methodInfo);
                        // if (taintedMethod) {
                        //     taintedMethods.add(methodInfo.signature());
                        // }
                    }
                    methodDelta = 0;
                    methodIndex = new JSONObject();
                } else if (line.startsWith(".end method")) {
                    if (methodInfo != null) {
                        classIndex.put(methodInfo.getNameAndDesc(), methodIndex);
                    }

                    methodInfo = null;
                    lastCalled = null;
                    fixRegisterLine(taintedClassLines, maxRegs);
                } else if (methodInfo != null) {
                    String instruction = getToken(line, 0);
                    if (instruction.startsWith(".")) {
                    } else if (instruction.startsWith(":")) {
                    } else if (instruction.startsWith("0x")) {
                    } else if (instruction.startsWith("-")) {
                    } else {

                        methodDelta++;
                        methodIndex.put(methodDelta, line);

                        linesToAdd.clear();

                        line = changeParamsToLocals(newParams, line, taintTempReg);

                        linesToAdd.add(line);

                        if (isNop(instruction)) {
                            // pass
                        } else if (isMove(instruction) || isMoveFrom16(instruction) || isMove16(instruction) || 
                            isMoveWide(instruction) || isMoveWideFrom16(instruction) || isMoveWide16(instruction) ||
                            isMoveObject(instruction) || isMoveObjectFrom16(instruction) || isMoveObject16(instruction)) {

                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);
                            maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;
                            if (targetIsWide(instruction)) {
                                addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                            }
                        } else if (isMoveResult(instruction) || isMoveResultWide(instruction) || isMoveResultObject(instruction)) {

                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);
                            
                            addGetReturnTaint(taintTempReg, maxRegs, linesToAdd, taintTargReg);

                            int newMaxRegs = injectTaintSeed(lastCalled, linesToAdd, methodInfo, taintTempReg+1, taintTargReg, signatureRegister, methodDelta, className, targetReg, instruction);
                            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                            taintTempReg = maxRegs;
                            
                            if (targetIsWide(instruction)) {
                                addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                            }
                            lastCalled = null;
                        } else if (isMoveException(instruction)) {
                            // pass
                        } else if (isReturnVoid(instruction)) {
                            // pass
                            // maxRegs = addEndTimer(linesToAdd, timerRegister, signatureRegister, methodInfo, taintTempReg, maxRegs);
                            // taintTempReg = maxRegs;
                        } else if (isReturn(instruction) || isReturnWide(instruction) || isReturnObject(instruction)) {
                            
                            int newMaxRegs = handleReturn(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister);
                            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                            taintTempReg = maxRegs;
                            
                            // maxRegs = addEndTimer(linesToAdd, timerRegister, signatureRegister, methodInfo, taintTempReg, maxRegs);
                            // taintTempReg = maxRegs;
                        } else if (isConst4(instruction) || isConst16(instruction) || isConst(instruction) || isConstHigh16(instruction) || 
                                isConstWide16(instruction) || isConstWide32(instruction) || isConstWide(instruction) || isConstWideHigh16(instruction) ||
                                isConstString(instruction) || isConstStringJumbo(instruction) || isConstClass(instruction)) {
                                    String targetReg = getRegReference(line, 1);
                                    String taintTargReg = taintRegMap.get(targetReg);
                                    maxRegs = addEraseTaint(taintTempReg, maxRegs, linesToAdd, targetReg, taintTargReg, signatureRegister);
                                    taintTempReg = maxRegs;
                        } else if (isMonitorEnter(instruction) || isMonitorExit(instruction)) {
                            // pass
                        } else if (isCheckCast(instruction)) {
                            // pass
                        } else if (isInstanceOf(instruction) || isArrayLength(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);
                            linesToAdd.add("    move/16 " + taintTargReg + ", " + taintSrcReg);
                        } else if (isNewInstance(instruction) || isNewArray(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);
                            maxRegs = addEraseTaint(taintTempReg, maxRegs, linesToAdd, targetReg, taintTargReg, signatureRegister);
                            taintTempReg = maxRegs;
                        } else if (isFilledNewArray(instruction) || isFilledNewArrayRange(instruction) || isFillArrayData(instruction)) {
                            // pass 
                            // TODO: handle arrays
                        } else if (isThrow(instruction)) {
                            
                            // TODO: Change this hande return to handleThrow, must add setThrowTaint and getThrowTaint
                            // int newMaxRegs = handleReturn(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                            //     line, linesToAdd, instruction, signatureRegister);
                            // maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                            // taintTempReg = maxRegs;

                            // if (!isFramework) {
                            //     maxRegs = addEndTimer(linesToAdd, timerRegister, signatureRegister, methodInfo, taintTempReg, maxRegs);
                            //     taintTempReg = maxRegs;
                            // }
                        } else if (isGoto(instruction) || isGoto16(instruction) || isGoto32(instruction)) {
                            // pass
                        } else if (isPackedSwitch(instruction) || isSparseSwitch(instruction)) {
                            // pass
                        } else if (isCmpkind(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);
                            maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;
                        } else if (isIfTest(instruction) || isIfTestz(instruction)) {
                            // pass
                        } else if (isArrayOp(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);


                            if (instruction.startsWith("aput")) {
                                String temp = taintTargReg;
                                taintTargReg = taintSrcReg;
                                taintSrcReg = temp;
                            }

                            maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;
                            if (targetIsWide(instruction)) {
                                addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                            }
                            // TODO: handle array
                        } else if (isIinstanceOp(instruction)) {
                            int newMaxRegs = handleIinstanceOp(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister);
                            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                            taintTempReg = maxRegs;
                        } else if (isSstaticOp(instruction)) {
                            int newMaxRegs = handleSstaticOp(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                    line, linesToAdd, instruction, signatureRegister);
                            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                            taintTempReg = maxRegs;
                        } else if (isInvokeKind(instruction) || isInvokeKindRange(instruction) || 
                            isInvokePolymorphic(instruction) || isInvokePolymorphicRange(instruction) || 
                            isInvokeCustom(instruction) || isInvokeCustomRange(instruction)) {
                            throw new Error("Invokes are handled in a separate branch");
                        } else if (isUnOp(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);
                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);

                            maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;
                            if (targetIsWide(instruction)) {
                                addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                            }
                        } else if (isBinOp(instruction)) {
                            String taintTargReg = taintRegMap.get(getRegReference(line, 1));
                            String firstTaintSrcReg = taintRegMap.get(getRegReference(line, 2));
                            String secondTaintSrcReg = taintRegMap.get(getRegReference(line, 3));

                            maxRegs = handleTwoSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, firstTaintSrcReg, secondTaintSrcReg);
                            taintTempReg = maxRegs;
                            if (targetIsWide(instruction)) {
                                addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                            }
                        } else if (isBinOp2addr(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);
                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);
                            
                            maxRegs = handleTwoSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;

                            if (targetIsWide(instruction)) {
                                addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                            }
                        } else if (isBinOpLit16(instruction) || isBinOpLit8(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);
                            maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;

                            if (targetIsWide(instruction)) {
                                addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                            }
                        } else if (isConstMethodHandle(instruction) || isConstMethodType(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);
                            maxRegs = addEraseTaint(taintTempReg, maxRegs, linesToAdd, targetReg, taintTargReg, signatureRegister);
                            taintTempReg = maxRegs;
                        } else {
                            throw new Error("Invalid instruction: " + line);
                        }
                    }
                }
            }
            taintedClassLines.addAll(linesToAdd);
        }

        for (int lineNum = 0; lineNum < classLines.size(); lineNum++) {
            String line = classLines.get(lineNum);
            if (line.startsWith(".method")) {
                if (!line.contains(" native ") && line.contains(" abstract ") ) {
                    methodInfo = getMethodInfo(className, line);
                    if (!taintedMethods.contains(methodInfo.signature())) {
                        methodInfo = null;
                    } else {
                        taintedClassLines.add(line);
                    }
                }
            } else if (methodInfo != null) {
                taintedClassLines.add(line);
                if (line.startsWith(".end method")) {
                    methodInfo = null;
                }
            }
        }

        taintedClassLines.addAll(taintFieldMethods);

        try {
            Files.write(Paths.get(file), taintedClassLines);
        } catch (IOException e) {
            throw new Error("Cannot modify class file: " + file);
        }
    }


    private int addEndTimer(List<String> linesToAdd, Integer timerRegister, Integer signatureRegister, MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs) {
        if (methodInfo.getMethodName().startsWith("on") || methodInfo.getDesc().equals("(Landroid/view/View;)V") || methodInfo.getMethodName().startsWith("doInBackground") || methodInfo.getNameAndDesc().equals("run()V")) {
            String newLine = "    invoke-static {v" + signatureRegister + ", v" + timerRegister + ", v" + String.valueOf(timerRegister + 1) + "}, Ljava/lang/PathTaint;->endTime(Ljava/lang/String;J)V";
            Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd.addAll(linesToAdd.size() - 1, rangedInvoke.first);
            int newMaxRegs = rangedInvoke.second;
            return (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        }
        return maxRegs;
    }

    private void addStartTimer(List<String> linesToAdd, Integer timerRegister, Integer taintTempReg, MethodInfo methodInfo) {
        if (methodInfo.getMethodName().startsWith("on") || methodInfo.getDesc().equals("(Landroid/view/View;)V") || methodInfo.getMethodName().startsWith("doInBackground") || methodInfo.getNameAndDesc().equals("run()V")) {
            String p0Move = null;
            String p1Move = null;
            if (methodInfo.getNumBaseLocalRegs() < 2) {
                if (methodInfo.getNumBaseParams() > 0) {
                    p0Move = getMoveInstructionByType(methodInfo.getParams().get(0));
                }
                if (methodInfo.getNumBaseParams() > 1) {
                    p1Move = getMoveInstructionByType(methodInfo.getParams().get(1));
                }
            }
            if (p0Move != null) {
                linesToAdd.add("    " + p0Move + " v" + taintTempReg + ", p0");
                if (p0Move != null && methodInfo.getNumBaseParams() > 1 && !p0Move.contains("wide") && p1Move != null) {
                    linesToAdd.add("    " + p1Move + " v" + String.valueOf(taintTempReg+1) + ", p1");
                }
            }
            linesToAdd.add("    invoke-static {}, Ljava/lang/System;->nanoTime()J");
            linesToAdd.add("    move-result-wide v0");
            linesToAdd.add("    move-wide/16 v" + timerRegister + ", v0");
            if (p0Move != null) {
                linesToAdd.add("    " + p0Move + " p0, v" + taintTempReg);
                if (p0Move != null && methodInfo.getNumBaseParams() > 1 && !p0Move.contains("wide") && p1Move != null) {
                    linesToAdd.add("    " + p1Move + " p1, v" + String.valueOf(taintTempReg+1));
                }
            }
        }
    }

    private void saveDexInfo() {
        File infoDir = new File(analysisDir, "class_info");
        if (!infoDir.isDirectory()) {
            infoDir.mkdirs();
        }
        for (Map.Entry<String, JSONObject> entry: classToMethodIndexMap.entrySet()) {
            String className = entry.getKey();
            JSONObject classInfo = entry.getValue();
            String unixClassName = className.replace("/", "_").replace(";", "") + ".json";
            File classFile = new File(infoDir, unixClassName);
            try {
                FileWriter fileWriter = new FileWriter(classFile);
                fileWriter.write(classInfo.toJSONString());
                fileWriter.flush();
                fileWriter.close();
            } catch (IOException e) {
                throw new Error("Cannot save class ifno: " + classFile);
            }
        }
    }


    private void eraseTaint(Integer taintTempReg, List<String> linesToAdd, String targetReg, String taintTargReg, String moveInstruction) {
        if (getRegNumFromRef(taintTargReg) < 256) {
            linesToAdd.add("    const/16 " + taintTargReg + ", 0");
        } else {
            linesToAdd.add("    " + moveInstruction + " v" + taintTempReg + ", " + targetReg);
            linesToAdd.add("    const/16 " + targetReg + ", 0");
            linesToAdd.add("    move/16 " + taintTargReg + ", " + targetReg);
            linesToAdd.add("    " + moveInstruction + " " + targetReg + ", v" + taintTempReg);
        }
    }


    private void eraseTaintV0(String regToErase, Integer taintTempReg, List<String> linesToAdd, String taintTargReg) {
        if (getRegNumFromRef(taintTargReg) < 256) {
            linesToAdd.add("    const/16 " + taintTargReg + ", 0");
        } else {
            linesToAdd.add("    const/16 " + regToErase + ", 0");
            linesToAdd.add("    move/16 " + taintTargReg + ", " + regToErase);
        }
    }

    private Integer handleOneSourceOneDest(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
            Map<String, String> taintRegMap, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister, String destTaintReg, String srcTaintReg) {
        addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, destTaintReg, signatureRegister, srcTaintReg);
        return maxRegs;
    }

    private Integer handleTwoSourceOneDest(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
            Map<String, String> taintRegMap, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister, 
            String destTaintReg, String firstSrcTaintReg, String secondSrcTaintReg) {
        addCreateTaintWithLeftRight(taintTempReg, maxRegs, linesToAdd, destTaintReg, signatureRegister, firstSrcTaintReg, secondSrcTaintReg);
        return maxRegs;
    }


    private Integer handleReturn(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
        Map<String, String> taintRegMap, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister) {


        linesToAdd.clear();
        String taintTargReg = taintRegMap.get(getRegReference(line, 1));
        addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister, taintTargReg);
        maxRegs = addSetReturnTaint(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister);
        linesToAdd.add(line);
        return maxRegs;
    }


    private Integer addEraseTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String targetReg, String taintTargReg, int signatureRegister) {
        if (getRegNumFromRef(taintTargReg) < 256) {
            linesToAdd.add(0, "    const " + taintTargReg + ", 0");
        } else {
            linesToAdd.add(0, "    const " + targetReg + ", 0");
            linesToAdd.add(1, "    move/16 " + taintTargReg + ", " + targetReg);
        }

        return maxRegs;
    }

    private void addCopyTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister, String taintSrcReg) {
        linesToAdd.add("    move/16 " + taintTargReg + ", " + taintSrcReg);
    }


    private void addCreateTaintWithLeftRight(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister, String leftTaint, String rightTaint) {
        if (!(taintTargReg.equals(leftTaint) && leftTaint.equals(taintTargReg))) {
            linesToAdd.add("    or-int " + taintTargReg + ", " + leftTaint + ", " + taintTargReg);
        }
        if (!(taintTargReg.equals(rightTaint) && rightTaint.equals(taintTargReg))) {
            linesToAdd.add("    or-int " + taintTargReg + ", " + rightTaint + ", " + taintTargReg);
        }
    }



    private void addCreateTaintWithLeft(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister, String leftTaint) {
        if (!(taintTargReg.equals(leftTaint) && leftTaint.equals(taintTargReg))) {
            linesToAdd.add("    or-int " + taintTargReg + ", " + leftTaint + ", " + taintTargReg);
        }
    }


    private void addCreateTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister, int taintNum, String targetReg, String instruction) {
        
        if (taintTempReg > 255) {
            String moveInstruction = "move/16";
            if (instruction.contains("wide")) {
                moveInstruction = "move-wide/16";
            } else if (instruction.contains("object")) {
                moveInstruction = "move-object/16";
            }
            linesToAdd.add("    " + moveInstruction + " v" + taintTempReg + ", " + targetReg);
            linesToAdd.add("    const " + targetReg + ", " + (1 << taintNum));
            linesToAdd.add("    or-int " + taintTargReg + ", " + taintTargReg + ", " + targetReg);
            linesToAdd.add("    " + moveInstruction + " " + targetReg + ", v" + taintTempReg);
        } else {
            linesToAdd.add("    const v" + taintTempReg + ", " + (1 << taintNum));
            linesToAdd.add("    or-int " + taintTargReg + ", " + taintTargReg + ", v" + taintTempReg);
        }
    }

    private void addGetReturnTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg) {
        linesToAdd.add("    invoke-static {}, Ljava/lang/Thread;->getReturnTaintTaintDroidInt()I");
        linesToAdd.add("    move-result " + taintTargReg);
    }


    private int addSetReturnTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister) {
        Pair<List<String>, Integer> rangedInvoke;
        int newMaxRegs;
        String newLine = "    invoke-static {" + taintTargReg + "}, Ljava/lang/Thread;->setReturnTaintTaintDroidInt(I)V";
        rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;
    }



    private Integer handleIinstanceOp(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
            Map<String, String> taintRegMap, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister) {
        String fieldRef = getLastToken(line);
        String fieldType = fieldRef.substring(fieldRef.indexOf(":")+1);
        String fieldClass = getFieldClass(fieldRef);
        String fieldName = getFieldName(fieldRef);
        String taintField = createTaintField(fieldClass, fieldName);
        String targetReg = getRegReference(line, 1);
        String taintTargReg = taintRegMap.get(getRegReference(line, 1));

        String baseRegRef = getRegReference(line, 2);
        String taintBaseReg = taintRegMap.get(getRegReference(line, 2));


        String whereIsField = classAnalysis.getClassOfField(fieldClass, fieldName);

        if (TAINT_FIELDS && forbiddenClasses.contains(fieldClass) || whereIsField == null || isIgnored(whereIsField)) {
            // String moveInstruction = getMoveInstructionByType(fieldType);
            // eraseTaint(taintTempReg, linesToAdd, targetReg, taintTargReg, moveInstruction);
            // if (targetIsWide(instruction)) {
            //     eraseTaint(taintTempReg, linesToAdd, targetReg, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), moveInstruction);
            // }
        } else {
            linesToAdd.clear();
            if (targetReg.equals(baseRegRef)) {
                // will add line after instrumentation
            } else {
                linesToAdd.add(line);
            }
            
            String newLine = "    # TargTaint: " + taintTargReg + ", BaseTaint: " + taintBaseReg;
            linesToAdd.add(newLine);
            if (instruction.startsWith("iget") ) {

                Pair<List<String>, Integer> rangedInvoke;
                int newMaxRegs;
                
                newLine = "    invoke-static {" + baseRegRef + "}, " + whereIsField + "->getField" + "zzz_" + fieldName + "_taintdroid" + "(" + whereIsField + ")I";
                rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                linesToAdd.addAll(rangedInvoke.first);
                newMaxRegs = rangedInvoke.second;
                maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                linesToAdd.add("    move-result " + taintTargReg);

                if (targetIsWide(instruction)) {
                    linesToAdd.add("    move/16 v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1) + ", " + taintTargReg);
                }
            } else if (instruction.startsWith("iput")) { // TODO: handle put in constructor  && !(methodInfo.getMethodName().equals("<init>"))
                Pair<List<String>, Integer> rangedInvoke;
                int newMaxRegs;

                addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister, taintTargReg);

                newLine = "    invoke-static {" + baseRegRef + ", " + taintTargReg + "}, " + whereIsField + "->setField" + "zzz_" + fieldName + "_taintdroid" + "(" + whereIsField + "I)V";
                rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                linesToAdd.addAll(rangedInvoke.first);
                newMaxRegs = rangedInvoke.second;
                maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
            }

            if (targetReg.equals(baseRegRef)) {
                linesToAdd.add(line);
            } else {
                // line already before instruemtnation
            }
            
        }
        return maxRegs;
    }



    private Integer handleSstaticOp(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
            Map<String, String> taintRegMap, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister) {
        String fieldRef = getLastToken(line);
        String fieldType = fieldRef.substring(fieldRef.indexOf(":")+1);
        String fieldClass = getFieldClass(fieldRef);
        String fieldName = getFieldName(fieldRef);
        String taintField = createTaintField(fieldClass, fieldName);
        String targetReg = getRegReference(line, 1);
        String taintTargReg = taintRegMap.get(getRegReference(line, 1));

        String whereIsField = classAnalysis.getClassOfField(fieldClass, fieldName);

        if (TAINT_FIELDS && forbiddenClasses.contains(fieldClass) || whereIsField == null || isIgnored(whereIsField)) {
            // String moveInstruction = getMoveInstructionByType(fieldType);
            // eraseTaint(taintTempReg, linesToAdd, targetReg, taintTargReg, moveInstruction);
            // if (targetIsWide(instruction)) {
            //     eraseTaint(taintTempReg, linesToAdd, targetReg, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), moveInstruction);
            // }
        } else {
            String newLine = "    # TargTaint: " + taintTargReg;
            linesToAdd.add(newLine);

            if (instruction.startsWith("sget") ) {
                Pair<List<String>, Integer> rangedInvoke;
                int newMaxRegs;
                
                
                newLine = "    invoke-static {}, " + whereIsField + "->getField" + "zzz_" + fieldName + "_taintdroid" + "()I";
                rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                linesToAdd.addAll(rangedInvoke.first);
                newMaxRegs = rangedInvoke.second;
                maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                linesToAdd.add("    move-result " + taintTargReg);
                if (targetIsWide(instruction)) {
                    linesToAdd.add("    move/16 v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1) + ", " + taintTargReg);
                }
            } else if (instruction.startsWith("sput")) {
                Pair<List<String>, Integer> rangedInvoke;
                int newMaxRegs;
                addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister, taintTargReg);
                newLine = "    invoke-static {" + taintTargReg + "}, " + whereIsField + "->setField" + "zzz_" + fieldName + "_taintdroid" + "(I)V";
                rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                linesToAdd.addAll(rangedInvoke.first);
                newMaxRegs = rangedInvoke.second;
                maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
            }
        }
        return maxRegs;
    }


    private String getMoveInstructionByType(String paramType) {
        String moveInstruction = "move-object/16";
        if (paramType.equals("Z") || paramType.equals("C") || paramType.equals("B") || paramType.equals("S") || paramType.equals("I") || paramType.equals("F")) {
            moveInstruction = "move/16";
        } else if (paramType.equals("J") || paramType.equals("D")) {
            moveInstruction = "move-wide/16";
        } else if (paramType.equals("*")) {
            moveInstruction = null;
        }
        return moveInstruction;
    }

    private String changeParamsToLocals(Map<Integer, Integer> newParams, String line, int taintTempReg) {
        line = changeParamsToLocals(newParams, line, " p");
        line = changeParamsToLocals(newParams, line, "{p");
        return line;
    }

    private String changeParamsToLocals(Map<Integer, Integer> newParams, String line, String token) {
        int indexOfParam = 0;
        // System.out.println("Line: " + line);
        if (line.startsWith("    packed-switch")) {
            indexOfParam = "    packed-switch".length()-1;
        }

        // System.out.println("Cmp-1: " + line.indexOf(token, indexOfParam) + ", to " + indexOfParam);
        while (line.indexOf(token, indexOfParam) > indexOfParam) {
            indexOfParam = line.indexOf(token, indexOfParam) + 2;
            int lastIndex = line.indexOf("\"");
            if (lastIndex == -1) {
                lastIndex = line.length();
            }
            // System.out.println("Cmp-2: " + lastIndex + ", to " + indexOfParam);
            if (indexOfParam > lastIndex) {
                break;
            }

            Matcher matcher = Pattern.compile("\\d+").matcher(line.subSequence(indexOfParam, line.length()));
            matcher.find();
            int i = Integer.valueOf(matcher.group());
            line = line.substring(0, indexOfParam-1) + "v" + matcher.replaceFirst(String.valueOf(newParams.get(i)));
            // System.out.println("New line: " + line);
            // System.out.println("Cmp-3: " + line.indexOf(token, indexOfParam) + ", to " + indexOfParam);
        }
        return line;
    }

    private void fixRegisterLine(List<String> taintedClassLines, int maxRegs) {
        if (maxRegs == 0) {
            return;
        }
        for (int i = taintedClassLines.size()-1; i >=0; i--) {
            String line = taintedClassLines.get(i);
            if (line.startsWith("    .registers")) {
                int numRegs = Integer.parseInt(getLastToken(line));
                maxRegs = (maxRegs > numRegs)? maxRegs : numRegs;
                maxRegs = maxRegs + 2;
                String newRegsLine = "    .registers " + maxRegs;
                // System.out.println("        Fixed class line from: " + line);
                // System.out.println("                           to: " + newRegsLine);
                taintedClassLines.set(i, newRegsLine);
                return;
            }
            if (line.startsWith(".method")) {
                return;
            }
        }
    }

    private String createTaintField(String fieldClass, String fieldName) {
        return fieldClass + "->" + "zzz_" + fieldName + "_taintdroid:I";
    }

    private String getFieldName(String fieldRef) {
        return fieldRef.substring(fieldRef.indexOf("->") + 2, fieldRef.indexOf(":"));
    }

    private String getFieldClass(String fieldRef) {
        return fieldRef.substring(0, fieldRef.indexOf("->"));
    }

    private int injectTaintSink(String line, List<String> linesToAdd, MethodInfo methodInfo, int taintTempReg, Map<String, String> taintRegMap, Integer signatureRegister, Integer methodDelta, String className) {
        if (line == null) {
            return 0;
        }
        int maxRegs = 0;
        String delim = "L";
        String search = ", L";
        if (line.indexOf(search) == -1) {
            delim = "[";
            search = ", \\[";
        }
        String calledMethod = delim + line.split(search, 2)[1];

        String instruction = getToken(line, 0);

        MethodInfo calledMethodInfo = new MethodInfo(calledMethod, instruction.contains("static"));
        linesToAdd.clear();
        int[] sinkParams = TaintSink.sinkParams(calledMethodInfo.signature());
        String[] passedRegs = null;
        if (sinkParams.length > 0) {
            passedRegs = parsePassedRegs(line);
        }

        if (sinkParams.length > 0) {
            linesToAdd.add("    move-object/16 v" + taintTempReg + ", v" + signatureRegister);
            linesToAdd.add("    const-string/jumbo v" + signatureRegister + ", \"" + calledMethodInfo.signature() + "\"");
            linesToAdd.add("    invoke-static/range {v" + signatureRegister + " .. v" + signatureRegister + "}, Ljava/lang/TaintDroid;->printSinkFound(Ljava/lang/String;)V");
            linesToAdd.add("    move-object/16 v" + signatureRegister + ", v" + taintTempReg);
            statistics.addSink();
        }

        for (int sinkParam : sinkParams) {

            String taintedVar = passedRegs[sinkParam];
            String taintTargReg = taintRegMap.get(taintedVar);

            addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister, taintTargReg);

            String type = calledMethodInfo.getParams().get(sinkParam);
            String newLine = "    invoke-static {" + taintTargReg + "}, Ljava/lang/TaintDroid;->dumpTaint(I)V";
            if (type.startsWith("L") || type.startsWith("[")) {
                newLine = "    invoke-static {" + taintTargReg + ", " + taintedVar + "}, Ljava/lang/TaintDroid;->dumpTaint(ILjava/lang/Object;)V";
            }

            Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd.addAll(rangedInvoke.first);
            int newMaxRegs = rangedInvoke.second;
            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;

        }
        linesToAdd.add(line);
        return maxRegs;
    }


    private int injectTaintSeed(String line, List<String> linesToAdd, MethodInfo methodInfo, int taintTempReg, String taintTargReg, Integer signatureRegister, Integer methodDelta, String className,
            String targReg, String moveInstruction) {
        if (line == null) {
            return 0;
        }
        int maxRegs = 0;
        String delim = "L";
        String search = ", L";
        if (line.indexOf(search) == -1) {
            delim = "[";
            search = ", \\[";
        }
        String calledMethod = delim + line.split(search, 2)[1];

        String instruction = getToken(line, 0);

        MethodInfo calledMethodInfo = new MethodInfo(calledMethod, instruction.contains("static"));

        int extraRetregister = 0;
        if (!calledMethodInfo.getReturnType().equals("V")) {
            extraRetregister = 1;
        }


        if (extraRetregister == 1) {
            if (TaintSource.isSource(calledMethodInfo.signature())) {
                statistics.addSource();
                linesToAdd.add("    move-object/16 v" + taintTempReg + ", v" + signatureRegister);
                linesToAdd.add("    const-string/jumbo v" + signatureRegister + ", \"" + calledMethodInfo.signature() + "\"");
                linesToAdd.add("    invoke-static/range {v" + signatureRegister + " .. v" + signatureRegister + "}, Ljava/lang/TaintDroid;->printSourceFound(Ljava/lang/String;)V");
                linesToAdd.add("    move-object/16 v" + signatureRegister + ", v" + taintTempReg);
                addCreateTaint(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister, TaintSource.getTaintNum(calledMethodInfo.signature()), targReg, moveInstruction);
            }
        }
        return maxRegs;
    }


    private int modelMethodCall(String line, List<String> linesToAdd, List<String> classLines, int lineNum, MethodInfo methodInfo, int taintTempReg, Map<String, String> taintRegMap, int signatureRegister, int methodDelta) {
        int maxRegs = 0;
        String delim = "L";
        String search = ", L";
        if (line.indexOf(search) == -1) {
            delim = "[";
            search = ", \\[";
        }
        String calledMethod = delim + line.split(search, 2)[1];

        String instruction = getToken(line, 0);

        MethodInfo calledMethodInfo = new MethodInfo(calledMethod, instruction.contains("static"));

        String[] passedRegs = parsePassedRegs(line);

        if (linesToAdd.size() > 0) {
            linesToAdd.remove(linesToAdd.size()-1);
        }
        
        String receiverReg = null;
        String receiverRegTaint = null;
        if (!instruction.contains("static") && !line.contains("{}")) { // has receiver register
            receiverReg = passedRegs[0];
            receiverRegTaint = taintRegMap.get(receiverReg);
        }

        String returnTaintReg = null;

        boolean methodReturnIsTainted = false;
        if (!calledMethodInfo.getReturnType().equals("V")) {
            if (lineNum + 2 < classLines.size() && classLines.get(lineNum+2).contains("move-result")) {
                methodReturnIsTainted = true;
                returnTaintReg = taintRegMap.get(getRegReference(classLines.get(lineNum+2), 1));
                // System.out.println("Return is tainted: " + calledMethodInfo.signature());
                // System.out.println("Move: " + classLines.get(lineNum+2));
                // System.out.println("Return reg: " + getRegReference(classLines.get(lineNum+2), 1));
                // System.out.println("Taint map: " + taintRegMap);
                
            }
        }

        String fristTargReg = null;

        if (receiverRegTaint != null) {
            fristTargReg = receiverRegTaint;
        } else {
            if (methodReturnIsTainted) {
                fristTargReg = returnTaintReg;
            }
        }

        if (fristTargReg != null) {
            for (String reg : parsePassedRegs(passedRegs)) {
                String srcTaintReg = taintRegMap.get(reg);
                addCreateTaintWithLeftRight(taintTempReg, maxRegs, linesToAdd, fristTargReg, signatureRegister, fristTargReg, srcTaintReg);
            }
        }

        if (methodReturnIsTainted) {
            addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, returnTaintReg, signatureRegister, fristTargReg);
            maxRegs = addSetReturnTaint(taintTempReg, maxRegs, linesToAdd, returnTaintReg, signatureRegister);
        }

        if (calledMethodInfo.getMethodName().equals("execute") && calledMethodInfo.getNumBaseParams() == 2 && calledMethodInfo.getReturnType().equals("Landroid/os/AsyncTask;")) {
            // System.out.println("Calling an execute method: " + calledMethodInfo);
            String reg = parsePassedRegs(passedRegs)[1];
            String srcTaintReg = taintRegMap.get(reg);
            linesToAdd.add("    invoke-static/range {" + srcTaintReg + " .. " + srcTaintReg + "}, Ljava/lang/Thread;->setAsyncTaskParamTaintDroid(I)V");
        }

        if (calledMethodInfo.getNameAndDesc().equals("invoke()Ljava/lang/Object;")) {
            String reg = parsePassedRegs(passedRegs)[0];
            String srcTaintReg = taintRegMap.get(reg);
            linesToAdd.add("    invoke-static/range {" + srcTaintReg + " .. " + srcTaintReg + "}, Ljava/lang/Thread;->setAsyncTaskParamTaintDroid(I)V");

        }

        linesToAdd.add(line);

        return maxRegs;
    }

    private int addTaintToCallParams(String line, List<String> linesToAdd, List<String> classLines, int lineNum, MethodInfo methodInfo, int taintTempReg, Map<String, String> taintRegMap, int signatureRegister, int methodDelta) {
        int maxRegs = 0;
        String delim = "L";
        String search = ", L";
        if (line.indexOf(search) == -1) {
            delim = "[";
            search = ", \\[";
        }
        String calledMethod = delim + line.split(search, 2)[1];

        String instruction = getToken(line, 0);

  
        if (classAnalysis.isNative(calledMethod)) {
            return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta);
        }

        MethodInfo calledMethodInfo = new MethodInfo(calledMethod, instruction.contains("static"));

        Set<String> whereIsMethod = classAnalysis.getClassOfMethod(calledMethodInfo.getClassName(), calledMethod.split("->")[1]);
        // System.out.println("For method: " + calledMethod);
        // System.out.println("Classes are: " + whereIsMethod);
        // System.out.println("Inherited: " + classAnalysis.getInheriterClasses(calledMethodInfo.getClassName()));
        // System.out.println("----------------------------------");

        if ((TAINT_METHODS && forbiddenClasses.contains(calledMethodInfo.getClassName())) || isIgnored(classAnalysis.getClassOfMethod(calledMethodInfo.getClassName(), calledMethodInfo.getNameAndDesc())) ) {
            return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta);
        }

        if (calledMethodInfo.getNameAndDesc().equals("<init>()V")) {
            return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta);
        }


        if (whereIsMethod == null || isIgnored(whereIsMethod)) {
            return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta);
        }

        // if (calledMethodInfo.getMethodName().startsWith("on")) { // TODO: remove
        //     return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta);
        // }

        // if (calledMethodInfo.getDesc().equals("(Landroid/view/View;)V")) { // TODO: remove
        //     return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta);
        // }
        

        if (linesToAdd.size() > 0) {
            linesToAdd.remove(linesToAdd.size()-1);
        }
        
        String [] lineSplit = line.split("\\}");
        String [] regSplit = lineSplit[0].split("\\{");
        String [] passedRegs = new String[0];
        if (regSplit.length > 1) {
            passedRegs = regSplit[1].replace(" ", "").split("\\,");
        }

        if (passedRegs.length > 0) {
            if (passedRegs[0].contains("..")) {
                passedRegs[0] = passedRegs[0].replace("..", "Z");
                String firstReg = passedRegs[0].split("Z")[0];
                String lastReg = passedRegs[0].split("Z")[1];
                int firstRegNum = getRegNumFromRef(firstReg);
                int lastRegNum = getRegNumFromRef(lastReg);
                passedRegs = new String[lastRegNum-firstRegNum+1];
                for (int i = firstRegNum; i <= lastRegNum; i++) {
                    passedRegs[i-firstRegNum] = "v" + i;
                }
            }
        }

        for (int i = 0; i < passedRegs.length; i++) {
            String taintReg = taintRegMap.get(passedRegs[i]);
            linesToAdd.add("    invoke-static/range {" + taintReg + " .. " + taintReg + "}, Ljava/lang/Thread;->setParamTaintTaintDroid" + i + "int(I)V");
        }

        if (calledMethodInfo.getNumBaseParams() == 2 && calledMethodInfo.getParams().get(1).equals("Lokhttp3/RequestBody;")) {
            String reg = parsePassedRegs(passedRegs)[1];
            String srcTaintReg = taintRegMap.get(reg);
            linesToAdd.add("    invoke-static/range {" + srcTaintReg + " .. " + srcTaintReg + "}, Ljava/lang/Thread;->setAsyncTaskParamTaintDroid(I)V");
        }

        if (calledMethodInfo.getNameAndDesc().equals("invoke()Ljava/lang/Object;")) {
            String reg = parsePassedRegs(passedRegs)[0];
            String srcTaintReg = taintRegMap.get(reg);
            linesToAdd.add("    invoke-static/range {" + srcTaintReg + " .. " + srcTaintReg + "}, Ljava/lang/Thread;->setAsyncTaskParamTaintDroid(I)V");

        }


        linesToAdd.add(line);

        return maxRegs;
    }

    private void addTaintRegisters(String line, List<String> linesToAdd, MethodInfo methodInfo) {
        Integer baseNumRegs;
        baseNumRegs = Integer.parseInt(getLastToken(line));
        methodInfo.setBaseNumRegs(baseNumRegs);
        String newRegsLine = "    .registers " + ((methodInfo.getBaseNumRegs()*2) + 3); // 1 site reg, 2 temp regs
        linesToAdd.clear();
        linesToAdd.add(newRegsLine);
    }

    private void addTaintField(List<String> linesToAdd, String line, String className, List<String> taintFieldMethods) {
        String[] parse = line.split(":");
        String left = parse[0];
        parse = left.split("\\s+");
        String [] accessModifierArray = Arrays.copyOfRange(parse, 0, parse.length-1);
        
        boolean isTransiet = false;

        for (int i = 0; i < accessModifierArray.length; i++) {
            String token = accessModifierArray[i];
            if (token.equals("private")) {
                accessModifierArray[i] = "public";
            } else if (token.equals("transient")) {
                isTransiet = true;
            }
        }

        

        String fieldName = "zzz_" + parse[parse.length-1] + "_taintdroid";
        String accessModifier = String.join(" ", accessModifierArray);

        

        String fieldNameDesc;
        if (accessModifier.contains(" static ")) {
            fieldNameDesc = fieldName + ":I";
        } else {
            fieldNameDesc = fieldName + ":I";
            if (!isTransiet) {
                accessModifier += " transient";
            }
        }

        String taintField = accessModifier + " " + fieldNameDesc;
        linesToAdd.add(0, taintField);

        if (accessModifier.contains("static")) {
            taintFieldMethods.add(".method public static getField" + fieldName + "()I");
            taintFieldMethods.add(".registers 3");
            taintFieldMethods.add("    sget v0, " + className + "->" + fieldNameDesc);
        } else {
            taintFieldMethods.add(".method public static getField" + fieldName + "(" + className + ")I");
            taintFieldMethods.add(".registers 4");
            taintFieldMethods.add("    iget v0, p0, " + className + "->" + fieldNameDesc);
        }
        taintFieldMethods.add("    if-eqz v0, :cond_2");
        taintFieldMethods.add("    const-string/jumbo v1, \"" + className + "->" + fieldName + "\"");
        taintFieldMethods.add("    invoke-static {v1}, Ljava/lang/TaintDroid;->printFieldNameGet(Ljava/lang/String;)V");
        taintFieldMethods.add("    :cond_2");
        taintFieldMethods.add("    return v0");
        taintFieldMethods.add(".end method");

        if (accessModifier.contains("static")) {
            taintFieldMethods.add(".method public static setField" + fieldName + "(I)V");
            taintFieldMethods.add(".registers 3");
            taintFieldMethods.add("    sput p0, " + className + "->" + fieldNameDesc);
            taintFieldMethods.add("    move v0, p0");
        } else {
            taintFieldMethods.add(".method public static setField" + fieldName + "(" + className + "I)V");
            taintFieldMethods.add(".registers 4");
            taintFieldMethods.add("    iput p1, p0, " + className + "->" + fieldNameDesc);
            taintFieldMethods.add("    move v0, p1");
        }

        taintFieldMethods.add("    if-eqz v0, :cond_1");
        taintFieldMethods.add("    const-string/jumbo v1, \"" + className + "->" + fieldName + "\"");
        taintFieldMethods.add("    invoke-static {v1}, Ljava/lang/TaintDroid;->printFieldNameSet(Ljava/lang/String;)V");
        taintFieldMethods.add("    :cond_1");
        taintFieldMethods.add("    return-void");
        taintFieldMethods.add(".end method");
    }

    public void analyze() {
        classAnalysis.analyze(smaliFiles);
    }


}