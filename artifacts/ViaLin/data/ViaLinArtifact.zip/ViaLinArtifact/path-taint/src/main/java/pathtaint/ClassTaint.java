package pathtaint;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.simple.*;


public class ClassTaint extends TaintAnalysis {
    
    enum ClassRegion {
        Header, StaticFields, InstanceFields, Methods
    }

    public static final List<String> twoLevelPkgs = new ArrayList<>();
    public static final List<String> threeLevelPkgs = new ArrayList<>();
    

    private String dexDir;
    private String outDir;
    private List<String> smaliFiles;
    private ClassAnalysis classAnalysis;
    private final Map<String, JSONObject> classToMethodIndexMap;
    private final String analysisDir;
    private boolean debug = false;
    private Statistics statistics;
    private boolean isFramework;


    public static Set<String> forbiddenClasses = new HashSet<>(Arrays.asList(
       "Ljava/lang/Object;", "Ljava/lang/DexCache;"
        , "Ljava/lang/String;", "Ldalvik/system/ClassExt;", 
        "[Z", "[B", "[C", "[S", "[I", "[J", "[F", "[D", "Ljava/lang/Class;", "[Ljava/lang/Class;", 
        "[Ljava/lang/Object;", "Ljava/lang/Cloneable;", "Ljava/io/Serializable;", "Ljava/lang/reflect/Proxy;", 
        "Ljava/lang/reflect/Field;", "[Ljava/lang/reflect/Field;", "Ljava/lang/reflect/Constructor;", 
        "[Ljava/lang/reflect/Constructor;", "Ljava/lang/reflect/Method;", "[Ljava/lang/reflect/Method;", 
        "Ljava/lang/invoke/MethodType;", "Ljava/lang/invoke/MethodHandleImpl;", "Ljava/lang/invoke/MethodHandles$Lookup;", 
        "Ljava/lang/invoke/CallSite;", "Ldalvik/system/EmulatedStackFrame;", "Ljava/lang/ref/Reference;", 
        "Ljava/lang/ref/FinalizerReference;", "Ljava/lang/ref/PhantomReference;", "Ljava/lang/ref/SoftReference;", 
        "Ljava/lang/ref/WeakReference;", "Ljava/lang/ClassLoader;", "Ljava/lang/Throwable;", 
        "Ljava/lang/ClassNotFoundException;", "Ljava/lang/StackTraceElement;", "[Ljava/lang/StackTraceElement;"
    ));

    // private static final Set<String> allowed = new HashSet<>(Arrays.asList(
    //     "L"));

    public static final String [] ignoreArray = {
        "Ljava/lang/Thread",
        "Ljava/lang/PathTaint",
        "[",
        "Ljava/",
        "Lsun/misc/",
        "Llibcore/",
        "Landroid/app",
        "Lorg/apache/http",
        "Ldalvik/",
        "Landroid/hidl/manager",
        "Lcom/android/providers/contacts", 
        "Landroid/app/IActivityManager",
        "Landroid/os/BatteryStats",
        "Lcom/android/server/power",
        "Lcom/android/internal/telephony",
        "Lcom/android/commands/",
        "Lcom/android/internal/",
        "Lcom/android/messaging/",
        "Lcom/android/providers/",
        "Lcom/android/phone/",
        "Lcom/android/server/", 
        "Landroid/os", // caused boot to fail
        "Lsun/misc/Unsafe",
        "Lsun/", 
        "Landroid/system/", // caused boot to fail

        // may caused dex2oat crash
        "Landroid/R",
        "Landroid/Manifest",
        "Landroid/util",
        "Landroid/icu/",
        "Landroid/provider",
        "Landroid/nfc",
        "Landroid/printservice",
        "Landroid/Rsssssss",
        "Landroid/inputmethodservice",
        "Landroid/print",
        "Landroid/preference",
        "Landroid/graphics",
        "Landroid/database",
        "Landroid/gesture",
        "Landroid/service",
        "Landroid/telecom",
        "Landroid/net",
        "Landroid/sax",
        "Landroid/bluetooth",
        "Landroid/accounts",
        "Landroid/accessibilityservice",
        "Landroid/ddm",
        "Landroid/content",
        "Landroid/transition",
        "Landroid/mtp",
        "Landroid/companion",
        "Lcom/auth0/jwt",


        // Trying to taint


         // OK to taint

        "Ljavax/", 
        "Ljunit/", 
        "Lgov/", 
        "Ljdk/", 
        "Lcom/google/", 
        "Lcom/facebook/", 
        "Lcom/chartboost/" , 
        "Lcom/bumptech/", 
        "Lcom/adobe/", 
        "Lcom/samsung/", 
        "Lcom/e/a/", 
        "Lit/octotelematics/ifc/ui/IFCDashboardActivity", 
        "Lch/qos/", 
        "Lio/fabric/", 
        "Lbolts/", 
        "Lfreemarker/core/", 
        "Lorg/apache/http",
        "Lorg/kxml2/io/",
        "Lorg/apache/",
        "Lorg/w3c/",
        "Lorg/xml/",
        "Lorg/xmlpull/",
        "Lorg/json/",
        "Lorg/ccil/",
        "Lorg/android/",
        "Lorg/junit/",
        "Lorg/chromium/",
        "Lorg/owasp/html/",
        "Lorg/hamcrest/",
        "Lorg/tukaani/xz/",

        "Lorg/apache/harmony/",
        "Lorg/w3c/dom/",
        "Lorg/xml/sax/",

        "Lorg/xmlpull/v1/",
        "Lorg/json/",
        "Lorg/ccil/cowan/",
        "Lorg/android/btsap/",
        "Lorg/junit/",

        "Lorg/chromium/webview_shell/",
        "Lorg/owasp/html/",
        "Lorg/apache/commons/",
        "Lorg/apache/james/",
        "Lorg/apache/xml/",
        "Lorg/apache/xalan/",
        "Lorg/apache/xpath/",
        "Lorg/hamcrest/",
        "Lorg/tukaani/xz/",

        "Lorg/apache/", 
        "Lorg/xml/sax", 
        "Lorg/w3c", 
        "Lorg/xmlpull",
        "Lorg/apache/", 
        "Lorg/xml/sax", 
        "Lorg/w3c", 
        "Lcom/sun", 
        "Lorg/xmlpull",
        "Landroid/test/",
        "Landroid/media/",
        "Landroid/text",
        "Landroid/location",
        "Landroid/animation",
        "Landroid/security",
        "Landroid/drm",
        "Landroid/metrics",
        "Landroid/speech",
        "Landroid/telephony",
        "Landroid/annotation",
        "Landroid/view",
        "Landroid/opengl",
        "Landroid/filterpacks",
        "Landroid/permissionpresenterservice",
        "Landroid/widget",
        "Landroid/webkit",
        "Landroid/renderscript",
        "Landroid/filterfw",
        "Landroid/hardware",
        "Landroid/hidl",

        "Landroid/support",
        // "Lokhttp3/",
        "Lokio/", 
        "Lcom/auth0/jwt/internal/com/fasterxml/jackson/databind/ser/BasicSerializerFactory;" ,
        "Lkotlin",
        "Lcom/echangecadeaux/ui/ViewInfoExchangeMod",
        "Lcom/bugsnag/android/",
        "Lcz/msebera/android/",
        "Lio/reactivex/", 
        "Lio/realm/",
        "Ljumio/",
        "Lcom/jeremyfeinstein/slidingmenu/lib/",
        "Lcom/slidingmenu/lib/"
    };

    private static final Set<String> ignoreClass = new HashSet<>(Arrays.asList(ignoreArray)); 
    private static final Set<String> ignore = new HashSet<>(Arrays.asList(ignoreArray));
    private static final boolean TAINT_FIELDS = true;
    private static final boolean TAINT_METHODS = true;



    public ClassTaint(String dexDir, List<String> smaliFiles, String analysisDir, boolean isFramework, String outDir) {
        this.smaliFiles = smaliFiles;
        this.dexDir = dexDir;
        this.classAnalysis = new ClassAnalysis(analysisDir);
        this.classToMethodIndexMap = new HashMap<>();
        this.analysisDir = analysisDir;
        this.statistics = new Statistics();
        this.isFramework = isFramework;
        this.outDir = outDir;
    }

    private boolean isAllowed(String className) {
        return true;
        // for (String c : allowed) {
        //     if (className.startsWith(c)) {
        //         return true;
        //     }
        // }
        // return false;
    }


    private boolean isIgnored(Set<String> classNames) {

        // System.out.printf("     Checking if %s is ignored%n", classNames);
        for (String className : classNames) {
            if (className.startsWith("[")) { // TODO: remove
                // System.out.printf("         Yes-1%n");
                return true;
            }
            for (String c : ignore) {
                if (className.startsWith(c)) {
                    // System.out.printf("         Yes-2%n");
                    return true;
                }
            }
        }
        // System.out.printf("         No%n");
        return false;
    }

    private boolean isIgnored(String className) {

        if (className.startsWith("[")) { // TODO: remove
            return true;
        }
        for (String c : ignore) {
            if (className.startsWith(c)) {
                return true;
            }
        }


        return false;
    }

    private boolean isIgnoredClass(String className) {
        // for (String c : allowed) {
        //     if (className.startsWith(c)) {
        //         return false;
        //     }
        // }
        for (String c : ignoreClass) {
            if (className.startsWith(c)) {
                return true;
            }
        }
        return false;
    }

    public void addTaint() {
        for (String file : smaliFiles) {
            // ClassInfo classInfo = ClassInfo.getClassInfo(file);
            addTaintToClassFile(file, null);
        }
        if (!smaliFiles.isEmpty()) {
            saveDexInfo();
        }
        statistics.print();
    }

    private void addTaintToClassFile(String file, ClassInfo classInfo) {

        if (isFramework) { // TODO: remove if tainting framework
            return;
        }

        List<String> classLines;
        try {
            classLines = Files.readAllLines(Paths.get(file));
        } catch (IOException e) {
            throw new Error("Cannot open class file: " + file);
        }

        String className = getLastToken(classLines.get(0));

        
        // if (className.equals("Ljava/lang/PathTaint;") || className.equals("Ljava/lang/Object;") || className.equals("Ljava/lang/Class;")) {
        //     return;
        // }
        // if (className.equals("Ljava/util/Date;") || className.startsWith("Ljava/net")) {
        // } else if (className.startsWith("L")) {
        //     return;
        // }


        if (className.equals("Ljava/lang/PathTaint;")) {
            return;
        }

        if (forbiddenClasses.contains(className) || isIgnoredClass(className)) {
            // System.out.println("Ignored class: " + className);
            // String[] pkgSplit = className.split("/");
            // if (pkgSplit.length > 1) {
                String threeLevelPkg = className;
                // String threeLevelPkg = pkgSplit[0] + "/" + pkgSplit[1] + "/" + pkgSplit[2]+ "/" + pkgSplit[3];
                if (!threeLevelPkgs.contains(threeLevelPkg)) {
                    threeLevelPkgs.add(threeLevelPkg);
                }
            // }
            return;
        }

        // System.out.println("Tainted class: " + className);
        String[] pkgSplit = className.split("/");
        if (pkgSplit.length > 1) {
            String twoLevelPkg = pkgSplit[0] + "/" + pkgSplit[1];
            if (!twoLevelPkgs.contains(twoLevelPkg)) {
                twoLevelPkgs.add(twoLevelPkg);
            }
        }

        JSONObject classIndex = new JSONObject();
        classToMethodIndexMap.put(className, classIndex);

        MethodInfo methodInfo = null;
        Integer taintTempReg = null;
        Integer signatureRegister = null;
        Integer timerRegister = null;
        Integer maxRegs = 0;
        Integer methodDelta = 0;
        List<String> taintedClassLines = new ArrayList<>();
        List<String> taintFieldMethods = new ArrayList<>();
        Map<Integer, Integer> newParams = new HashMap<>();
        Map<String, String> taintRegMap = new HashMap<>();
        Set<String> taintedMethods = new HashSet<>();
        Map<String, FieldAccessInfo> fieldArraysInMethod = new HashMap<>();

        boolean instrument = true;
        boolean inAnnon = false;
        Stack<String> tryCatches = new Stack<>();
        String lastCalled = null;
        JSONObject methodIndex = null;

        for (int lineNum = 0; lineNum < classLines.size(); lineNum++) {
            
            String line = classLines.get(lineNum);
            List<String> linesToAdd = new ArrayList<>();
            linesToAdd.add(line);

            
            if (line.trim().startsWith(".annotation")) {
                inAnnon = true;
            }
            if (line.trim().startsWith(".end annotation")) {
                inAnnon = false;
            }
            if (line.startsWith("    :try_start")) {
                tryCatches.push(line);
            }
            if (line.startsWith("    :try_end")) {
                tryCatches.pop();
            }


            if (instrument && !inAnnon) { 

                if (line.isEmpty()) {
                    // pass
                } else if (line.startsWith(".field")) {
                    if (TAINT_FIELDS && !forbiddenClasses.contains(className) && ! isIgnored(className)) {
                        addTaintField(linesToAdd, line, className, taintFieldMethods);
                    }
                } else if (line.startsWith("    invoke")) {
                    methodDelta++;
                    methodIndex.put(methodDelta, line);
                    linesToAdd.clear();
                    line = changeParamsToLocals(newParams, line, taintTempReg);
                    linesToAdd.add(line);

                    int newMaxRegs = injectTaintSink(line, linesToAdd, methodInfo, taintTempReg+1, taintRegMap, signatureRegister, methodDelta, className);
                    maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                    taintTempReg = maxRegs;
                    if (!line.startsWith("    invoke-polymorphic")) { // TODO: model poly too and remove this if
                        newMaxRegs = addTaintToCallParams(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg+1, taintRegMap, signatureRegister, methodDelta, taintedClassLines, className);
                        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                        taintTempReg = maxRegs;
                        lastCalled = line;
                    }

                    newMaxRegs = injectTaintSeedByReflection(line, linesToAdd, methodInfo, taintTempReg+1, signatureRegister, methodDelta, className, taintFieldMethods, lineNum, classLines, taintRegMap);
                    maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                    taintTempReg = maxRegs;
                } else if (line.startsWith("    .registers")) {
                    addTaintRegisters(line, linesToAdd, methodInfo);
                    int firstTaintReg = methodInfo.getBaseNumRegs();

                    signatureRegister = firstTaintReg + methodInfo.getNumBaseLocalRegs() + methodInfo.getNumBaseParams() + 1;
                    timerRegister = signatureRegister + 1;
                    taintTempReg = timerRegister + 2;
                    maxRegs = taintTempReg + 2;

                    // if (!isFramework) {
                    //     addStartTimer(linesToAdd, timerRegister, taintTempReg, methodInfo);
                    // }
                    

                    for (int i = 0; i < methodInfo.getBaseNumRegs() + 1; i++) {
                        taintRegMap.put("v" + i, "v" + String.valueOf(firstTaintReg + i));
                    }

                    String v0MoveInstruction = null;
                    String regToUseForInit = "v0";

                    for (int i = 0; i < methodInfo.getParams().size(); i++ ) {
                        
                        String paramType = methodInfo.getParams().get(i);
                        int paramReg = methodInfo.getNumBaseLocalRegs() + i;

                        newParams.put(i, paramReg);

                        String moveInstruction = getMoveInstructionByType(paramType);

                        if (moveInstruction != null) {
                            linesToAdd.add("    " + moveInstruction + " v" + paramReg + ", p" + i);
                            
                            if (paramReg == getRegNumFromRef(regToUseForInit)) {
                                v0MoveInstruction = moveInstruction;
                            }
                        }
                    }

                    

                    boolean alreadyMovedV0 = false;

                    // if (TAINT_METHODS && !forbiddenClasses.contains(className) && !isIgnored(classAnalysis.getClassOfMethod(methodInfo.getClassName(), methodInfo.getNameAndDesc())) && !methodInfo.getNameAndDesc().equals("<init>()V")) { // TODO: remove the "on"  && !methodInfo.getMethodName().startsWith("on") && !methodInfo.getDesc().equals("(Landroid/view/View;)V") 
                        // move taint params to taint regs
                        if (v0MoveInstruction != null) {
                            linesToAdd.add("    " + v0MoveInstruction + " v" + taintTempReg + ", " + regToUseForInit);
                            alreadyMovedV0 = true;
                        }
                        for (int i = 0; i < methodInfo.getParams().size(); i++) {
                            int paramReg = methodInfo.getNumBaseLocalRegs() + i;
                            linesToAdd.add("    invoke-static {}, Ljava/lang/Thread;->getParamTaint" + i + "()Ljava/lang/PathTaint;");
                            linesToAdd.add("    move-result-object " + regToUseForInit);
                            linesToAdd.add("    move-object/16 " + taintRegMap.get("v"+paramReg) + ", " + regToUseForInit);
                            taintRegMap.put("p" + i, taintRegMap.get("v"+paramReg));
                        }

                        if (methodInfo.getNameAndDesc().startsWith("createFromParcel(Landroid/os/Parcel;)")) {
                            int firstParamReg = methodInfo.getNumBaseLocalRegs() + 1;
                            linesToAdd.add("    move-object/16 " + regToUseForInit + ", " + taintRegMap.get("v"+firstParamReg));
                            linesToAdd.add("    invoke-static {" + regToUseForInit + "}, Ljava/lang/PathTaint;->getReturnTaint(Ljava/lang/PathTaint;)V");
                        }

                        int paramReg = methodInfo.getNumBaseLocalRegs() + methodInfo.getParams().size();
                        
                        linesToAdd.add("    new-instance " + regToUseForInit + ", Ljava/lang/PathTaint;");
                        linesToAdd.add("    invoke-direct {" + regToUseForInit + "}, Ljava/lang/PathTaint;-><init>()V");
                        linesToAdd.add("    move-object/16 " + taintRegMap.get("v"+paramReg) + ", " + regToUseForInit);



                        if (paramReg == getRegNumFromRef(regToUseForInit)) {
                            v0MoveInstruction = "move-object/16";
                        }
                    // } 
                    // else {
                    //     for (int i = 0; i < methodInfo.getParams().size(); i++) {
                    //         int paramReg = methodInfo.getNumBaseLocalRegs() + i;
                    //         eraseTaintV0(regToUseForInit, taintTempReg, linesToAdd, taintRegMap.get("v"+paramReg));
                    //         taintRegMap.put("p" + i, taintRegMap.get("v"+paramReg));
                    //     }
                    //     int paramReg = methodInfo.getNumBaseLocalRegs() + methodInfo.getParams().size();
                    //     eraseTaintV0(regToUseForInit,taintTempReg, linesToAdd, taintRegMap.get("v"+paramReg));
                    //     if (v0MoveInstruction != null) {
                    //         linesToAdd.add("    " + v0MoveInstruction + " v" + taintTempReg + ", " + regToUseForInit);
                    //         alreadyMovedV0 = true;
                    //     }
                    //     linesToAdd.add("    new-instance " + regToUseForInit + ", Ljava/lang/PathTaint;");
                    //     linesToAdd.add("    invoke-direct {"+regToUseForInit+"}, Ljava/lang/PathTaint;-><init>()V");
                    //     linesToAdd.add("    move-object/16 " + taintRegMap.get("v"+paramReg) + ", "+regToUseForInit);
                    // }

                    // Init taint registers, must be done after moving parameters
                    if (v0MoveInstruction != null && !alreadyMovedV0) {
                        linesToAdd.add("    " + v0MoveInstruction + " v" + taintTempReg + ", "+regToUseForInit);
                    }

                    linesToAdd.add("    const-string/jumbo "+regToUseForInit+", \"" + methodInfo.signature() + "\"");
                    linesToAdd.add("    move-object/16 " + "v" + String.valueOf(signatureRegister) + ", "+regToUseForInit);

                    // linesToAdd.add("    invoke-static {" + regToUseForInit + "}, Ljava/lang/PathTaint;->printMethodName(Ljava/lang/String;)V");


                    for (int i = 0; i < methodInfo.getNumBaseLocalRegs(); i++) {
                        linesToAdd.add("    new-instance "+regToUseForInit+", Ljava/lang/PathTaint;");
                        linesToAdd.add("    invoke-direct {"+regToUseForInit+"}, Ljava/lang/PathTaint;-><init>()V");
                        linesToAdd.add("    move-object/16 " + "v" + String.valueOf(firstTaintReg + i) + ", "+regToUseForInit);
                    }
                    if (TAINT_METHODS && !forbiddenClasses.contains(className) && !isIgnored(classAnalysis.getClassOfMethod(methodInfo.getClassName(), methodInfo.getNameAndDesc())) && !methodInfo.getNameAndDesc().equals("<init>()V")) { // TODO: remove the "on" && !methodInfo.getMethodName().startsWith("on")  && !methodInfo.getDesc().equals("(Landroid/view/View;)V")
                    } else {
                        for (int i = methodInfo.getNumBaseLocalRegs(); i < methodInfo.getBaseNumRegs(); i++) {
                            linesToAdd.add("    new-instance "+regToUseForInit+", Ljava/lang/PathTaint;");
                            linesToAdd.add("    invoke-direct {"+regToUseForInit+"}, Ljava/lang/PathTaint;-><init>()V");
                            linesToAdd.add("    move-object/16 " + "v" + String.valueOf(firstTaintReg + i) + ", "+regToUseForInit);
                        }
                    }
                    if (v0MoveInstruction != null) {
                        linesToAdd.add("    " + v0MoveInstruction + " "+regToUseForInit+", v" + taintTempReg);
                    }

                    if (methodInfo.getNameAndDesc().equals("doInBackground([Ljava/lang/Object;)Ljava/lang/Object;")) {
                        String targetTaintReg = taintRegMap.get("p1");
                        linesToAdd.add("    invoke-static {}, Ljava/lang/Thread;->getAsyncTaskParam()Ljava/lang/PathTaint;");
                        linesToAdd.add("    move-result-object " + targetTaintReg);
                    } else if (methodInfo.getNameAndDesc().equals("invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;")) {
                        String targetTaintReg = taintRegMap.get("p3");
                        if(methodInfo.isStatic()) {
                            targetTaintReg = taintRegMap.get("p2");
                        }
                        linesToAdd.add("    invoke-static {}, Ljava/lang/Thread;->getAsyncTaskParam()Ljava/lang/PathTaint;");
                        linesToAdd.add("    move-result-object " + targetTaintReg);
                    } else if (methodInfo.getNameAndDesc().equals("handleMessage(Landroid/os/Message;)V")) {
                        String targetTaintReg = taintRegMap.get("p1");
                        linesToAdd.add("    invoke-static {}, Ljava/lang/Thread;->getAsyncTaskParam()Ljava/lang/PathTaint;");
                        linesToAdd.add("    move-result-object " + targetTaintReg);
                    }
                    

                } else if (line.startsWith(".method")) {
                    if (!line.contains(" native ")) {
                        methodInfo = getMethodInfo(className, line);
                        // boolean taintedMethod = addTaintToMethodParams(line, linesToAdd, methodInfo);
                        // if (taintedMethod) {
                        //     taintedMethods.add(methodInfo.signature());
                        // }
                    }
                    fieldArraysInMethod = new HashMap<>();
                    methodDelta = 0;
                    methodIndex = new JSONObject();
                } else if (line.startsWith(".end method")) {
                    if (methodInfo != null) {
                        classIndex.put(methodInfo.getNameAndDesc(), methodIndex);
                    }

                    methodInfo = null;
                    lastCalled = null;
                    fixRegisterLine(taintedClassLines, maxRegs);
                } else if (methodInfo != null) {
                    String instruction = getToken(line, 0);
                    if (instruction.startsWith(".")) {
                    } else if (instruction.startsWith(":")) {
                    } else if (instruction.startsWith("0x")) {
                    } else if (instruction.startsWith("-")) {
                    } else {

                        methodDelta++;
                        methodIndex.put(methodDelta, line);

                        linesToAdd.clear();

                        line = changeParamsToLocals(newParams, line, taintTempReg);

                        linesToAdd.add(line);

                        if (isNop(instruction)) {
                            // pass
                        } else if (isMove(instruction) || isMoveFrom16(instruction) || isMove16(instruction) || 
                            isMoveWide(instruction) || isMoveWideFrom16(instruction) || isMoveWide16(instruction) ||
                            isMoveObject(instruction) || isMoveObjectFrom16(instruction) || isMoveObject16(instruction)) {

                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);
                            maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;
                            if (targetIsWide(instruction)) {
                                maxRegs = addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                                taintTempReg = maxRegs;
                            }
                            fieldArraysInMethod.remove(targetReg);
                        } else if (isMoveResult(instruction) || isMoveResultWide(instruction) || isMoveResultObject(instruction)) {

                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);
                            
                            // System.out.println("Lines to add became-1: " + linesToAdd);
                            maxRegs = addGetReturnTaint(taintTempReg, maxRegs, linesToAdd, taintTargReg, targetReg, instruction);
                            maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, taintTargReg);
                            taintTempReg = maxRegs;

                            int newMaxRegs = injectTaintSeed(lastCalled, linesToAdd, methodInfo, taintTempReg+1, taintTargReg, signatureRegister, methodDelta, className, taintFieldMethods);
                            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                            taintTempReg = maxRegs;
                            
                            if (targetIsWide(instruction)) {
                                maxRegs = addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                                taintTempReg = maxRegs;
                            }
                            // System.out.println("Lines to add became-2: " + linesToAdd);
                            // System.out.println("--------------------------------------");
                            lastCalled = null;
                            fieldArraysInMethod.remove(targetReg);
                        } else if (isMoveException(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            maxRegs = addGetExceptionTaint(taintTempReg, maxRegs, linesToAdd, taintTargReg, targetReg, instruction);
                            maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, taintTargReg);
                            taintTempReg = maxRegs;
                        } else if (isReturnVoid(instruction)) {
                            // pass
                            // if (!isFramework) {
                            //     maxRegs = addEndTimer(linesToAdd, timerRegister, signatureRegister, methodInfo, taintTempReg, maxRegs);
                            //     taintTempReg = maxRegs;
                            // }
                        } else if (isReturn(instruction) || isReturnWide(instruction) || isReturnObject(instruction)) {
                            
                            int newMaxRegs = handleReturn(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister);
                            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                            taintTempReg = maxRegs;
                            
                            // if (!isFramework) {
                            //     maxRegs = addEndTimer(linesToAdd, timerRegister, signatureRegister, methodInfo, taintTempReg, maxRegs);
                            //     taintTempReg = maxRegs;
                            // }
                        } else if (isConst4(instruction) || isConst16(instruction) || isConst(instruction) || isConstHigh16(instruction) || 
                                isConstWide16(instruction) || isConstWide32(instruction) || isConstWide(instruction) || isConstWideHigh16(instruction) ||
                                isConstString(instruction) || isConstStringJumbo(instruction) || isConstClass(instruction)) {
                                    String targetReg = getRegReference(line, 1);
                                    String taintTargReg = taintRegMap.get(targetReg);
                                    maxRegs = addEraseTaint(taintTempReg, maxRegs, linesToAdd, targetReg, taintTargReg, signatureRegister);
                                    taintTempReg = maxRegs;
                                    fieldArraysInMethod.remove(targetReg);
                        } else if (isMonitorEnter(instruction) || isMonitorExit(instruction)) {
                            // pass
                        } else if (isCheckCast(instruction)) {
                            // pass
                        } else if (isInstanceOf(instruction) || isArrayLength(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);
                            linesToAdd.add("    move-object/16 " + taintTargReg + ", " + taintSrcReg);
                            fieldArraysInMethod.remove(targetReg);
                        } else if (isNewInstance(instruction) || isNewArray(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);
                            maxRegs = addEraseTaint(taintTempReg, maxRegs, linesToAdd, targetReg, taintTargReg, signatureRegister);
                            taintTempReg = maxRegs;
                            fieldArraysInMethod.remove(targetReg);
                        } else if (isFilledNewArray(instruction) || isFilledNewArrayRange(instruction) || isFillArrayData(instruction)) {
                            // pass 
                            // TODO: handle arrays
                        } else if (isThrow(instruction)) {
                            
                            // TODO: Change this hande return to handleThrow, must add setThrowTaint and getThrowTaint
                            int newMaxRegs = handleThrow(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister);
                            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                            taintTempReg = maxRegs;

                            // if (!isFramework) {
                            //     maxRegs = addEndTimer(linesToAdd, timerRegister, signatureRegister, methodInfo, taintTempReg, maxRegs);
                            //     taintTempReg = maxRegs;
                            // }
                        } else if (isGoto(instruction) || isGoto16(instruction) || isGoto32(instruction)) {
                            // pass
                        } else if (isPackedSwitch(instruction) || isSparseSwitch(instruction)) {
                            // pass
                        } else if (isCmpkind(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);
                            maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;
                            fieldArraysInMethod.remove(targetReg);
                        } else if (isIfTest(instruction) || isIfTestz(instruction)) {
                            // pass
                        } else if (isArrayOp(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);


                            if (instruction.startsWith("aput")) {
                                String temp = taintTargReg;
                                taintTargReg = taintSrcReg;
                                taintSrcReg = temp;
                                maxRegs = handleTwoSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                    line, linesToAdd, instruction, signatureRegister, taintTargReg, taintTargReg, taintSrcReg);
                                taintTempReg = maxRegs;

                                // Multidimensioanl arrays
                                String prevLine = classLines.get(lineNum-2);
                                String prevInstruction = getToken(prevLine, 0);
                                if (prevInstruction.startsWith("aget")) {
                                    if (getRegReference(line, 2).equals(getRegReference(prevLine, 1))) {
                                        maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                            line, linesToAdd, instruction, signatureRegister, taintRegMap.get(getRegReference(prevLine, 2)), taintTargReg);
                                        taintTempReg = maxRegs;
                                    }
                                }

                                // Static arrays
                                if (fieldArraysInMethod.containsKey(srcReg)) { // srcReg is not the source, but it's the destination array object
                                    // System.out.format("Will fill in array for instruction %s at method %s%n", line, methodInfo.signature());
                                    FieldAccessInfo fieldAccessInfo = fieldArraysInMethod.get(srcReg);
                                    if (fieldAccessInfo.refType.equals("Static")) {
                                        maxRegs = taintSetStaticField(taintTempReg, maxRegs, lineNum, linesToAdd, signatureRegister, fieldAccessInfo.fieldName,
                                            fieldAccessInfo.taintTargReg, fieldAccessInfo.whereIsField);
                                        taintTempReg = maxRegs;
                                    } 
                                    // else if (fieldAccessInfo.refType.equals("Instance")) {
                                    //     maxRegs = taintSetInstanceField(taintTempReg, maxRegs, lineNum, linesToAdd, signatureRegister, fieldAccessInfo.fieldName, fieldAccessInfo.taintTargReg, fieldAccessInfo.baseRegRef, fieldAccessInfo.whereIsField);
                                    //     taintTempReg = maxRegs;
                                    // }
                                }

                            } else {
                                maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                    line, linesToAdd, instruction, signatureRegister, taintTargReg, taintSrcReg);
                                taintTempReg = maxRegs;
                            }



                            
                            if (targetIsWide(instruction)) {
                                maxRegs = addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                                taintTempReg = maxRegs;
                            }
                            fieldArraysInMethod.remove(targetReg);
                        } else if (isIinstanceOp(instruction)) {
                            int newMaxRegs = handleIinstanceOp(methodInfo, taintTempReg, maxRegs, taintRegMap, fieldArraysInMethod, methodDelta,
                                line, linesToAdd, instruction, signatureRegister);
                            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                            taintTempReg = maxRegs;
                        } else if (isSstaticOp(instruction)) {
                            int newMaxRegs = handleSstaticOp(methodInfo, taintTempReg, maxRegs, taintRegMap, fieldArraysInMethod, methodDelta,
                                    line, linesToAdd, instruction, signatureRegister);
                            maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                            taintTempReg = maxRegs;
                        } else if (isInvokeKind(instruction) || isInvokeKindRange(instruction) || 
                            isInvokePolymorphic(instruction) || isInvokePolymorphicRange(instruction) || 
                            isInvokeCustom(instruction) || isInvokeCustomRange(instruction)) {
                            throw new Error("Invokes are handled in a separate branch");
                        } else if (isUnOp(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);
                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);

                            maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;
                            if (targetIsWide(instruction)) {
                                maxRegs = addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                                taintTempReg = maxRegs;
                            }
                            fieldArraysInMethod.remove(targetReg);
                        } else if (isBinOp(instruction)) {
                            String taintTargReg = taintRegMap.get(getRegReference(line, 1));
                            String firstTaintSrcReg = taintRegMap.get(getRegReference(line, 2));
                            String secondTaintSrcReg = taintRegMap.get(getRegReference(line, 3));

                            maxRegs = handleTwoSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, firstTaintSrcReg, secondTaintSrcReg);
                            taintTempReg = maxRegs;
                            if (targetIsWide(instruction)) {
                                maxRegs = addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                                taintTempReg = maxRegs;
                            }
                            fieldArraysInMethod.remove(getRegReference(line, 1));
                        } else if (isBinOp2addr(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);
                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);
                            
                            maxRegs = handleTwoSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;

                            if (targetIsWide(instruction)) {
                                maxRegs = addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                                taintTempReg = maxRegs;
                            }
                            fieldArraysInMethod.remove(targetReg);
                        } else if (isBinOpLit16(instruction) || isBinOpLit8(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);

                            String srcReg = getRegReference(line, 2);
                            String taintSrcReg = taintRegMap.get(srcReg);
                            maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintSrcReg);
                            taintTempReg = maxRegs;

                            if (targetIsWide(instruction)) {
                                maxRegs = addCopyTaint(taintTempReg, maxRegs, linesToAdd, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), signatureRegister, taintTargReg);
                                taintTempReg = maxRegs;
                            }
                            fieldArraysInMethod.remove(targetReg);
                        } else if (isConstMethodHandle(instruction) || isConstMethodType(instruction)) {
                            String targetReg = getRegReference(line, 1);
                            String taintTargReg = taintRegMap.get(targetReg);
                            maxRegs = addEraseTaint(taintTempReg, maxRegs, linesToAdd, targetReg, taintTargReg, signatureRegister);
                            taintTempReg = maxRegs;
                            fieldArraysInMethod.remove(targetReg);
                        } else {
                            throw new Error("Invalid instruction: " + line);
                        }
                    }
                }
            }
            taintedClassLines.addAll(linesToAdd);
        }

        for (int lineNum = 0; lineNum < classLines.size(); lineNum++) {
            String line = classLines.get(lineNum);
            if (line.startsWith(".method")) {
                if (!line.contains(" native ") && line.contains(" abstract ") ) {
                    methodInfo = getMethodInfo(className, line);
                    if (!taintedMethods.contains(methodInfo.signature())) {
                        methodInfo = null;
                    } else {
                        taintedClassLines.add(line);
                    }
                }
            } else if (methodInfo != null) {
                taintedClassLines.add(line);
                if (line.startsWith(".end method")) {
                    methodInfo = null;
                }
            }
        }

        taintedClassLines.addAll(taintFieldMethods);

        try {
            Files.write(Paths.get(file), taintedClassLines);
        } catch (IOException e) {
            throw new Error("Cannot modify class file: " + file);
        }
    }


    private int addEndTimer(List<String> linesToAdd, Integer timerRegister, Integer signatureRegister, MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs) {
        if (methodInfo.getMethodName().startsWith("on") || methodInfo.getDesc().equals("(Landroid/view/View;)V") || methodInfo.getMethodName().startsWith("doInBackground") || methodInfo.getNameAndDesc().equals("run()V")) {
            String newLine = "    invoke-static {v" + signatureRegister + ", v" + timerRegister + ", v" + String.valueOf(timerRegister + 1) + "}, Ljava/lang/PathTaint;->endTime(Ljava/lang/String;J)V";
            Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd.addAll(linesToAdd.size() - 1, rangedInvoke.first);
            int newMaxRegs = rangedInvoke.second;
            return (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        }
        return maxRegs;
    }

    private void addStartTimer(List<String> linesToAdd, Integer timerRegister, Integer taintTempReg, MethodInfo methodInfo) {
        if (methodInfo.getMethodName().startsWith("on") || methodInfo.getDesc().equals("(Landroid/view/View;)V") || methodInfo.getMethodName().startsWith("doInBackground") || methodInfo.getNameAndDesc().equals("run()V")) {
            String p0Move = null;
            String p1Move = null;
            if (methodInfo.getNumBaseLocalRegs() < 2) {
                if (methodInfo.getNumBaseParams() > 0) {
                    p0Move = getMoveInstructionByType(methodInfo.getParams().get(0));
                }
                if (methodInfo.getNumBaseParams() > 1) {
                    p1Move = getMoveInstructionByType(methodInfo.getParams().get(1));
                }
            }
            if (p0Move != null) {
                linesToAdd.add("    " + p0Move + " v" + taintTempReg + ", p0");
                if (p0Move != null && methodInfo.getNumBaseParams() > 1 && !p0Move.contains("wide") && p1Move != null) {
                    linesToAdd.add("    " + p1Move + " v" + String.valueOf(taintTempReg+1) + ", p1");
                }
            }
            linesToAdd.add("    invoke-static {}, Ljava/lang/System;->nanoTime()J");
            linesToAdd.add("    move-result-wide v0");
            linesToAdd.add("    move-wide/16 v" + timerRegister + ", v0");
            if (p0Move != null) {
                linesToAdd.add("    " + p0Move + " p0, v" + taintTempReg);
                if (p0Move != null && methodInfo.getNumBaseParams() > 1 && !p0Move.contains("wide") && p1Move != null) {
                    linesToAdd.add("    " + p1Move + " p1, v" + String.valueOf(taintTempReg+1));
                }
            }
        }
    }

    private void saveDexInfo() {
        saveDexInfoToDir(analysisDir);
        saveDexInfoToDir(outDir);
    }

    private void saveDexInfoToDir(String dir) throws Error {
        File infoDir = new File(dir, "class_info");
        if (!infoDir.isDirectory()) {
            infoDir.mkdirs();
        }
        for (Map.Entry<String, JSONObject> entry: classToMethodIndexMap.entrySet()) {
            String className = entry.getKey();
            JSONObject classInfo = entry.getValue();
            String unixClassName = className.replace("/", "_").replace(";", "") + ".json";
            File classFile = new File(infoDir, unixClassName);
            try {
                FileWriter fileWriter = new FileWriter(classFile);
                fileWriter.write(classInfo.toJSONString());
                fileWriter.flush();
                fileWriter.close();
            } catch (IOException e) {
                throw new Error("Cannot save class ifno: " + classFile);
            }
        }
    }


    private void eraseTaint(Integer taintTempReg, List<String> linesToAdd, String targetReg, String taintTargReg, String moveInstruction) {
        if (getRegNumFromRef(taintTargReg) < 256) {
            linesToAdd.add("    const/16 " + taintTargReg + ", 0");
        } else {
            linesToAdd.add("    " + moveInstruction + " v" + taintTempReg + ", " + targetReg);
            linesToAdd.add("    const/16 " + targetReg + ", 0");
            linesToAdd.add("    move/16 " + taintTargReg + ", " + targetReg);
            linesToAdd.add("    " + moveInstruction + " " + targetReg + ", v" + taintTempReg);
        }
    }


    private void eraseTaintV0(String regToErase, Integer taintTempReg, List<String> linesToAdd, String taintTargReg) {
        if (getRegNumFromRef(taintTargReg) < 256) {
            linesToAdd.add("    const/16 " + taintTargReg + ", 0");
        } else {
            linesToAdd.add("    const/16 " + regToErase + ", 0");
            linesToAdd.add("    move/16 " + taintTargReg + ", " + regToErase);
        }
    }

    private Integer handleOneSourceOneDest(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
            Map<String, String> taintRegMap, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister, String destTaintReg, String srcTaintReg) {
        maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, destTaintReg, signatureRegister, srcTaintReg);
        maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, destTaintReg);
        return maxRegs;
    }

    private Integer handleTwoSourceOneDest(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
            Map<String, String> taintRegMap, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister, 
            String destTaintReg, String firstSrcTaintReg, String secondSrcTaintReg) {
        maxRegs = addCreateTaintWithLeftRight(taintTempReg, maxRegs, linesToAdd, destTaintReg, signatureRegister, firstSrcTaintReg, secondSrcTaintReg);
        maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, destTaintReg);
        return maxRegs;
    }


    private Integer handleReturn(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
        Map<String, String> taintRegMap, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister) {


        linesToAdd.clear();
        String taintTargReg = taintRegMap.get(getRegReference(line, 1));
        maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister, taintTargReg);
        maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, taintTargReg);
        maxRegs = addSetReturnTaint(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister);
        linesToAdd.add(line);
        return maxRegs;
    }

    private Integer handleThrow(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
        Map<String, String> taintRegMap, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister) {


        linesToAdd.clear();
        String taintTargReg = taintRegMap.get(getRegReference(line, 1));
        maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister, taintTargReg);
        maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, taintTargReg);
        maxRegs = addSetThrowTaint(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister);
        linesToAdd.add(line);
        return maxRegs;
    }


    private Integer addEraseTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String targetReg, String taintTargReg, int signatureRegister) {
        if (getRegNumFromRef(taintTargReg) < 256) {
            linesToAdd.add(0, "    invoke-static {}, Ljava/lang/PathTaint;->newInstance()Ljava/lang/PathTaint;");
            linesToAdd.add(1, "    move-result-object " + taintTargReg);
        } else {
            linesToAdd.add(0, "    invoke-static {}, Ljava/lang/PathTaint;->newInstance()Ljava/lang/PathTaint;");
            linesToAdd.add(1, "    move-result-object " + targetReg);
            linesToAdd.add(2, "    move-object/16 " + taintTargReg + ", " + targetReg);
        }

        // linesToAdd.add("    invoke-static {}, Ljava/lang/PathTaint;->newInstance()Ljava/lang/PathTaint;");
        // linesToAdd.add("    move-result-object " + taintTargReg);

        return maxRegs;
    }

    private Integer addCopyTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister, String taintSrcReg) {
        String newLine;
        newLine = "    invoke-static {" + taintTargReg + ", " + taintSrcReg + "}, Ljava/lang/PathTaint;->copy(Ljava/lang/PathTaint;Ljava/lang/PathTaint;)V";
        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        int newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;
    }


    private Integer addCreateTaintWithLeftRight(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister, String leftTaint, String rightTaint) {
        String newLine;
        newLine = "    invoke-static {" + taintTargReg + ", v" + signatureRegister + ", " + leftTaint + ", " + rightTaint + "}, Ljava/lang/PathTaint;->create(Ljava/lang/PathTaint;Ljava/lang/String;Ljava/lang/PathTaint;Ljava/lang/PathTaint;)V";
        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        int newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;
    }



    private Integer addCreateTaintWithLeft(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister, String leftTaint) {
        String newLine;
        newLine = "    invoke-static {" + taintTargReg + ", v" + signatureRegister + ", " + leftTaint + "}, Ljava/lang/PathTaint;->create(Ljava/lang/PathTaint;Ljava/lang/String;Ljava/lang/PathTaint;)V";
        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        int newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;
    }


    private Integer addCreateTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister) {
        String newLine;
        newLine = "    invoke-static {" + taintTargReg + ", v" + signatureRegister + "}, Ljava/lang/PathTaint;->create(Ljava/lang/PathTaint;Ljava/lang/String;)V";
        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        int newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;
    }

    private Integer addGetReturnTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, String targetReg, String instruction) {
        if (getRegNumFromRef(taintTargReg) < 256) {
            linesToAdd.add("    invoke-static {}, Ljava/lang/PathTaint;->newInstance()Ljava/lang/PathTaint;");
            linesToAdd.add("    move-result-object " + taintTargReg);
        } else {
            String moveInstruction = "move/16";
            if (instruction.contains("object")) {
                moveInstruction = "move-object/16";
            } else if (instruction.contains("wide")) {
                moveInstruction = "move-wide/16";
            }
            linesToAdd.add("    " + moveInstruction + " v" + taintTempReg + ", " + targetReg);
            linesToAdd.add("    invoke-static {}, Ljava/lang/PathTaint;->newInstance()Ljava/lang/PathTaint;");
            linesToAdd.add("    move-result-object " + targetReg);
            linesToAdd.add("    move-object/16 " + taintTargReg + ", " + targetReg);
            linesToAdd.add("    " + moveInstruction + " " + targetReg + ", v" + taintTempReg);
        }
        String newLine;
        newLine = "    invoke-static {" + taintTargReg + "}, Ljava/lang/PathTaint;->getReturnTaint(Ljava/lang/PathTaint;)V";
        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        int newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;

  
        
        
        // linesToAdd.add("    invoke-static {}, Ljava/lang/Thread;->getReturnTaint()Ljava/lang/PathTaint;");
        
        // if (getRegNumFromRef(taintTargReg) > 255) {
        //     linesToAdd.add("    move-result " + targetReg);
        //     linesToAdd.add("    move-object/16 " + taintTargReg + ", " + targetReg);
        //     linesToAdd.add("    " + moveInstruction + " " + targetReg + ", v" + taintTempReg);
        // } else {
        //     linesToAdd.add("    move-result " + taintTargReg);
        // }

        // return maxRegs;
    }


    private Integer addGetExceptionTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, String targetReg, String instruction) {
        if (getRegNumFromRef(taintTargReg) < 256) {
            linesToAdd.add("    invoke-static {}, Ljava/lang/PathTaint;->newInstance()Ljava/lang/PathTaint;");
            linesToAdd.add("    move-result-object " + taintTargReg);
        } else {
            String moveInstruction = "move/16";
            if (instruction.contains("object")) {
                moveInstruction = "move-object/16";
            } else if (instruction.contains("wide")) {
                moveInstruction = "move-wide/16";
            }
            linesToAdd.add("    " + moveInstruction + " v" + taintTempReg + ", " + targetReg);
            linesToAdd.add("    invoke-static {}, Ljava/lang/PathTaint;->newInstance()Ljava/lang/PathTaint;");
            linesToAdd.add("    move-result-object " + targetReg);
            linesToAdd.add("    move-object/16 " + taintTargReg + ", " + targetReg);
            linesToAdd.add("    " + moveInstruction + " " + targetReg + ", v" + taintTempReg);
        }
        String newLine;
        newLine = "    invoke-static {" + taintTargReg + "}, Ljava/lang/PathTaint;->getThrowTaint(Ljava/lang/PathTaint;)V";
        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        int newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;
    }

    private Integer addSetReturnTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister) {
        String newLine;
        newLine = "    invoke-static {" + taintTargReg + "}, Ljava/lang/Thread;->setReturnTaint(Ljava/lang/PathTaint;)V";
        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        int newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;
    }

    private Integer addSetThrowTaint(Integer taintTempReg, Integer maxRegs, List<String> linesToAdd, String taintTargReg, int signatureRegister) {
        String newLine;
        newLine = "    invoke-static {" + taintTargReg + "}, Ljava/lang/Thread;->setThrowTaint(Ljava/lang/PathTaint;)V";
        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        int newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;
    }



    private Integer handleIinstanceOp(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
            Map<String, String> taintRegMap, Map<String, FieldAccessInfo> fieldArraysInMethod, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister) {
        String fieldRef = getLastToken(line);
        String fieldType = fieldRef.substring(fieldRef.indexOf(":")+1);
        String fieldClass = getFieldClass(fieldRef);
        String fieldName = getFieldName(fieldRef);
        String taintField = createTaintField(fieldClass, fieldName);
        String targetReg = getRegReference(line, 1);
        String taintTargReg = taintRegMap.get(getRegReference(line, 1));

        String baseRegRef = getRegReference(line, 2);
        String taintBaseReg = taintRegMap.get(getRegReference(line, 2));


        String whereIsField = classAnalysis.getClassOfField(fieldClass, fieldName);

        if (fieldType.startsWith("[")) {
            fieldArraysInMethod.put(targetReg, new FieldAccessInfo(fieldRef, fieldType, fieldClass, fieldName, taintField, targetReg, taintTargReg, "Instance", whereIsField, baseRegRef));
        } else {
            fieldArraysInMethod.remove(targetReg);
        }

        if (TAINT_FIELDS && forbiddenClasses.contains(fieldClass) || whereIsField == null || isIgnored(whereIsField)) {
            // String moveInstruction = getMoveInstructionByType(fieldType);
            // eraseTaint(taintTempReg, linesToAdd, targetReg, taintTargReg, moveInstruction);
            // if (targetIsWide(instruction)) {
            //     eraseTaint(taintTempReg, linesToAdd, targetReg, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), moveInstruction);
            // }
            if (whereIsField == null || isIgnored(whereIsField)) {
                if (instruction.startsWith("iget") ) {
                    maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintBaseReg);
                } else if (instruction.startsWith("iput")) {
                    maxRegs = handleTwoSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                    line, linesToAdd, instruction, signatureRegister, taintBaseReg, taintTargReg, taintBaseReg);
                }
            }
            
            
        } else {
            linesToAdd.clear();
            if (targetReg.equals(baseRegRef) || (instruction.contains("wide") && ((getRegNumFromRef(targetReg) + 1) == getRegNumFromRef(baseRegRef)))) {
                // will add line after instrumentation
            } else {
                linesToAdd.add(line);
            }
            
            String newLine = "    # TargTaint: " + taintTargReg + ", BaseTaint: " + taintBaseReg;
            linesToAdd.add(newLine);
            if (instruction.startsWith("iget") ) {

                Pair<List<String>, Integer> rangedInvoke;
                int newMaxRegs;
                
                newLine = "    invoke-static {" + baseRegRef + "}, " + whereIsField + "->getField" + "zzz_" + fieldName + "_pathTaint" + "(" + whereIsField + ")Ljava/lang/PathTaint;";
                rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                linesToAdd.addAll(rangedInvoke.first);
                newMaxRegs = rangedInvoke.second;
                maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                linesToAdd.add("    move-result-object " + taintTargReg);

                maxRegs = handleTwoSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                    line, linesToAdd, instruction, signatureRegister, taintTargReg, taintTargReg, taintBaseReg);

                if (targetIsWide(instruction)) {
                    linesToAdd.add("    move-object/16 v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1) + ", " + taintTargReg);
                }
            } else if (instruction.startsWith("iput")) { // TODO: handle put in constructor  && !(methodInfo.getMethodName().equals("<init>"))
                maxRegs = taintSetInstanceField(taintTempReg, maxRegs, methodDelta, linesToAdd, signatureRegister, fieldName,
                        taintTargReg, baseRegRef, whereIsField);
            }

            if (targetReg.equals(baseRegRef) || (instruction.contains("wide") && ((getRegNumFromRef(targetReg) + 1) == getRegNumFromRef(baseRegRef)))) {
                linesToAdd.add(line);
            } else {
                // line already before instruemtnation
            }
            
        }
        return maxRegs;
    }



    private Integer handleSstaticOp(MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs,
            Map<String, String> taintRegMap, Map<String, FieldAccessInfo> fieldArraysInMethod, int methodDelta, String line, List<String> linesToAdd, String instruction, Integer signatureRegister) {
        String fieldRef = getLastToken(line);
        String fieldType = fieldRef.substring(fieldRef.indexOf(":")+1);
        String fieldClass = getFieldClass(fieldRef);
        String fieldName = getFieldName(fieldRef);
        String taintField = createTaintField(fieldClass, fieldName);
        String targetReg = getRegReference(line, 1);
        String taintTargReg = taintRegMap.get(getRegReference(line, 1));

        String whereIsField = classAnalysis.getClassOfField(fieldClass, fieldName);

        if (fieldType.startsWith("[")) {
            fieldArraysInMethod.put(targetReg, new FieldAccessInfo(fieldRef, fieldType, fieldClass, fieldName, taintField, targetReg, taintTargReg, "Static", whereIsField, null));
        } else {
            fieldArraysInMethod.remove(targetReg);
        }

        if (TAINT_FIELDS && forbiddenClasses.contains(fieldClass) || whereIsField == null || isIgnored(whereIsField)) {
            // String moveInstruction = getMoveInstructionByType(fieldType);
            // eraseTaint(taintTempReg, linesToAdd, targetReg, taintTargReg, moveInstruction);
            // if (targetIsWide(instruction)) {
            //     eraseTaint(taintTempReg, linesToAdd, targetReg, "v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1), moveInstruction);
            // }
        } else {
            String newLine = "    # TargTaint: " + taintTargReg;
            linesToAdd.add(newLine);

            if (instruction.startsWith("sget") ) {
                Pair<List<String>, Integer> rangedInvoke;
                int newMaxRegs;
                
                
                newLine = "    invoke-static {}, " + whereIsField + "->getField" + "zzz_" + fieldName + "_pathTaint" + "()Ljava/lang/PathTaint;";
                rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                linesToAdd.addAll(rangedInvoke.first);
                newMaxRegs = rangedInvoke.second;
                maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
                linesToAdd.add("    move-result-object " + taintTargReg);
                if (targetIsWide(instruction)) {
                    linesToAdd.add("    move-object/16 v" + String.valueOf(getRegNumFromRef(taintTargReg) + 1) + ", " + taintTargReg);
                }
                maxRegs = handleOneSourceOneDest(methodInfo, taintTempReg, maxRegs, taintRegMap, methodDelta,
                                line, linesToAdd, instruction, signatureRegister, taintTargReg, taintTargReg);

            } else if (instruction.startsWith("sput")) {
                maxRegs = taintSetStaticField(taintTempReg, maxRegs, methodDelta, linesToAdd, signatureRegister, fieldName,
                        taintTargReg, whereIsField);
            }
        }
        return maxRegs;
    }

    private Integer taintSetInstanceField(Integer taintTempReg, Integer maxRegs, int methodDelta, List<String> linesToAdd,
            Integer signatureRegister, String fieldName, String taintTargReg, String baseRegRef, String whereIsField) {
        String newLine;
        Pair<List<String>, Integer> rangedInvoke;
        int newMaxRegs;

        maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister, taintTargReg);
        maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, taintTargReg);

        newLine = "    invoke-static {" + baseRegRef + ", " + taintTargReg + "}, " + whereIsField + "->setField" + "zzz_" + fieldName + "_pathTaint" + "(" + whereIsField + "Ljava/lang/PathTaint;)V";
        rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;
    }

    private Integer taintSetStaticField(Integer taintTempReg, Integer maxRegs, int methodDelta, List<String> linesToAdd,
            Integer signatureRegister, String fieldName, String taintTargReg, String whereIsField) {
        String newLine;
        Pair<List<String>, Integer> rangedInvoke;
        int newMaxRegs;
        maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister, taintTargReg);
        maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, taintTargReg);
        newLine = "    invoke-static {" + taintTargReg + "}, " + whereIsField + "->setField" + "zzz_" + fieldName + "_pathTaint" + "(Ljava/lang/PathTaint;)V";
        rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
        linesToAdd.addAll(rangedInvoke.first);
        newMaxRegs = rangedInvoke.second;
        maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        return maxRegs;
    }


    private String getMoveInstructionByType(String paramType) {
        String moveInstruction = "move-object/16";
        if (paramType.equals("Z") || paramType.equals("C") || paramType.equals("B") || paramType.equals("S") || paramType.equals("I") || paramType.equals("F")) {
            moveInstruction = "move/16";
        } else if (paramType.equals("J") || paramType.equals("D")) {
            moveInstruction = "move-wide/16";
        } else if (paramType.equals("*")) {
            moveInstruction = null;
        }
        return moveInstruction;
    }

    private String changeParamsToLocals(Map<Integer, Integer> newParams, String line, int taintTempReg) {
        line = changeParamsToLocals(newParams, line, " p");
        line = changeParamsToLocals(newParams, line, "{p");
        return line;
    }

    private String changeParamsToLocals(Map<Integer, Integer> newParams, String line, String token) {
        int indexOfParam = 0;
        // System.out.println("Line: " + line);
        if (line.startsWith("    packed-switch")) {
            indexOfParam = "    packed-switch".length()-1;
        }

        // System.out.println("Cmp-1: " + line.indexOf(token, indexOfParam) + ", to " + indexOfParam);
        while (line.indexOf(token, indexOfParam) > indexOfParam) {
            indexOfParam = line.indexOf(token, indexOfParam) + 2;
            int lastIndex = line.indexOf("\"");
            if (lastIndex == -1) {
                lastIndex = line.length();
            }
            // System.out.println("Cmp-2: " + lastIndex + ", to " + indexOfParam);
            if (indexOfParam > lastIndex) {
                break;
            }

            Matcher matcher = Pattern.compile("\\d+").matcher(line.subSequence(indexOfParam, line.length()));
            matcher.find();
            int i = Integer.valueOf(matcher.group());
            line = line.substring(0, indexOfParam-1) + "v" + matcher.replaceFirst(String.valueOf(newParams.get(i)));
            // System.out.println("New line: " + line);
            // System.out.println("Cmp-3: " + line.indexOf(token, indexOfParam) + ", to " + indexOfParam);
        }
        return line;
    }

    private void fixRegisterLine(List<String> taintedClassLines, int maxRegs) {
        if (maxRegs == 0) {
            return;
        }
        for (int i = taintedClassLines.size()-1; i >=0; i--) {
            String line = taintedClassLines.get(i);
            if (line.startsWith("    .registers")) {
                int numRegs = Integer.parseInt(getLastToken(line));
                maxRegs = (maxRegs > numRegs)? maxRegs : numRegs;
                maxRegs = maxRegs + 2;
                String newRegsLine = "    .registers " + maxRegs;
                // System.out.println("        Fixed class line from: " + line);
                // System.out.println("                           to: " + newRegsLine);
                taintedClassLines.set(i, newRegsLine);
                return;
            }
            if (line.startsWith(".method")) {
                return;
            }
        }
    }

    private String createTaintField(String fieldClass, String fieldName) {
        return fieldClass + "->" + "zzz_" + fieldName + "_pathTaint:Ljava/lang/PathTaint;";
    }

    private String getFieldName(String fieldRef) {
        return fieldRef.substring(fieldRef.indexOf("->") + 2, fieldRef.indexOf(":"));
    }

    private String getFieldClass(String fieldRef) {
        return fieldRef.substring(0, fieldRef.indexOf("->"));
    }

    private int injectTaintSink(String line, List<String> linesToAdd, MethodInfo methodInfo, int taintTempReg, Map<String, String> taintRegMap, Integer signatureRegister, Integer methodDelta, String className) {
        if (line == null) {
            return 0;
        }
        int maxRegs = 0;
        String delim = "L";
        String search = ", L";
        if (line.indexOf(search) == -1) {
            delim = "[";
            search = ", \\[";
        }
        String calledMethod = delim + line.split(search, 2)[1];

        String instruction = getToken(line, 0);

        MethodInfo calledMethodInfo = new MethodInfo(calledMethod, instruction.contains("static"));
        linesToAdd.clear();
        Set<String> classesOfMethod = classAnalysis.getClassOfMethod(calledMethodInfo.getClassName(), calledMethodInfo.getNameAndDesc());
        classesOfMethod.add(calledMethodInfo.getClassName());
        int[] sinkParams = TaintSink.sinkParams(classesOfMethod, calledMethodInfo.getNameAndDesc());
        String[] passedRegs = null;
        if (sinkParams.length > 0) {
            passedRegs = parsePassedRegs(line);
        }

        if (sinkParams.length > 0) {
            linesToAdd.add("    move-object/16 v" + taintTempReg + ", v" + signatureRegister);
            linesToAdd.add("    const-string/jumbo v" + signatureRegister + ", \"" + calledMethodInfo.signature() + "\"");
            linesToAdd.add("    invoke-static/range {v" + signatureRegister + " .. v" + signatureRegister + "}, Ljava/lang/PathTaint;->printSinkFound(Ljava/lang/String;)V");
            linesToAdd.add("    move-object/16 v" + signatureRegister + ", v" + taintTempReg);
            statistics.addSink();
        }
        
        try {

            for (int sinkParam : sinkParams) {

                String taintedVar = passedRegs[sinkParam];
                String taintTargReg = taintRegMap.get(taintedVar);

                maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister, taintTargReg);
                maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, taintTargReg);

                String type = calledMethodInfo.getParams().get(sinkParam);

                // System.out.format("Will dump taint for arg %s of type %s%n", sinkParam, type);

                String newLine = "    invoke-static {" + taintTargReg + "}, Ljava/lang/Thread;->addToTaintDump(Ljava/lang/PathTaint;)V";
                if (type.startsWith("L") || type.startsWith("[")) {
                    newLine = "    invoke-static {" + taintTargReg + ", " + taintedVar + "}, Ljava/lang/Thread;->addToTaintDump(Ljava/lang/PathTaint;Ljava/lang/Object;)V";
                }

                Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                linesToAdd.addAll(rangedInvoke.first);
                int newMaxRegs = rangedInvoke.second;
                maxRegs = (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;

            }
            
            if (sinkParams.length != 0) {
                linesToAdd.add("    invoke-static {}, Ljava/lang/PathTaint;->finishDumpTaint()V");
            }


        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Failed to inject at sink: " + line);
            throw e;
        }
        linesToAdd.add(line);
        return maxRegs;
    }


    private int injectTaintSeedByReflection(String line, List<String> linesToAdd, MethodInfo methodInfo, int taintTempReg, Integer signatureRegister, Integer methodDelta, String className, List<String> extraTaintMethods, int lineNum, List<String> classLines, Map<String, String> taintRegMap) {
        if (line == null) {
            return 0;
        }
        int maxRegs = 0;
        String delim = "L";
        String search = ", L";
        if (line.indexOf(search) == -1) {
            delim = "[";
            search = ", \\[";
        }
        String calledMethod = delim + line.split(search, 2)[1];

        String instruction = getToken(line, 0);

        MethodInfo calledMethodInfo = new MethodInfo(calledMethod, instruction.contains("static"));


        if (calledMethodInfo.signature().equals("Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;")) {
            String[] passedRegs = parsePassedRegs(line);
            String methodRegister = passedRegs[0];
            String taintReg = taintRegMap.get(methodRegister);
            System.out.println("Will try to add Reflection source at " + line);

            linesToAdd.remove(linesToAdd.size()-1);
            for (int i = 0; i < passedRegs.length; i++) {
                linesToAdd.add("    invoke-static/range {" + taintReg + " .. " + taintReg + "}, Ljava/lang/Thread;->setParamTaint" + i + "(Ljava/lang/PathTaint;)V");
            }
            linesToAdd.add(line);

            
            for (String moveLine : classLines.subList(lineNum+1, classLines.size())) {
                System.out.println("    Checking line " + moveLine);
                if (moveLine.contains("move-result")) {
                    String targetReg = getRegReference(moveLine, 1);
                    String taintTargReg = taintRegMap.get(targetReg);
                    maxRegs = Reflection.injectTaintSeedIfReflectiveSource(methodRegister, taintTargReg, targetReg, signatureRegister, methodDelta, linesToAdd, extraTaintMethods, MAX_METHOD_DELTA, taintTempReg, className, maxRegs);
                    return maxRegs;
                } else if (moveLine.contains("invoke")) {
                    break;
                }
            }

            String taintTargReg = taintRegMap.get(passedRegs[0]);
            String firstParamReg = passedRegs[1];
            String firstParamTaintReg = taintRegMap.get(passedRegs[1]);
            maxRegs = Reflection.injectTaintSeedIfReflectiveSource(methodRegister, taintTargReg, firstParamReg, signatureRegister, methodDelta, linesToAdd, extraTaintMethods, MAX_METHOD_DELTA, taintTempReg, className, maxRegs);
            maxRegs = addCreateTaintWithLeftRight(taintTempReg, maxRegs, linesToAdd, firstParamTaintReg, signatureRegister, firstParamTaintReg, taintTargReg);
            maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, firstParamTaintReg);
        }
        return maxRegs;
    }

    private int injectTaintSeed(String line, List<String> linesToAdd, MethodInfo methodInfo, int taintTempReg, String taintTargReg, Integer signatureRegister, Integer methodDelta, String className, List<String> extraTaintMethods) {
        if (line == null) {
            return 0;
        }
        int maxRegs = 0;
        String delim = "L";
        String search = ", L";
        if (line.indexOf(search) == -1) {
            delim = "[";
            search = ", \\[";
        }
        String calledMethod = delim + line.split(search, 2)[1];

        String instruction = getToken(line, 0);

        MethodInfo calledMethodInfo = new MethodInfo(calledMethod, instruction.contains("static"));

        int extraRetregister = 0;
        if (!calledMethodInfo.getReturnType().equals("V")) {
            extraRetregister = 1;
        }

        

        if (extraRetregister == 1) {
            if (TaintSource.isSource(calledMethodInfo.signature())) {
                statistics.addSource();
                linesToAdd.add("    move-object/16 v" + taintTempReg + ", v" + signatureRegister);
                linesToAdd.add("    const-string/jumbo v" + signatureRegister + ", \"" + calledMethodInfo.signature() + "\"");
                linesToAdd.add("    invoke-static/range {v" + signatureRegister + " .. v" + signatureRegister + "}, Ljava/lang/PathTaint;->printSourceFound(Ljava/lang/String;)V");
                linesToAdd.add("    move-object/16 v" + signatureRegister + ", v" + taintTempReg);
                maxRegs = addCreateTaint(taintTempReg, maxRegs, linesToAdd, taintTargReg, signatureRegister);
                maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, taintTargReg);
            }
        }
        return maxRegs;
    }


    private int modelMethodCall(String line, List<String> linesToAdd, List<String> classLines, int lineNum, MethodInfo methodInfo, int taintTempReg, Map<String, String> taintRegMap, int signatureRegister, int methodDelta, List<String> taintedClassLines, String className) {
        int maxRegs = 0;
        String delim = "L";
        String search = ", L";
        if (line.indexOf(search) == -1) {
            delim = "[";
            search = ", \\[";
        }
        String calledMethod = delim + line.split(search, 2)[1];

        String instruction = getToken(line, 0);

        MethodInfo calledMethodInfo = new MethodInfo(calledMethod, instruction.contains("static"));

        String[] passedRegs = parsePassedRegs(line);

        if (linesToAdd.size() > 0) {
            linesToAdd.remove(linesToAdd.size()-1);
        }


        
        String receiverReg = null;
        String receiverRegTaint = null;
        if (!instruction.contains("static") && !line.contains("{}")) { // has receiver register
            receiverReg = passedRegs[0];
            receiverRegTaint = taintRegMap.get(receiverReg);
        }

        String returnTaintReg = null;

        boolean methodReturnIsTainted = false;
        if (!calledMethodInfo.getReturnType().equals("V")) {
            int nextMoveIndex = nextInstructionContains(classLines, lineNum, "move-result");
            if (nextMoveIndex != -1) {
                methodReturnIsTainted = true;
                returnTaintReg = taintRegMap.get(getRegReference(classLines.get(nextMoveIndex), 1));
                // System.out.println("Return is tainted: " + calledMethodInfo.signature());
                // System.out.println("Move: " + classLines.get(lineNum+2));
                // System.out.println("Return reg: " + getRegReference(classLines.get(lineNum+2), 1));
                // System.out.println("Taint map: " + taintRegMap);
                
            }
        }

        String fristTargReg = null;

        if (receiverRegTaint != null) {
            fristTargReg = receiverRegTaint;
        } else {
            if (methodReturnIsTainted) {
                fristTargReg = returnTaintReg;
            }
        }

        
        

        // if (calledMethodInfo.getClassName().startsWith("Ljava")) {
        //     // Option 1
        //     if (calledMethodInfo.getReturnType().equals(calledMethodInfo.getClassName()) || calledMethodInfo.getReturnType().equals("Z")) {
        //         if (fristTargReg != null) {
        //             for (String reg : parsePassedRegs(passedRegs)) {
        //                 String srcTaintReg = taintRegMap.get(reg);
        //                 maxRegs = addCreateTaintWithLeftRight(taintTempReg, maxRegs, linesToAdd, fristTargReg, signatureRegister, fristTargReg, srcTaintReg);
        //                 maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, fristTargReg);
        //             }
        //         }

        //         if (methodReturnIsTainted) {
        //             maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, returnTaintReg, signatureRegister, fristTargReg);
        //             maxRegs = addSetReturnTaint(taintTempReg, maxRegs, linesToAdd, returnTaintReg, signatureRegister);
        //         }
        //         // System.out.println(calledMethodInfo.signature() + ": Modeled both return and receiver");
        //     } else {
        //         if (methodReturnIsTainted && !calledMethodInfo.getMethodName().equals("add") && !calledMethodInfo.getMethodName().equals("put")) {
        //             for (String reg : parsePassedRegs(passedRegs)) {
        //                 String srcTaintReg = taintRegMap.get(reg);
        //                 maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, returnTaintReg, signatureRegister, srcTaintReg);
        //                 maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, returnTaintReg);
        //             }
        //             maxRegs = addSetReturnTaint(taintTempReg, maxRegs, linesToAdd, returnTaintReg, signatureRegister);
        //             // System.out.println(calledMethodInfo.signature() + ": Modeled return");
        //         } else if (fristTargReg != null) {
        //             for (String reg : parsePassedRegs(passedRegs)) {
        //                 String srcTaintReg = taintRegMap.get(reg);
        //                 maxRegs = addCreateTaintWithLeftRight(taintTempReg, maxRegs, linesToAdd, fristTargReg, signatureRegister, fristTargReg, srcTaintReg);
        //                 maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, fristTargReg);
        //             }
        //             // System.out.println(calledMethodInfo.signature() + ": Modeled receiver");
        //         }
        //     }
        // } else {
            // Option 2
            if (fristTargReg != null) {
                for (String reg : parsePassedRegs(passedRegs)) {
                    String srcTaintReg = taintRegMap.get(reg);
                    maxRegs = addCreateTaintWithLeftRight(taintTempReg, maxRegs, linesToAdd, fristTargReg, signatureRegister, fristTargReg, srcTaintReg);
                    maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, fristTargReg);
                }
            }

            if (methodReturnIsTainted) {
                maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, returnTaintReg, signatureRegister, fristTargReg);
                maxRegs = addSetReturnTaint(taintTempReg, maxRegs, linesToAdd, returnTaintReg, signatureRegister);
            }
        // }

        
        if (calledMethodInfo.signature().equals("Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V")) {
            maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintRegMap.get(passedRegs[2]), signatureRegister, taintRegMap.get(passedRegs[0]));
            maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, taintRegMap.get(passedRegs[2]));
        } else if (calledMethodInfo.signature().equals("Ljava/lang/String;->getChars(II[CI)V")) {
            maxRegs = addCreateTaintWithLeft(taintTempReg, maxRegs, linesToAdd, taintRegMap.get(passedRegs[3]), signatureRegister, taintRegMap.get(passedRegs[0]));
            maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, taintRegMap.get(passedRegs[3]));
        }


        if (calledMethodInfo.getMethodName().equals("execute") && calledMethodInfo.getNumBaseParams() == 2 && calledMethodInfo.getReturnType().equals("Landroid/os/AsyncTask;")) {
            String reg = parsePassedRegs(passedRegs)[1];
            String srcTaintReg = taintRegMap.get(reg);
            linesToAdd.add("    invoke-static/range {" + srcTaintReg + " .. " + srcTaintReg + "}, Ljava/lang/Thread;->setAsyncTaskParam(Ljava/lang/PathTaint;)V");
        }

        if ((calledMethodInfo.getMethodName().equals("send") || calledMethodInfo.getMethodName().equals("dispatchMessage")) && calledMethodInfo.getNumBaseParams() == 2 && calledMethodInfo.getParams().get(1).equals("Landroid/os/Message;")) {
            String reg = parsePassedRegs(passedRegs)[1];
            String srcTaintReg = taintRegMap.get(reg);
            linesToAdd.add("    invoke-static/range {" + srcTaintReg + " .. " + srcTaintReg + "}, Ljava/lang/Thread;->setAsyncTaskParam(Ljava/lang/PathTaint;)V");
        }

        List<String> parcelLines = Parcels.addParcelTaint(line, instruction, calledMethodInfo, passedRegs, taintRegMap, taintTempReg, returnTaintReg, TaintTool.PathTaint, classAnalysis);
        
        linesToAdd.addAll(parcelLines);
        if (returnTaintReg != null && !parcelLines.isEmpty()) {
            maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, returnTaintReg);
        }

        List<String> fileLines = FileTaint.addFileTaint(line, instruction, calledMethodInfo, passedRegs, taintRegMap, taintTempReg, returnTaintReg, TaintTool.PathTaint, signatureRegister, methodDelta, taintedClassLines, className);

        linesToAdd.addAll(fileLines);
        if (returnTaintReg != null && !fileLines.isEmpty()) {
            maxRegs = addLineNumTaint(taintTempReg, maxRegs, methodDelta, linesToAdd, returnTaintReg);
        }

        linesToAdd.add(line);

        return maxRegs;
    }

    private int nextInstructionContains(List<String> classLines, int lineNum, String string) {
        for (int i = lineNum+1; i < classLines.size(); i++) {
            String line = classLines.get(i);
            if (line.startsWith(".")) {
                break;
            }
            if (line.startsWith("    :") || line.startsWith("    .")) {
                continue;
            }
            if (line.isEmpty()) {
                continue;
            }
            String instruction = getToken(line, 0);
            if (instruction.contains(string)) {
                return i;
            } else {
                return -1;
            }
        }
        return -1;
    }

   


    private int addTaintToCallParams(String line, List<String> linesToAdd, List<String> classLines, int lineNum, MethodInfo methodInfo, int taintTempReg, Map<String, String> taintRegMap, int signatureRegister, int methodDelta, List<String> taintedClassLines, String className) {
        int maxRegs = 0;
        String delim = "L";
        String search = ", L";
        if (line.indexOf(search) == -1) {
            delim = "[";
            search = ", \\[";
        }
        String calledMethod = delim + line.split(search, 2)[1];

        String instruction = getToken(line, 0);

  
        if (classAnalysis.isNative(calledMethod)) {
            return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta, taintedClassLines, className);
        }

        MethodInfo calledMethodInfo = new MethodInfo(calledMethod, instruction.contains("static"));

        Set<String> whereIsMethod = classAnalysis.getClassOfMethod(calledMethodInfo.getClassName(), calledMethod.split("->")[1]);
        // System.out.println("----------------------------------");
        // System.out.println("For method: " + calledMethod);
        // System.out.println("Classes are: " + whereIsMethod);
        // System.out.println("Inherited: " + classAnalysis.getInheriterClasses(calledMethodInfo.getClassName()));

        if ((TAINT_METHODS && forbiddenClasses.contains(calledMethodInfo.getClassName())) || isIgnored(classAnalysis.getClassOfMethod(calledMethodInfo.getClassName(), calledMethodInfo.getNameAndDesc())) ) {
            // System.out.printf("    Decision 1: %s, %s%n", forbiddenClasses.contains(calledMethodInfo.getClassName()), isIgnored(classAnalysis.getClassOfMethod(calledMethodInfo.getClassName(), calledMethodInfo.getNameAndDesc())));
            return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta, taintedClassLines, className);
        }

        if (calledMethodInfo.getNameAndDesc().equals("<init>()V")) {
            // System.out.println("    Decision 2");
            return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta, taintedClassLines, className);
        }


        if (whereIsMethod == null || isIgnored(whereIsMethod)) {
            // System.out.println("    Decision 3");
            return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta, taintedClassLines, className);
        }

        // if (calledMethodInfo.getMethodName().startsWith("on")) { // TODO: remove
        //     return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta);
        // }

        // if (calledMethodInfo.getDesc().equals("(Landroid/view/View;)V")) { // TODO: remove
        //     return modelMethodCall(line, linesToAdd, classLines, lineNum, methodInfo, taintTempReg, taintRegMap, signatureRegister, methodDelta);
        // }
        
        // System.out.println("    Decision 4");

        if (linesToAdd.size() > 0) {
            linesToAdd.remove(linesToAdd.size()-1);
        }
        
        String [] lineSplit = line.split("\\}");
        String [] regSplit = lineSplit[0].split("\\{");
        String [] passedRegs = new String[0];
        if (regSplit.length > 1) {
            passedRegs = regSplit[1].replace(" ", "").split("\\,");
        }

        if (passedRegs.length > 0) {
            if (passedRegs[0].contains("..")) {
                passedRegs[0] = passedRegs[0].replace("..", "Z");
                String firstReg = passedRegs[0].split("Z")[0];
                String lastReg = passedRegs[0].split("Z")[1];
                int firstRegNum = getRegNumFromRef(firstReg);
                int lastRegNum = getRegNumFromRef(lastReg);
                passedRegs = new String[lastRegNum-firstRegNum+1];
                for (int i = firstRegNum; i <= lastRegNum; i++) {
                    passedRegs[i-firstRegNum] = "v" + i;
                }
            }
        }

        for (int i = 0; i < passedRegs.length; i++) {
            String taintReg = taintRegMap.get(passedRegs[i]);
            linesToAdd.add("    invoke-static/range {" + taintReg + " .. " + taintReg + "}, Ljava/lang/Thread;->setParamTaint" + i + "(Ljava/lang/PathTaint;)V");
        }

        if (calledMethodInfo.getNumBaseParams() == 2 && calledMethodInfo.getParams().get(1).equals("Lokhttp3/RequestBody;")) {
            String reg = parsePassedRegs(passedRegs)[1];
            String srcTaintReg = taintRegMap.get(reg);
            linesToAdd.add("    invoke-static/range {" + srcTaintReg + " .. " + srcTaintReg + "}, Ljava/lang/Thread;->setAsyncTaskParam(Ljava/lang/PathTaint;)V");
        }

        if (calledMethodInfo.getNameAndDesc().equals("invoke()Ljava/lang/Object;")) {
            String reg = parsePassedRegs(passedRegs)[0];
            String srcTaintReg = taintRegMap.get(reg);
            linesToAdd.add("    invoke-static/range {" + srcTaintReg + " .. " + srcTaintReg + "}, Ljava/lang/Thread;->setAsyncTaskParam(Ljava/lang/PathTaint;)V");

        }

        linesToAdd.add(line);

        return maxRegs;
    }

    private void addTaintRegisters(String line, List<String> linesToAdd, MethodInfo methodInfo) {
        Integer baseNumRegs;
        baseNumRegs = Integer.parseInt(getLastToken(line));
        methodInfo.setBaseNumRegs(baseNumRegs);
        String newRegsLine = "    .registers " + ((methodInfo.getBaseNumRegs()*2) + 3); // 1 site reg, 2 temp regs
        linesToAdd.clear();
        linesToAdd.add(newRegsLine);
    }

    private boolean addTaintToMethodParams(String line, List<String> linesToAdd, MethodInfo methodInfo) {

        // System.out.println("At: " + line);
        // System.out.println(classAnalysis.getClassOfMethod(methodInfo.getClassName(), methodInfo.getNameAndDesc()));

        System.out.println("For method: " + line);
        System.out.println("Classes are: " + classAnalysis.getClassOfMethod(methodInfo.getClassName(), methodInfo.getNameAndDesc()));
        System.out.println("Inherited: " + classAnalysis.getInheriterClasses(methodInfo.getClassName()));
        System.out.println("----------------------------------");


        if ((TAINT_METHODS && forbiddenClasses.contains(methodInfo.getClassName())) || isIgnored(classAnalysis.getClassOfMethod(methodInfo.getClassName(), methodInfo.getNameAndDesc()))) {
            // System.out.println("Ignored");
            // System.out.println("--------------------------------");
            return false;
        }
        // System.out.println("--------------------------------");

        // if (methodInfo.getMethodName().startsWith("on")) { // TODO: remove
        //     return false;
        // }

        // if (methodInfo.getDesc().equals("(Landroid/view/View;)V")) { // TODO: remove
        //     return false;
        // }
        

        if (methodInfo.getNameAndDesc().equals("<init>()V")) {
            return false;
        }


        String descWithTaint = methodInfo.addTaintToDesc();
        String newLine = replaceToken(line, methodInfo.getMethodName() + descWithTaint, -1);
        linesToAdd.clear();
        linesToAdd.add(newLine);
        return true;
    }

    private void addTaintField(List<String> linesToAdd, String line, String className, List<String> taintFieldMethods) {
        String[] parse = line.split(":");
        String left = parse[0];
        parse = left.split("\\s+");
        String [] accessModifierArray = Arrays.copyOfRange(parse, 0, parse.length-1);
        
        boolean isTransiet = false;

        for (int i = 0; i < accessModifierArray.length; i++) {
            String token = accessModifierArray[i];
            if (token.equals("private")) {
                accessModifierArray[i] = "public";
            } else if (token.equals("transient")) {
                isTransiet = true;
            }
        }

        

        String fieldName = "zzz_" + parse[parse.length-1] + "_pathTaint";
        String accessModifier = String.join(" ", accessModifierArray);

        

        String fieldNameDesc;
        if (accessModifier.contains(" static ")) {
            fieldNameDesc = fieldName + ":Ljava/lang/PathTaint;"; // "_pathTaint:I = 1"; // 
        } else {
            fieldNameDesc = fieldName + ":Ljava/lang/PathTaint;"; // "_pathTaint:I"; // 
            if (!isTransiet) {
                accessModifier += " transient";
            }
        }

        String taintField = accessModifier + " " + fieldNameDesc;
        linesToAdd.add(0, taintField);

        if (accessModifier.contains("static")) {
            taintFieldMethods.add(".method public static getField" + fieldName + "()Ljava/lang/PathTaint;");
            taintFieldMethods.add(".registers 3");
            taintFieldMethods.add("    sget-object v0, " + className + "->" + fieldNameDesc);
            taintFieldMethods.add("    if-nez v0, :cond_1");
            taintFieldMethods.add("    new-instance v0, Ljava/lang/PathTaint;");
            taintFieldMethods.add("    invoke-direct {v0}, Ljava/lang/PathTaint;-><init>()V");
            taintFieldMethods.add("    sput-object v0, " + className + "->" + fieldNameDesc);
            taintFieldMethods.add("    goto :end");
            taintFieldMethods.add("    :cond_1");
        } else {
            taintFieldMethods.add(".method public static getField" + fieldName + "(" + className + ")Ljava/lang/PathTaint;");
            taintFieldMethods.add(".registers 4");
            taintFieldMethods.add("    iget-object v0, p0, " + className + "->" + fieldNameDesc);
            taintFieldMethods.add("    if-nez v0, :cond_1");
            taintFieldMethods.add("    new-instance v0, Ljava/lang/PathTaint;");
            taintFieldMethods.add("    invoke-direct {v0}, Ljava/lang/PathTaint;-><init>()V");
            taintFieldMethods.add("    iput-object v0, p0, " + className + "->" + fieldNameDesc);
            taintFieldMethods.add("    goto :end");
            taintFieldMethods.add("    :cond_1");
        }
        taintFieldMethods.add("    :end");
        taintFieldMethods.add("    iget-object v1, v0, Ljava/lang/PathTaint;->left:Ljava/lang/PathTaint;");
        taintFieldMethods.add("    if-eqz v1, :cond_2");
        taintFieldMethods.add("    const-string/jumbo v1, \"" + className + "->" + fieldName + "\"");
        taintFieldMethods.add("    invoke-static {v1}, Ljava/lang/PathTaint;->printFieldNameGet(Ljava/lang/String;)V");
        taintFieldMethods.add("    :cond_2");
        taintFieldMethods.add("    return-object v0");
        taintFieldMethods.add(".end method");

        if (accessModifier.contains("static")) {
            taintFieldMethods.add(".method public static setField" + fieldName + "(Ljava/lang/PathTaint;)V");
            taintFieldMethods.add(".registers 3");
            taintFieldMethods.add("    new-instance v0, Ljava/lang/PathTaint;");
            taintFieldMethods.add("    invoke-direct {v0}, Ljava/lang/PathTaint;-><init>()V");
            taintFieldMethods.add("    iget-object v1, p0, Ljava/lang/PathTaint;->left:Ljava/lang/PathTaint;");
            taintFieldMethods.add("    iput-object v1, v0, Ljava/lang/PathTaint;->left:Ljava/lang/PathTaint;");
            taintFieldMethods.add("    sput-object v0, " + className + "->" + fieldNameDesc);
        } else {
            taintFieldMethods.add(".method public static setField" + fieldName + "(" + className + "Ljava/lang/PathTaint;)V");
            taintFieldMethods.add(".registers 4");
            taintFieldMethods.add("    new-instance v0, Ljava/lang/PathTaint;");
            taintFieldMethods.add("    invoke-direct {v0}, Ljava/lang/PathTaint;-><init>()V");
            taintFieldMethods.add("    iget-object v1, p1, Ljava/lang/PathTaint;->left:Ljava/lang/PathTaint;");
            taintFieldMethods.add("    iput-object v1, v0, Ljava/lang/PathTaint;->left:Ljava/lang/PathTaint;");
            taintFieldMethods.add("    iput-object v0, p0, " + className + "->" + fieldNameDesc);
        }
        taintFieldMethods.add("    if-eqz v1, :cond_1");
        taintFieldMethods.add("    const-string/jumbo v1, \"" + className + "->" + fieldName + "\"");
        taintFieldMethods.add("    invoke-static {v1}, Ljava/lang/PathTaint;->printFieldNameSet(Ljava/lang/String;)V");
        taintFieldMethods.add("    :cond_1");
        taintFieldMethods.add("    return-void");
        taintFieldMethods.add(".end method");


    }

    private ClassRegion getCurrentRegion(String line, ClassRegion classRegion) {
        if (line.startsWith("# static fields")) {
            return ClassRegion.StaticFields;
        } else if (line.startsWith("# instance fields")) {
                return ClassRegion.InstanceFields;
        }
        return classRegion;
    }

    private void addTaintGetField(List<String> linesToAdd, String line) {

    }

    public void analyze() {
        classAnalysis.analyze(smaliFiles);
    }


}