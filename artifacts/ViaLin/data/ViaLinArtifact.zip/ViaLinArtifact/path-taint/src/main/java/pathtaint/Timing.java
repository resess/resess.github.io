package pathtaint;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Timing extends TaintAnalysis {
    
    enum ClassRegion {
        Header, StaticFields, InstanceFields, Methods
    }

    private List<String> smaliFiles;


    public static Set<String> forbiddenClasses = new HashSet<>(Arrays.asList(
       "Ljava/lang/Object;", "Ljava/lang/DexCache;"
        , "Ljava/lang/String;", "Ldalvik/system/ClassExt;", 
        "[Z", "[B", "[C", "[S", "[I", "[J", "[F", "[D", "Ljava/lang/Class;", "[Ljava/lang/Class;", 
        "[Ljava/lang/Object;", "Ljava/lang/Cloneable;", "Ljava/io/Serializable;", "Ljava/lang/reflect/Proxy;", 
        "Ljava/lang/reflect/Field;", "[Ljava/lang/reflect/Field;", "Ljava/lang/reflect/Constructor;", 
        "[Ljava/lang/reflect/Constructor;", "Ljava/lang/reflect/Method;", "[Ljava/lang/reflect/Method;", 
        "Ljava/lang/invoke/MethodType;", "Ljava/lang/invoke/MethodHandleImpl;", "Ljava/lang/invoke/MethodHandles$Lookup;", 
        "Ljava/lang/invoke/CallSite;", "Ldalvik/system/EmulatedStackFrame;", "Ljava/lang/ref/Reference;", 
        "Ljava/lang/ref/FinalizerReference;", "Ljava/lang/ref/PhantomReference;", "Ljava/lang/ref/SoftReference;", 
        "Ljava/lang/ref/WeakReference;", "Ljava/lang/ClassLoader;", "Ljava/lang/Throwable;", 
        "Ljava/lang/ClassNotFoundException;", "Ljava/lang/StackTraceElement;", "[Ljava/lang/StackTraceElement;"
    ));

    // private static final Set<String> allowed = new HashSet<>(Arrays.asList(
    //     "L"));

    public static final String [] ignoreArray = ClassTaint.ignoreArray;

    private static final Set<String> ignoreClass = new HashSet<>(Arrays.asList(ignoreArray)); 



    public Timing(List<String> smaliFiles, String analysisDir) {
        this.smaliFiles = smaliFiles;
    }



    private boolean isIgnoredClass(String className) {
        for (String c : ignoreClass) {
            if (className.startsWith(c)) {
                return true;
            }
        }
        return false;
    }

    public void addTaint() {
        for (String file : smaliFiles) {
            // ClassInfo classInfo = ClassInfo.getClassInfo(file);
            addTaintToClassFile(file, null);
        }
    }

    private void addTaintToClassFile(String file, ClassInfo classInfo) {
        List<String> classLines;
        try {
            classLines = Files.readAllLines(Paths.get(file));
        } catch (IOException e) {
            throw new Error("Cannot open class file: " + file);
        }

        String className = getLastToken(classLines.get(0));

        
        // if (className.equals("Ljava/lang/TaintDroid;") || className.equals("Ljava/lang/Object;") || className.equals("Ljava/lang/Class;")) {
        //     return;
        // }
        // if (className.equals("Ljava/util/Date;") || className.startsWith("Ljava/net")) {
        // } else if (className.startsWith("L")) {
        //     return;
        // }


        if (className.equals("Ljava/lang/TaintDroid;")) {
            return;
        }

        if (forbiddenClasses.contains(className) || isIgnoredClass(className)) {
            // System.out.println("Ignored class: " + className);
            return;
        }

        // System.out.println("Tainted class: " + className);


        MethodInfo methodInfo = null;
        Integer taintTempReg = null;
        Integer signatureRegister = null;
        Integer timerRegister = null;
        Integer maxRegs = 0;
        List<String> taintedClassLines = new ArrayList<>();
        Map<Integer, Integer> newParams = new HashMap<>();

        boolean instrument = true;
        boolean inAnnon = false;
        Stack<String> tryCatches = new Stack<>();

        for (int lineNum = 0; lineNum < classLines.size(); lineNum++) {
            
            String line = classLines.get(lineNum);
            List<String> linesToAdd = new ArrayList<>();
            linesToAdd.add(line);

            
            if (line.trim().startsWith(".annotation")) {
                inAnnon = true;
            }
            if (line.trim().startsWith(".end annotation")) {
                inAnnon = false;
            }
            if (line.startsWith("    :try_start")) {
                tryCatches.push(line);
            }
            if (line.startsWith("    :try_end")) {
                tryCatches.pop();
            }


            if (instrument && !inAnnon) { 

                if (line.isEmpty()) {
                    // pass
                } else if (line.startsWith(".field")) {
                    // pass
                } else if (line.startsWith("    invoke")) {
                    linesToAdd.clear();
                    line = changeParamsToLocals(newParams, line, taintTempReg);
                    linesToAdd.add(line);
                } else if (line.startsWith("    .registers")) {
                    addTaintRegisters(line, linesToAdd, methodInfo);
                    int firstTaintReg = methodInfo.getBaseNumRegs();

                    signatureRegister = firstTaintReg + methodInfo.getNumBaseLocalRegs() + methodInfo.getNumBaseParams() + 1;
                    timerRegister = signatureRegister + 1;
                    taintTempReg = timerRegister + 2;
                    maxRegs = taintTempReg + 2 + methodInfo.getNumBaseParams();

                    // addStartTimer(linesToAdd, timerRegister, taintTempReg, methodInfo, signatureRegister);

                    String regToUseForInit = "v0";

                    for (int i = 0; i < methodInfo.getParams().size(); i++ ) {
                        
                        String paramType = methodInfo.getParams().get(i);
                        int paramReg = methodInfo.getNumBaseLocalRegs() + i;

                        newParams.put(i, paramReg);

                        String moveInstruction = getMoveInstructionByType(paramType);

                        if (moveInstruction != null) {
                            linesToAdd.add("    " + moveInstruction + " v" + paramReg + ", p" + i);
                        }
                    }


                } else if (line.startsWith(".method")) {
                    if (!line.contains(" native ")) {
                        methodInfo = getMethodInfo(className, line);
                    }
                    
                } else if (line.startsWith(".end method")) {

                    methodInfo = null;
                    fixRegisterLine(taintedClassLines, maxRegs);
                } else if (methodInfo != null) {
                    String instruction = getToken(line, 0);
                    if (instruction.startsWith(".")) {
                    } else if (instruction.startsWith(":")) {
                    } else if (instruction.startsWith("0x")) {
                    } else if (instruction.startsWith("-")) {
                    } else {
                        linesToAdd.clear();
                        line = changeParamsToLocals(newParams, line, taintTempReg);
                        linesToAdd.add(line);
                        if (isNop(instruction)) {
                            // pass
                        } else if (isMove(instruction) || isMoveFrom16(instruction) || isMove16(instruction) || 
                            isMoveWide(instruction) || isMoveWideFrom16(instruction) || isMoveWide16(instruction) ||
                            isMoveObject(instruction) || isMoveObjectFrom16(instruction) || isMoveObject16(instruction)) {
                            // pass
                        } else if (isMoveResult(instruction) || isMoveResultWide(instruction) || isMoveResultObject(instruction)) {

                            // pass
                        } else if (isMoveException(instruction)) {
                            // pass
                        } else if (isReturnVoid(instruction)) {
                            // pass
                            // maxRegs = addEndTimer(linesToAdd, timerRegister, signatureRegister, methodInfo, taintTempReg, maxRegs);
                            // taintTempReg = maxRegs;
                        } else if (isReturn(instruction) || isReturnWide(instruction) || isReturnObject(instruction)) {
                            
                            // maxRegs = addEndTimer(linesToAdd, timerRegister, signatureRegister, methodInfo, taintTempReg, maxRegs);
                            // taintTempReg = maxRegs;
                        } else if (isConst4(instruction) || isConst16(instruction) || isConst(instruction) || isConstHigh16(instruction) || 
                                isConstWide16(instruction) || isConstWide32(instruction) || isConstWide(instruction) || isConstWideHigh16(instruction) ||
                                isConstString(instruction) || isConstStringJumbo(instruction) || isConstClass(instruction)) {
                            // pass
                        } else if (isMonitorEnter(instruction) || isMonitorExit(instruction)) {
                            // pass
                        } else if (isCheckCast(instruction)) {
                            // pass
                        } else if (isInstanceOf(instruction) || isArrayLength(instruction)) {
                            // pass
                        } else if (isNewInstance(instruction) || isNewArray(instruction)) {
                            // pass
                        } else if (isFilledNewArray(instruction) || isFilledNewArrayRange(instruction) || isFillArrayData(instruction)) {
                            // pass
                        } else if (isThrow(instruction)) {
                            // pass
                            // maxRegs = addEndTimer(linesToAdd, timerRegister, signatureRegister, methodInfo, taintTempReg, maxRegs);
                            // taintTempReg = maxRegs;
                        } else if (isGoto(instruction) || isGoto16(instruction) || isGoto32(instruction)) {
                            // pass
                        } else if (isPackedSwitch(instruction) || isSparseSwitch(instruction)) {
                            // pass
                        } else if (isCmpkind(instruction)) {
                            // pass
                        } else if (isIfTest(instruction) || isIfTestz(instruction)) {
                            // pass
                        } else if (isArrayOp(instruction)) {
                            // pass
                        } else if (isIinstanceOp(instruction)) {
                            // pass
                        } else if (isSstaticOp(instruction)) {
                            // pass
                        } else if (isInvokeKind(instruction) || isInvokeKindRange(instruction) || 
                            isInvokePolymorphic(instruction) || isInvokePolymorphicRange(instruction) || 
                            isInvokeCustom(instruction) || isInvokeCustomRange(instruction)) {
                            throw new Error("Invokes are handled in a separate branch");
                        } else if (isUnOp(instruction)) {
                            // pass
                        } else if (isBinOp(instruction)) {
                            // pass
                        } else if (isBinOp2addr(instruction)) {
                            // pass
                        } else if (isBinOpLit16(instruction) || isBinOpLit8(instruction)) {
                            // pass
                        } else if (isConstMethodHandle(instruction) || isConstMethodType(instruction)) {
                            // pass
                        } else {
                            throw new Error("Invalid instruction: " + line);
                        }
                    }
                }
            }
            taintedClassLines.addAll(linesToAdd);
        }


        try {
            Files.write(Paths.get(file), taintedClassLines);
        } catch (IOException e) {
            throw new Error("Cannot modify class file: " + file);
        }
    }


    private int addEndTimer(List<String> linesToAdd, Integer timerRegister, Integer signatureRegister, MethodInfo methodInfo, Integer taintTempReg, Integer maxRegs) {
        if (methodInfo.getMethodName().startsWith("on") || methodInfo.getDesc().equals("(Landroid/view/View;)V") || methodInfo.getMethodName().startsWith("doInBackground") || methodInfo.getNameAndDesc().equals("run()V")) {
            String newLine = "    invoke-static {v" + signatureRegister + ", v" + timerRegister + ", v" + String.valueOf(timerRegister + 1) + "}, Ljava/lang/TaintDroid;->endTime(Ljava/lang/String;J)V";
            Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
            linesToAdd.addAll(linesToAdd.size() - 1, rangedInvoke.first);
            int newMaxRegs = rangedInvoke.second;
            return (maxRegs > newMaxRegs)? maxRegs : newMaxRegs;
        }
        return maxRegs;
    }

    private void addStartTimer(List<String> linesToAdd, Integer timerRegister, Integer taintTempReg, MethodInfo methodInfo, Integer signatureRegister) {
        if (methodInfo.getMethodName().startsWith("on") || methodInfo.getDesc().equals("(Landroid/view/View;)V") || methodInfo.getMethodName().startsWith("doInBackground") || methodInfo.getNameAndDesc().equals("run()V")) {
            String p0Move = null;
            String p1Move = null;
            if (methodInfo.getNumBaseLocalRegs() < 2) {
                if (methodInfo.getNumBaseParams() > 0) {
                    p0Move = getMoveInstructionByType(methodInfo.getParams().get(0));
                }
                if (methodInfo.getNumBaseParams() > 1) {
                    p1Move = getMoveInstructionByType(methodInfo.getParams().get(1));
                }
            }
            if (p0Move != null) {
                linesToAdd.add("    " + p0Move + " v" + taintTempReg + ", p0");
                if (p0Move != null && methodInfo.getNumBaseParams() > 1 && !p0Move.contains("wide") && p1Move != null) {
                    linesToAdd.add("    " + p1Move + " v" + String.valueOf(taintTempReg+1) + ", p1");
                }
            }
            linesToAdd.add("    invoke-static {}, Ljava/lang/System;->nanoTime()J");
            linesToAdd.add("    move-result-wide v0");
            linesToAdd.add("    move-wide/16 v" + timerRegister + ", v0");

            linesToAdd.add("    const-string/jumbo v0, \"" + methodInfo.signature() + "\"");
            linesToAdd.add("    move-object/16 v" + String.valueOf(signatureRegister) + ", v0");

            if (p0Move != null) {
                linesToAdd.add("    " + p0Move + " p0, v" + taintTempReg);
                if (p0Move != null && methodInfo.getNumBaseParams() > 1 && !p0Move.contains("wide") && p1Move != null) {
                    linesToAdd.add("    " + p1Move + " p1, v" + String.valueOf(taintTempReg+1));
                }
            }
        }
    }



    private String getMoveInstructionByType(String paramType) {
        String moveInstruction = "move-object/16";
        if (paramType.equals("Z") || paramType.equals("C") || paramType.equals("B") || paramType.equals("S") || paramType.equals("I") || paramType.equals("F")) {
            moveInstruction = "move/16";
        } else if (paramType.equals("J") || paramType.equals("D")) {
            moveInstruction = "move-wide/16";
        } else if (paramType.equals("*")) {
            moveInstruction = null;
        }
        return moveInstruction;
    }

    private String changeParamsToLocals(Map<Integer, Integer> newParams, String line, int taintTempReg) {
        line = changeParamsToLocals(newParams, line, " p");
        line = changeParamsToLocals(newParams, line, "{p");
        return line;
    }

    private String changeParamsToLocals(Map<Integer, Integer> newParams, String line, String token) {
        int indexOfParam = 0;
        // System.out.println("Line: " + line);
        if (line.startsWith("    packed-switch")) {
            indexOfParam = "    packed-switch".length()-1;
        }

        // System.out.println("Cmp-1: " + line.indexOf(token, indexOfParam) + ", to " + indexOfParam);
        while (line.indexOf(token, indexOfParam) > indexOfParam) {
            indexOfParam = line.indexOf(token, indexOfParam) + 2;
            int lastIndex = line.indexOf("\"");
            if (lastIndex == -1) {
                lastIndex = line.length();
            }
            // System.out.println("Cmp-2: " + lastIndex + ", to " + indexOfParam);
            if (indexOfParam > lastIndex) {
                break;
            }

            Matcher matcher = Pattern.compile("\\d+").matcher(line.subSequence(indexOfParam, line.length()));
            matcher.find();
            int i = Integer.valueOf(matcher.group());
            line = line.substring(0, indexOfParam-1) + "v" + matcher.replaceFirst(String.valueOf(newParams.get(i)));
            // System.out.println("New line: " + line);
            // System.out.println("Cmp-3: " + line.indexOf(token, indexOfParam) + ", to " + indexOfParam);
        }
        return line;
    }

    private void fixRegisterLine(List<String> taintedClassLines, int maxRegs) {
        if (maxRegs == 0) {
            return;
        }
        for (int i = taintedClassLines.size()-1; i >=0; i--) {
            String line = taintedClassLines.get(i);
            if (line.startsWith("    .registers")) {
                int numRegs = Integer.parseInt(getLastToken(line));
                maxRegs = (maxRegs > numRegs)? maxRegs : numRegs;
                maxRegs = maxRegs + 2;
                String newRegsLine = "    .registers " + maxRegs;
                // System.out.println("        Fixed class line from: " + line);
                // System.out.println("                           to: " + newRegsLine);
                taintedClassLines.set(i, newRegsLine);
                return;
            }
            if (line.startsWith(".method")) {
                return;
            }
        }
    }



    private void addTaintRegisters(String line, List<String> linesToAdd, MethodInfo methodInfo) {
        Integer baseNumRegs;
        baseNumRegs = Integer.parseInt(getLastToken(line));
        methodInfo.setBaseNumRegs(baseNumRegs);
        String newRegsLine = "    .registers " + ((methodInfo.getBaseNumRegs()*2) + 3); // 1 site reg, 2 temp regs
        linesToAdd.clear();
        linesToAdd.add(newRegsLine);
    }

}