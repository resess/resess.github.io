package pathtaint;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClassInfo extends TaintAnalysis {

    private Map<String, MethodInfo> methods = new HashMap<>();

    // public static ClassInfo getClassInfo(String file) {
    //     ClassInfo classInfo = new ClassInfo();
    //     List<String> classLines;
    //     try {
    //         classLines = Files.readAllLines(Paths.get(file));
    //     } catch (IOException e) {
    //         throw new Error("Cannot open class file: " + file);
    //     }

    //     String className = getLastToken(classLines.get(0));
    //     MethodInfo methodInfo = null;
    //     for (String line : classLines) {
    //         if (line.startsWith(".method")) {
    //             methodInfo = getMethodInfo(className, line);
    //             classInfo.methods.put(methodInfo.signature(), methodInfo);
    //         } else if (line.startsWith(".end method")) {
    //             methodInfo = null;
    //         } else if (methodInfo != null) {
    //             String instruction = getToken(line, 0);
    //             if (instruction.equals("const") || instruction.equals("const/4") || instruction.equals("const/16") || instruction.equals("const/high16")) {
    //                 System.out.println("Dest reg: " + getRegReference(line, 1));
    //             } else if (instruction.equals("const-wide/16") || instruction.equals("const-wide/32") || instruction.equals("const-wide") || instruction.equals("const-wide/high16")) {
    //             } else if (instruction.equals("const-string") || instruction.equals("const-string/jumbo") || instruction.equals("const-class")) {
    //             }
    //         }
    //     }
    //     return classInfo;
    // }

}