package pathtaint;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

public class ClassAnalysis extends TaintAnalysis {

    private final String analysisDir;
    private final Map<String, Set<String>> methodsInClass = new HashMap<>();
    private final Map<String, String> classSuper = new HashMap<>();
    private final Map<String, Set<String>> implementedClass = new HashMap<>();
    private final Map<String, Set<String>> implementingClass = new HashMap<>();
    private final Set<String> nativeMethods = new HashSet<>();
    private final Map<String, Set<String>> fieldsInClass = new HashMap<>();
    // Want to know if method is in class, if not, want to know if it is in any of its super

    public ClassAnalysis (String analysisDir) {
        this.analysisDir = analysisDir;
        load();
    }

    private void addMethodToClass(String methodName, String className) {
        Set<String> methodSet = methodsInClass.getOrDefault(className, new HashSet<>());
        methodSet.add(methodName);
        methodsInClass.put(className, methodSet);
    }

    private void addFieldToClass(String fieldName, String className) {
        Set<String> fieldSet = fieldsInClass.getOrDefault(className, new HashSet<>());
        fieldSet.add(fieldName);
        fieldsInClass.put(className, fieldSet);
    }

    private void addSuperToClass(String superName, String className) {
        classSuper.put(className, superName);
    }

    private void addImplementedToClass(String superName, String className) {
        Set<String> classSet = implementedClass.getOrDefault(className, new HashSet<>());
        classSet.add(superName);
        implementedClass.put(className, classSet);
    }



    public void analyze(List<String> smaliFiles) {
        for (String file : smaliFiles) {
            List<String> classLines;
            try {
                classLines = Files.readAllLines(Paths.get(file));
            } catch (IOException e) {
                throw new Error("Cannot open class file: " + file);
            }
    
            String className = getLastToken(classLines.get(0));
            for (String line : classLines) {
                if (line.startsWith(".method") && line.contains("native")) {
                    addNativeMethod(className, line);
                }
                if (line.startsWith(".super")) {
                    addSuperToClass(getLastToken(line), className);
                }
                if (line.startsWith(".implements")) {
                    addImplementedToClass(getLastToken(line), className);
                }
                if (line.startsWith(".method")) {
                    addMethodToClass(getLastToken(line), className);
                }
                if (line.startsWith(".field")) {
                    addFieldToClass(getFieldName(line), className);
                }
            }
        }
        createImplementingClass();
    }

    private String getFieldName(String line) {
        String[] parse = line.split(":");
        String left = parse[0];
        parse = left.split("\\s+");
        return parse[parse.length-1];
    }

    private void addNativeMethod(String className, String line) {
        String methodName = className + "->" + getLastToken(line);
        nativeMethods.add(methodName);
    }

    public boolean isNative(String methodName) {
        return nativeMethods.contains(methodName);
    }

    public Set<String> getInheriterClasses(String className) {
        Set<String> classes = new HashSet<>();
        Stack<String> classesToGet = new Stack<String>();
        classesToGet.push(className);
        while (!classesToGet.isEmpty()) {
            String classToLookForNow = classesToGet.pop();
            Set<String> set = implementingClass.get(classToLookForNow);
            if (set != null ) {
                for (String c : set) {
                    if (!classes.contains(c)) {
                        classesToGet.add(c);
                        classes.add(c);
                    }
                }
            }
        }
        return classes;
    }

    public Set<String> getSuperClasses(String className, Set<String> classesSearched) {
        Set<String> superClasses = new HashSet<>();
        if (classesSearched.contains(className)) {
            // System.out.println("Returning early");
            return superClasses;
        }
        // System.out.println("Checking class: " + className);
        superClasses.add(className);
        classesSearched.add(className);
        Set<String> implementedClasses = implementedClass.getOrDefault(className, new HashSet<>());
        for (String c : implementedClasses) {
            // System.out.println("Adding implemented class: " + className);
            superClasses.addAll(getSuperClasses(c, classesSearched));
        }
        String superClass = classSuper.get(className);
        if (superClass != null) {
            // System.out.println("Adding super class: " + className);
            superClasses.addAll(getSuperClasses(superClass, classesSearched));
        }
        return superClasses;
    }


    public Set<String> getClassOfMethod(String className, String methodName) {
        Set<String> classesSearched = new HashSet<>();
        Set<String> classOfMethod = new HashSet<>();
        if (className.startsWith("[")) {
            classOfMethod.add("[" + className);
        }
        Set<String> classToLookFor = getInheriterClasses(className);
        classToLookFor.add(className);
        // System.out.println("Looking for: " + methodName + ", in class " + className);
        for (String in : classToLookFor) {
            try {
                classOfMethod.addAll(getClassOfMethodSearch(in, methodName, classesSearched));
            } catch (Exception e) {
                // System.out.println("Warning: exception thrown: " + e);
            }
        }

        if (classOfMethod.isEmpty()) {
            // System.out.println("Warning: cannot find method! " + methodName);
        }
        if (isNative(classOfMethod + "->" + methodName)) {
            return null;
        }
        classOfMethod.remove("Ljava/lang/Object;");
        return classOfMethod;
    }



    private Set<String> getClassOfMethodSearch(String className, String methodName, Set<String> classesSearched) {
        Set<String> classOfMethod = new HashSet<>();
        if (classesSearched.contains(className)) {
            return classOfMethod;
        }
        // System.out.println("Checking class: " + className);
        Set<String> classMethods = methodsInClass.get(className);
        if (classMethods != null && classMethods.contains(methodName)) {
            // System.out.println("Method found!");
            classOfMethod.add(className);
        }
        classesSearched.add(className);
        Set<String> implementedClasses = implementedClass.getOrDefault(className, new HashSet<>());
        for (String c : implementedClasses) {
            classOfMethod.addAll(getClassOfMethodSearch(c, methodName, classesSearched));
        }
        String superClass = classSuper.get(className);
        if (superClass != null) {
            classOfMethod.addAll(getClassOfMethodSearch(superClass, methodName, classesSearched));
        }
        return classOfMethod;
    }

    public String getClassOfField(String className, String fieldName) {
        // System.out.printf("--------------- looking for %s in %s ----------------\n", fieldName, className);
        String classOfField = null;
        try {
            classOfField = getClassOfFieldSearch(className, fieldName, new HashSet<>());
        } catch (Exception e) {
            // e.printStackTrace();
            // System.out.println("Warning: exception thrown: " + e);
        }
        if (classOfField == null) {
            // System.out.println("Warning: cannot find field! " + fieldName);
        }
        return classOfField;
    }

    private String getClassOfFieldSearch(String className, String fieldName, Set<String> classesSearched) {
        // System.out.printf("checking in class %s \n", className);
        Set<String> candidateFields = fieldsInClass.get(className);
        if (candidateFields != null && candidateFields.contains(fieldName)) {
            return className;
        }
        if (classesSearched.contains(className)) {
            return null;
        }
        classesSearched.add(className);
        Set<String> implementedClasses = implementedClass.getOrDefault(className, new HashSet<>());
        for (String c : implementedClasses) {
            String searchResult = getClassOfFieldSearch(c, fieldName, classesSearched);
            if (searchResult != null) {
                return searchResult;
            }
        }
        String superClass = classSuper.get(className);
        if (superClass == null) {
            return null;
        }
        return getClassOfFieldSearch(superClass, fieldName, classesSearched);
    }

    private void load() {
        try {
            methodsInClass.putAll(deSerialize("methodsInClass", methodsInClass));
            fieldsInClass.putAll(deSerialize("fieldsInClass", fieldsInClass));
            classSuper.putAll(deSerialize("classSuper", classSuper));
            implementedClass.putAll(deSerialize("implementedClass", implementedClass));
            createImplementingClass();
            nativeMethods.addAll(deSerialize("nativeMethods", nativeMethods));
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
        
    }

    private void createImplementingClass() {
        for (Map.Entry<String, Set<String>> e : implementedClass.entrySet()) {
            for (String c : e.getValue()) {
                Set<String> set = implementingClass.getOrDefault(c, new HashSet<>());
                set.add(e.getKey());
                implementingClass.put(c, set);
            }
        }
        
    }

    public void save() {
        serialize("methodsInClass", methodsInClass);
        serialize("fieldsInClass", fieldsInClass);
        serialize("classSuper", classSuper);
        serialize("implementedClass", implementedClass);
        serialize("nativeMethods", nativeMethods);
    }

    private <T> void serialize(String name, T object) {
        try {
            FileOutputStream fos =
                new FileOutputStream(analysisDir + "/" + name);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(object);
            oos.close();
            fos.close();
        } catch(IOException ioe) {
            ioe.printStackTrace();
        }
    }

    private <T> T deSerialize(String name, T object) {
        T ret = null;
        try {
           FileInputStream fis = new FileInputStream(analysisDir + "/" + name);
           ObjectInputStream ois = new ObjectInputStream(fis);
           ret = (T) ois.readObject();
           ois.close();
           fis.close();
        } catch(IOException ioe) {
           ioe.printStackTrace();
           return ret;
        } catch(ClassNotFoundException c) {
           System.out.println("Class not found");
           c.printStackTrace();
           return ret;
        }
        return ret;
    }

    // private Map<String, String> readFrameworkSummaries () {
    //     File[] listOfFiles = folder.listFiles();
    //     FileInputStream fis = new FileInputStream(analysisDir + "/" + name);
        
    // }


}
