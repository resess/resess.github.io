package pathtaint.injectedclasses;

public class PathTaint {
    public PathTaint left;
    public PathTaint right;
    public String site;

    public PathTaint(String site, PathTaint left, PathTaint right) {
        this.site = site;
        this.left = left;
        this.right = right;
    }
}

