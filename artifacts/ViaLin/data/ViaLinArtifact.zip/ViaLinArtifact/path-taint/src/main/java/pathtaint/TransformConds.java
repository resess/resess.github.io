package pathtaint;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class TransformConds extends TaintAnalysis {
    

    private List<String> smaliFiles;
    public static Set<String> forbiddenClasses = ClassTaint.forbiddenClasses;
    public static final String [] ignoreArray = ClassTaint.ignoreArray;
    private static final Set<String> ignoreClass = new HashSet<>(Arrays.asList(ignoreArray)); 



    public TransformConds(List<String> smaliFiles, String analysisDir, String coverageFile) {
        this.smaliFiles = smaliFiles;
    }



    private boolean isIgnoredClass(String className) {
        for (String c : ignoreClass) {
            if (className.startsWith(c)) {
                return true;
            }
        }
        return false;
    }

    public void transform() {
        for (String file : smaliFiles) {
            // ClassInfo classInfo = ClassInfo.getClassInfo(file);
            transformFile(file, null);
        }
    }

    private void transformFile(String file, ClassInfo classInfo) {
        List<String> classLines;
        try {
            classLines = Files.readAllLines(Paths.get(file));
        } catch (IOException e) {
            throw new Error("Cannot open class file: " + file);
        }

        String className = getLastToken(classLines.get(0));

        

        if (forbiddenClasses.contains(className) || isIgnoredClass(className)) {
            // System.out.println("Ignored class: " + className);
            return;
        }


        MethodInfo methodInfo = null;
        List<String> taintedClassLines = new ArrayList<>();

        boolean instrument = true;
        boolean inAnnon = false;
        Stack<String> tryCatches = new Stack<>();
        int methodSize = 0;
        Map<String, Integer> labelDistanceMap = new HashMap<>();

        for (int lineNum = 0; lineNum < classLines.size(); lineNum++) {
            
            String line = classLines.get(lineNum);
            List<String> linesToAdd = new ArrayList<>();
            linesToAdd.add(line);

            
            if (line.trim().startsWith(".annotation")) {
                inAnnon = true;
            }
            if (line.trim().startsWith(".end annotation")) {
                inAnnon = false;
            }
            if (line.startsWith("    :try_start")) {
                tryCatches.push(line);
            }
            if (line.startsWith("    :try_end")) {
                tryCatches.pop();
            }


            if (instrument && !inAnnon) { 

                if (line.isEmpty()) {
                    // pass
                } else if (line.startsWith(".field")) {
                    // pass
                } else if (line.startsWith("    invoke")) {
                    // pass
                } else if (line.startsWith("    .registers")) {
                    // pass


                } else if (line.startsWith(".method")) {
                    methodSize = 0;
                    if (!line.contains(" native ")) {
                        methodInfo = getMethodInfo(className, line);
                        labelDistanceMap = collectLabelDistanceMap(lineNum, classLines, methodInfo);
                    }
                } else if (line.startsWith(".end method")) {
                    if (methodInfo != null) {
                        // System.out.println("Method: " + methodInfo.signature());
                        // System.out.println("MethodSize: " + methodSize);
                    }

                } else if (methodInfo != null) {
                    String instruction = getToken(line, 0);
                    if (instruction.startsWith(".line")) {
                    } else if (instruction.startsWith(".")) {
                    } else if (instruction.startsWith(":")) {
                    } else if (instruction.startsWith("0x")) {
                    } else if (instruction.startsWith("-")) {
                    } else if (instruction.startsWith("#")) {
                    } else {
                        methodSize += getSizeBit(instruction);
                        if (isNop(instruction)) {
                            // pass
                        } else if (isMove(instruction) || isMoveFrom16(instruction) || isMove16(instruction) || 
                            isMoveWide(instruction) || isMoveWideFrom16(instruction) || isMoveWide16(instruction) ||
                            isMoveObject(instruction) || isMoveObjectFrom16(instruction) || isMoveObject16(instruction)) {
                            // pass
                        } else if (isMoveResult(instruction) || isMoveResultWide(instruction) || isMoveResultObject(instruction)) {
                            // pass
                        } else if (isMoveException(instruction)) {
                            // pass
                        } else if (isReturnVoid(instruction)) {
                            // pass
                        } else if (isReturn(instruction) || isReturnWide(instruction) || isReturnObject(instruction)) {
                            // pass
                        } else if (isConst4(instruction) || isConst16(instruction) || isConst(instruction) || isConstHigh16(instruction) || 
                                isConstWide16(instruction) || isConstWide32(instruction) || isConstWide(instruction) || isConstWideHigh16(instruction) ||
                                isConstString(instruction) || isConstStringJumbo(instruction) || isConstClass(instruction)) {
                            // pass
                        } else if (isMonitorEnter(instruction) || isMonitorExit(instruction)) {
                            // pass
                        } else if (isCheckCast(instruction)) {
                            // pass
                        } else if (isInstanceOf(instruction) || isArrayLength(instruction)) {
                            // pass
                        } else if (isNewInstance(instruction) || isNewArray(instruction)) {
                            // pass
                        } else if (isFilledNewArray(instruction) || isFilledNewArrayRange(instruction) || isFillArrayData(instruction)) {
                            // pass
                        } else if (isThrow(instruction)) {
                            // pass
                        } else if (isGoto(instruction) || isGoto16(instruction) || isGoto32(instruction)) {
                            // pass
                        } else if (isPackedSwitch(instruction) || isSparseSwitch(instruction)) {
                            // pass
                        } else if (isCmpkind(instruction)) {
                            // pass
                        } else if (isIfTest(instruction) || isIfTestz(instruction)) {
                            // pass
                            String srcReg1 = getRegReference(line, 1);
                            String label = getRegReference(line, 2);
                            // System.out.println("At line: " + line);

                            String srcReg2 = "";
                            if (isIfTest(instruction)) {
                                srcReg2 = label;
                                label = getRegReference(line, 3);
                            }
                            // System.out.printf("Label %s, Distance %s%n", label, labelDistanceMap.get(label));
                            String oppositeConditional = getOppositeConditional(instruction);
                            int labelNum = new Random().nextInt();
                            labelNum = (labelNum > 0? labelNum : -labelNum);
                            String newLabel = ":TaintLabel_" + labelNum;
                            String newInstruction = oppositeConditional + " " + srcReg1 + ", " + (srcReg2.equals("")? "" : srcReg2 + ", ") + newLabel;
                            String gotoInstruction = "goto/32 " + label;
                            // System.out.println("New Instruction: " + newInstruction);
                            int delta = labelDistanceMap.get(label) - methodSize;
                            if (delta < -32768 || delta > 32767) {
                                // System.out.format("Bad delta To cond %s in method%s%n", delta, methodInfo.signature());
                                linesToAdd.clear();
                                linesToAdd.add("    " + newInstruction);
                                linesToAdd.add("    " + gotoInstruction);
                                linesToAdd.add("    " + newLabel);
                            }

                        } else if (isArrayOp(instruction)) {
                            // pass
                        } else if (isIinstanceOp(instruction)) {
                            // pass
                        } else if (isSstaticOp(instruction)) {
                            // pass
                        } else if (isInvokeKind(instruction) || isInvokeKindRange(instruction) || 
                            isInvokePolymorphic(instruction) || isInvokePolymorphicRange(instruction) || 
                            isInvokeCustom(instruction) || isInvokeCustomRange(instruction)) {
                            throw new Error("Invokes are handled in a separate branch");
                        } else if (isUnOp(instruction)) {
                            // pass
                        } else if (isBinOp(instruction)) {
                            // pass
                        } else if (isBinOp2addr(instruction)) {
                            // pass
                        } else if (isBinOpLit16(instruction) || isBinOpLit8(instruction)) {
                            // pass
                        } else if (isConstMethodHandle(instruction) || isConstMethodType(instruction)) {
                            // pass
                        } else {
                            throw new Error("Invalid instruction: " + line);
                        }
                    }
                }
            }
            taintedClassLines.addAll(linesToAdd);
        }


        try {
            Files.write(Paths.get(file), taintedClassLines);
        } catch (IOException e) {
            throw new Error("Cannot modify class file: " + file);
        }
    }




    private Map<String, Integer> collectLabelDistanceMap(int lineNumInit, List<String> classLines, MethodInfo methodInfo) {
        int methodSize = 0;
        boolean inAnnon = false;
        Map<String, Integer> labelDistanceMap = new HashMap<>();
        for (int lineNum = lineNumInit; lineNum < classLines.size(); lineNum++) {
            String line = classLines.get(lineNum);

            if (line.trim().startsWith(".annotation")) {
                inAnnon = true;
            }
            if (line.trim().startsWith(".end annotation")) {
                inAnnon = false;
            }
            if (!inAnnon) { 
                if (line.isEmpty()) {
                    // pass
                } else if (line.startsWith(".end method")) {
                    return labelDistanceMap;

                } else if (methodInfo != null) {
                    String instruction = getToken(line, 0);
                    if (instruction.startsWith(".line")) {
                    } else if (instruction.startsWith(".")) {
                    } else if (instruction.startsWith(":")) {
                        labelDistanceMap.put(instruction, methodSize);
                    } else if (instruction.startsWith("0x")) {
                    } else if (instruction.startsWith("-")) {
                    } else if (instruction.startsWith("#")) {
                    } else {
                        methodSize += getSizeBit(instruction);
                    }
                }
            }
        }
        throw new Error("Didn't reach the end of method");
    }



    private String getMoveInstructionByType(String paramType) {
        String moveInstruction = "move-object/16";
        if (paramType.equals("Z") || paramType.equals("C") || paramType.equals("B") || paramType.equals("S") || paramType.equals("I") || paramType.equals("F")) {
            moveInstruction = "move/16";
        } else if (paramType.equals("J") || paramType.equals("D")) {
            moveInstruction = "move-wide/16";
        } else if (paramType.equals("*")) {
            moveInstruction = null;
        }
        return moveInstruction;
    }

    private String changeParamsToLocals(Map<Integer, Integer> newParams, String line, int taintTempReg) {
        line = changeParamsToLocals(newParams, line, " p");
        line = changeParamsToLocals(newParams, line, "{p");
        return line;
    }

    private String changeParamsToLocals(Map<Integer, Integer> newParams, String line, String token) {
        int indexOfParam = 0;
        // System.out.println("Line: " + line);
        if (line.startsWith("    packed-switch")) {
            indexOfParam = "    packed-switch".length()-1;
        }

        // System.out.println("Cmp-1: " + line.indexOf(token, indexOfParam) + ", to " + indexOfParam);
        while (line.indexOf(token, indexOfParam) > indexOfParam) {
            indexOfParam = line.indexOf(token, indexOfParam) + 2;
            int lastIndex = line.indexOf("\"");
            if (lastIndex == -1) {
                lastIndex = line.length();
            }
            // System.out.println("Cmp-2: " + lastIndex + ", to " + indexOfParam);
            if (indexOfParam > lastIndex) {
                break;
            }

            Matcher matcher = Pattern.compile("\\d+").matcher(line.subSequence(indexOfParam, line.length()));
            matcher.find();
            int i = Integer.valueOf(matcher.group());
            line = line.substring(0, indexOfParam-1) + "v" + matcher.replaceFirst(String.valueOf(newParams.get(i)));
            // System.out.println("New line: " + line);
            // System.out.println("Cmp-3: " + line.indexOf(token, indexOfParam) + ", to " + indexOfParam);
        }
        return line;
    }

    private void fixRegisterLine(List<String> taintedClassLines, int maxRegs) {
        if (maxRegs == 0) {
            return;
        }
        for (int i = taintedClassLines.size()-1; i >=0; i--) {
            String line = taintedClassLines.get(i);
            if (line.startsWith("    .registers")) {
                int numRegs = Integer.parseInt(getLastToken(line));
                maxRegs = (maxRegs > numRegs)? maxRegs : numRegs;
                maxRegs = maxRegs + 2;
                String newRegsLine = "    .registers " + maxRegs;
                // System.out.println("        Fixed class line from: " + line);
                // System.out.println("                           to: " + newRegsLine);
                taintedClassLines.set(i, newRegsLine);
                return;
            }
            if (line.startsWith(".method")) {
                return;
            }
        }
    }


}