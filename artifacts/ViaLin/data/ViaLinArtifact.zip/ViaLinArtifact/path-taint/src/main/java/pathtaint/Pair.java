package pathtaint;

public class Pair <E, K> {

    final E first;
    final K second;

    public Pair(E a, K b) {
        this.first = a;
        this.second = b;
    }
}
