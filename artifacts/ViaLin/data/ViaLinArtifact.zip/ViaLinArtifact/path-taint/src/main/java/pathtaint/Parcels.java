package pathtaint;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Parcels extends TaintAnalysis {
    public static List<String> addParcelTaint(String line, String instruction, MethodInfo calledMethodInfo, String[] passedRegs, Map<String, String> taintRegMap, int taintTempReg, String returnTaintReg, TaintTool tool, ClassAnalysis classAnalysis) {
        String toolName = "";
        if (tool.equals(TaintTool.TaintDroid)) {
            toolName = "TaintDroid";
        } else if (tool.equals(TaintTool.PathTaint)) {
            toolName = "PathTaint";
        } else {
            throw new Error("Unsupported tool: " + tool);
        }
         
        List<String> linesToAdd = new ArrayList<>();
        String receiverReg = null;
        String receiverRegTaint = null;
        System.out.println("Inspecting line: " + line);
        if (!instruction.contains("static") && !line.contains("{}")) { // has receiver register
            receiverReg = passedRegs[0];
            receiverRegTaint = taintRegMap.get(receiverReg);
        }
        String calledMethodClass = calledMethodInfo.getClassName();
        String calledMethodName = calledMethodInfo.getNameAndDesc();
        List<String> params = calledMethodInfo.getParams();
        Set<String> classesOfMethod = classAnalysis.getClassOfMethod(calledMethodInfo.getClassName(), calledMethodInfo.getNameAndDesc());
        System.out.println("    Classes " + classesOfMethod);
        if (calledMethodClass.equals("Landroid/content/Intent;")) {
            if (calledMethodName.equals("putExtras") || calledMethodName.equals("writeToParcel") || calledMethodName.equals("replaceExtras")) {
                String newLine = "    invoke-static {" + passedRegs[0] + ", " + receiverRegTaint + ", " + 
                    "}, Landroid/content/Intent;->addParcelTaint(Landroid/content/Intent;Ljava/lang/"+toolName+";)V";
                Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                linesToAdd = rangedInvoke.first;
                int newMaxRegs = rangedInvoke.second;
                return linesToAdd;
            } else if (calledMethodName.startsWith("put")) {
                if (params.get(1).equals("Ljava/lang/String;")) {
                    if (params.get(2).startsWith("L") || params.get(2).startsWith("[")) {
                        // System.out.println("Should add taint parcels to: " + line);
                        String newLine = "    invoke-static {" + passedRegs[0] + ", " + receiverRegTaint + ", " + passedRegs[2] + 
                            "}, Landroid/content/Intent;->addParcelTaint(Landroid/content/Intent;Ljava/lang/"+toolName+";Ljava/lang/Object;)V";
                        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                        linesToAdd = rangedInvoke.first;
                        int newMaxRegs = rangedInvoke.second;
                        return linesToAdd;
                    } else {
                        String newLine = "    invoke-static {" + passedRegs[0] + ", " + receiverRegTaint + ", " + 
                            "}, Landroid/content/Intent;->addParcelTaint(Landroid/content/Intent;Ljava/lang/"+toolName+";)V";
                        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                        linesToAdd = rangedInvoke.first;
                        int newMaxRegs = rangedInvoke.second;
                        return linesToAdd;
                    }
                }
            }  

            if (returnTaintReg != null) {
                if (calledMethodName.startsWith("get")) {
                    // System.out.println("----------------");
                    // System.out.println(line);
                    // System.out.println(passedRegs[0]);
                    // System.out.println(returnTaintReg);
                    String newLine = "    invoke-static {" + passedRegs[0] + ", " + returnTaintReg + 
                        "}, Landroid/content/Intent;->getParcelTaint(Landroid/content/Intent;Ljava/lang/"+toolName+";)V";
                    Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                    linesToAdd = rangedInvoke.first;
                    int newMaxRegs = rangedInvoke.second;
                    return linesToAdd;
                }
            }
        } else if (calledMethodClass.equals("Landroid/os/Bundle;")) {
            if (calledMethodName.startsWith("put")) {
                if (params.get(1).equals("Ljava/lang/String;")) {
                    if (params.get(2).startsWith("L") || params.get(2).startsWith("[")) {
                        // System.out.println("Should add taint parcels to: " + line);
                        String newLine = "    invoke-static {" + passedRegs[0] + ", " + receiverRegTaint + ", " + passedRegs[2] + 
                            "}, Landroid/os/Bundle;->addBundleTaint(Landroid/os/Bundle;Ljava/lang/"+toolName+";Ljava/lang/Object;)V";
                        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                        linesToAdd = rangedInvoke.first;
                        int newMaxRegs = rangedInvoke.second;
                        return linesToAdd;
                    } else {
                        String newLine = "    invoke-static {" + passedRegs[0] + ", " + receiverRegTaint + ", " + 
                            "}, Landroid/os/Bundle;->addBundleTaint(Landroid/os/Bundle;Ljava/lang/"+toolName+";)V";
                        Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                        linesToAdd = rangedInvoke.first;
                        int newMaxRegs = rangedInvoke.second;
                        return linesToAdd;
                    }
                }
            }  

            if (returnTaintReg != null) {
                if (calledMethodName.startsWith("get")) {
                    // System.out.println("----------------");
                    // System.out.println(line);
                    // System.out.println(passedRegs[0]);
                    // System.out.println(returnTaintReg);
                    String newLine = "    invoke-static {" + passedRegs[0] + ", " + returnTaintReg + 
                        "}, Landroid/os/Bundle;->getBundleTaint(Landroid/os/Bundle;Ljava/lang/"+toolName+";)V";
                    Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                    linesToAdd = rangedInvoke.first;
                    int newMaxRegs = rangedInvoke.second;
                    return linesToAdd;
                }
            }
        } else if (classesOfMethod.contains("Landroid/content/BroadcastReceiver;")) {
            System.out.println("    Method is " + calledMethodName);
            if (calledMethodName.startsWith("setResultData")) {
                System.out.println("    Adding taint");
                String newLine = "    invoke-static {" + receiverRegTaint + ", " + 
                    "}, Ljava/lang/Thread;->setOrderedIntentParam(Ljava/lang/"+toolName+";)V";
                Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                linesToAdd = rangedInvoke.first;
                int newMaxRegs = rangedInvoke.second;
                return linesToAdd;
            }
            if (returnTaintReg != null) {
                if (calledMethodName.startsWith("getResultData")) {
                    // System.out.println("----------------");
                    // System.out.println(line);
                    // System.out.println(passedRegs[0]);
                    // System.out.println(returnTaintReg);
                    linesToAdd.add("    invoke-static {}, Ljava/lang/Thread;->getOrderedIntentParam()Ljava/lang/"+toolName+";");
                    linesToAdd.add("    move-result-object " + returnTaintReg);
                    String newLine = "    invoke-static {" + returnTaintReg + "}, Ljava/lang/Thread;->setReturnTaint(Ljava/lang/PathTaint;)V";
                    Pair<List<String>, Integer> rangedInvoke = makeInvokeToRange(newLine, taintTempReg);
                    linesToAdd.addAll(rangedInvoke.first);
                    int newMaxRegs = rangedInvoke.second;
                    return linesToAdd;
                }
            }
        }
        return linesToAdd;
    }


}


// Landroid/content/Intent;->putExtras(Intent src)Landroid/content/Intent;
// Landroid/content/Intent;->putExtras(Bundle extras)Landroid/content/Intent;