package pathtaint.verifier;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;

import org.jf.smali.Smali;
import org.jf.smali.SmaliOptions;
import org.jf.util.ExceptionWithContext;

public class SmaliFileVerifier {
    enum FileType {JAR, DEX, APK};

    private static final int JOBS = 8;
    private final String classFileToVerify;
    

    public static void main(String args[]) throws IOException {
        if (args.length < 1) {
          System.out.println("Usage: inFile.smali");
          return;
        }

        String inFile = args[0];

        SmaliFileVerifier verifier = new SmaliFileVerifier(inFile);
        boolean pass = verifier.verify();
        if (pass) {
            System.out.println("verifier passed");
        } else {
            System.out.println("verifier error");
        }
        
      }
      

    public SmaliFileVerifier(String classFileToVerify) {
        this.classFileToVerify = classFileToVerify;
    }



    public boolean verify() {
        try {
            packageDexFile(classFileToVerify, 28, 0);
            return true;
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        }
        return false;
    }

    private void packageDexFile(String classFileToVerify, int apiLevel, int fileNum) throws IOException {
        SmaliOptions options = new SmaliOptions();
        options.outputDexFile = "temp.dex";
        options.apiLevel = apiLevel;
        options.jobs = JOBS;
        options.verboseErrors = true;
        try {
            Smali.assemble(options, classFileToVerify);
            System.out.println("Assembeled");
        } catch (ExceptionWithContext e) {
            e.printStackTrace();
        }
    }

}
