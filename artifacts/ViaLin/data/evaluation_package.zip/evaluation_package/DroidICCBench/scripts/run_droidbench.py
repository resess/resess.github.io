import os
import sys
import time
import subprocess
import signal

experiment = sys.argv[1]

if experiment == "cov":
    mode = "cov"
    out_dir = "coverage"
    results_tag = "cov"
elif experiment == "pt":
    mode = "pt"
    out_dir = "results_vialin"
    results_tag = "paths"
elif experiment == "td":
    mode = "td"
    out_dir = "results_taintdroid"
    results_tag = "paths"
elif experiment == "orig":
    mode = "orig"
    out_dir = "results_orig"
    results_tag = "time?"
else:
    raise "Error, invalid experiment"

device_num = input("Select device \n\
    [1] 712KPWQ1047761 \n\
    [2] 711KPED0968020 \n\
")
device_num = int(device_num)


if device_num == 1:
    device_id = "712KPWQ1047761"
    temp_dir = "temp"

elif device_num == 2:
    device_id = "711KPED0968020"
    temp_dir = "temp2"
else:
    raise "Error, must select device 1 or 2"

print("Must run from path-taint directory")



list_type = input("Select source/sink list to use \n\
    [1] App specific list \n\
    [2] TSE + FD list \n\
")
list_type = int(list_type)

run_single_app = input("Select app # to run, or 0 to run all \n\
")

run_single_app = int(run_single_app)

apps = []
with open ("evaluation/droidbench/config/droidbench_apks.log", 'r') as f:
    for line in f:
        apps.append(line.strip())

# print(apps)


if list_type == 2:
    source_list = "source_full_list.txt"
    sink_list = "sinks_full_list.txt"
    list_type = "big_list"
elif list_type == 1:
    source_list = app_name + ".src.txt"
    sink_list = app_name + ".sink.txt"
    list_type = "single_list"
else:
    raise "Error, must select 1 or 2"

out_dir_path = f"evaluation/droidbench/{out_dir}/"
if not os.path.exists(out_dir_path):
  os.makedirs(out_dir_path)

for app_index in range(0, len(apps)):

    if run_single_app > 0:
        if (run_single_app - 1) != app_index:
            continue

    app = apps[app_index]
    app_name = "_".join(app.split("/")[1:3])
    apk_path = f"~/data/2022_composite_taints/code/{app}"
    apk_name = app.split("/")[-1]
    print(app_name)
    log_name = f"evaluation/droidbench/{out_dir}/{app_name}.{list_type}.log"
    results_log = f"evaluation/droidbench/{out_dir}/{app_name}.{list_type}.{results_tag}.log"
    replay_file = f"evaluation/droidbench/config/{app_name}.replay.txt"

    if not os.path.isfile(replay_file):
        print("Failed to find replay file, using default")
        replay_file = f"evaluation/droidbench/config/trigger_flow.replay.txt"



    os.system(f"cd path-taint/; mvn package install; cd -; rm -r {temp_dir}; mkdir {temp_dir}; \
        java -Xss16M -jar path-taint/target/pathtaint-jar-with-dependencies.jar \
        t false {mode} {temp_dir} /home/user/data/2022_composite_taints/code/path-taint/framework_analysis_results \
        evaluation/droidbench/config/{source_list} evaluation/droidbench/config/{sink_list} \
        {apk_path} > {log_name} 2>&1")

    
    os.system(f"cp -r {temp_dir}/class_info evaluation/droidbench/{out_dir}/{app_name}.{list_type}.class_info")

    proc = subprocess.Popen(f"/home/user/data/android-aosp-pixel-2-xl-taintart/out/host/linux-x86/bin/aapt dump badging {temp_dir}/new-jar/{apk_name}", stdout=subprocess.PIPE, shell=True)
    (out, err) = proc.communicate()
    package_name = out.decode("utf-8").split()[1][5:].replace("\'", "")

    if experiment == "cov":
        os.system(f"cp {temp_dir}/full_coverage.log evaluation/droidbench/{out_dir}/{app_name}.{list_type}.all_lines.log")

    proc = subprocess.Popen(f"adb -s {device_id} shell dumpsys power | grep \'mHolding\'", stdout=subprocess.PIPE, shell=True)
    (out, err) = proc.communicate()
    power_stats = out.decode("utf-8")

    os.system(f"adb -s {device_id} uninstall {package_name} 2>/dev/null")
    os.system(f"yes vialin | apksigner sign --ks vialin.keystore {temp_dir}/new-jar/{apk_name}")

    os.system(f"adb -s {device_id} reboot")
    time.sleep(10)
    os.system(f"adb -s {device_id} logcat -c")
    time.sleep(10)
    print(f"Phone rebooted")
    time.sleep(30)
    os.system(f"adb -s {device_id} logcat -c")
    os.system(f"adb -s {device_id} install {temp_dir}/new-jar/{apk_name}")
    os.system(f"adb -s {device_id} logcat -G 100M")
    proc = subprocess.Popen(f"adb -s {device_id} logcat >> {log_name}", stdout=subprocess.PIPE, shell=True)
    

    # if "mHoldingWakeLockSuspendBlocker=false" in power_stats or "mHoldingDisplaySuspendBlocker=false" in power_stats:
    #     print("Unlocking")
    #     os.system(f"adb -s {device_id} shell input keyevent 26")

    time.sleep(5)
    os.system(f"adb -s {device_id} shell monkey -p {package_name} -c android.intent.category.LAUNCHER 1")
    time.sleep(2)
    proc.kill()
    time.sleep(2)

    os.system(f"adb -s {device_id} logcat -c")
    proc = subprocess.Popen(f"adb -s {device_id} logcat >> {log_name}", stdout=subprocess.PIPE, shell=True)
    
    os.chdir("../android-touch-record-replay/")

    os.system(f"./replay_touch_events_device.sh {device_id} ../path-taint/{replay_file}")

    os.chdir("../path-taint")

    time.sleep(10)

    # os.system(f"adb -s {device_id} shell input keyevent 26")

    os.system(f"adb -s {device_id} uninstall {package_name}")
    if experiment == "cov":
        os.system(f"python3 compute_coverage.py {log_name} evaluation/droidbench/{out_dir}/{app_name}.{list_type}.all_lines.log > {results_log} 2>&1")
    time.sleep(5)
    proc.kill()

    print(f"Finished running {app_name} with list {list_type} and mode {mode}")