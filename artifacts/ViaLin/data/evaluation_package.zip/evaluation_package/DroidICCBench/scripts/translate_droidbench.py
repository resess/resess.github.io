import os
import sys
import utils
import shutil

droidbench_folder = sys.argv[1]
f = sys.argv[2]
# files = utils.get_all_files(droidbench_folder)
# print(files)
def translate_file(f):
    # print("======")
    print(f, flush=True)
    log = utils.read_file(f)
    report, parcels = utils.get_dumptaint_report_from_log(log)
    graphs, insn_stmt_map = utils.get_graphs_from_reports_threaded(report)

    print(f"Map: {insn_stmt_map}")
    print("========")
    for n in graphs:
        print(n)
        for g in graphs[n]:
            print(g)
    
    paths = utils.translate_graphs_to_paths(graphs, insn_stmt_map)
    print(f"Paths: {paths}")

    classed_dir = f.replace(".log", ".class_info")
    loaded_classes = utils.load_all_classes(classed_dir)


    paths = utils.translate_paths_to_bytecode(paths, loaded_classes)
    # print(f"Paths here: {paths}")
    # for n in paths:
    #     print(n)
    # print("+++++")
    for p in parcels:
        # print(p)
        if p in paths:
            paths.pop(p)
    # print(f"Paths after removing parcels: {paths}")

    paths_unique = list()
    for n in paths:
        if paths[n] not in paths_unique:
            paths_unique.append(paths[n])

    out_dir = f.replace(".log", ".paths")
    shutil.rmtree(out_dir, ignore_errors=True)
    i = 0
    for path_bytecode in paths_unique:
        path_jimple = utils.translate_paths_to_jimple(path_bytecode)
        utils.print_path_consol(path_jimple)
        i += 1
        file_name = "path_" + str(i) + ".log"
        utils.print_list_reverse(out_dir, file_name, path_jimple)
        # print(path_jimple)

translate_file(f)