import sys
import os
import subprocess
import math
import numpy as np
from scipy.stats import shapiro 
from scipy.stats import lognorm
import xlsxwriter
import json

def get_all_files(mypath):
    # list all files
    # https://stackoverflow.com/questions/3207219/how-do-i-list-all-files-of-a-directory
    files = [os.path.join(mypath, f) for f in os.listdir(mypath) if os.path.isfile(os.path.join(mypath, f))]
    return files


def run_proc_get_out(command):
    result = subprocess.run(command.split(" "), stdout=subprocess.PIPE)
    return result.stdout.decode('utf-8')

def write_to_file(string_to_write, file_name):
    with open(file_name, 'w') as f:
        f.write(string_to_write)

def read_file(file_name):
    data = list()
    with open(file_name, 'r') as f:
        for l in f:
            data.append(l.strip())
    return data

def p_value(data):
    return shapiro(data).pvalue


def write_to_excel(string_to_write, workbook, sheet_name):
    worksheet = workbook.add_worksheet(sheet_name)
    rows = string_to_write.split("\n")
    for row_id in range(0, len(rows)):
        row = rows[row_id]
        cols = row.split(",")
        for col_id in range(0, len(cols)):
            worksheet.write(row_id, col_id, cols[col_id])

def get_dumptaint_report_from_log(log):
    report = []
    parcels = []
    for line in log:
        if "DumpTaint for parcel: " in line:
            parcels.append(int(line.split("DumpTaint for parcel: ")[1]))
        if "DumpTaint-" in line:
            report.append(line.split("System.out: ")[1])
        if "SourceFound:" in line:
            report.append(line.split("System.out: ")[1])
        if "SinkFound:" in line:
            report.append(line.split("System.out: ")[1])
    return report, parcels

def get_graphs_from_reports_threaded(report):
    graphs_lines = dict()
    graphs_rev = dict()
    sources = set()
    insn_stmt_map = dict()
    for line in report:
        if "DumpTaint-" in line:
            start, tail = line.split(": ->")
            num = int(start.split("-")[1])
            node, left = tail.split("->left->")
            if "->right->" in left:
                left, right = left.split("->right->")
            else:
                right = None
            if num not in graphs_lines:
                graphs_lines[num] = list()
            if [node, left, right] not in graphs_lines[num]:
                graphs_lines[num].append([node, left, right])

    src_insn_sink_ins_pairs = set()
    src_sink_ins_pairs = set()
    src_sink_pairs = set()
    
    for n in graphs_lines:
        sink_insn = None
        source_insn = None
        graphs_rev[n] = dict()
        for l in graphs_lines[n]:
            node, left, right = l
            stmt1, insn1 = parse_node(node)
            stmt2, insn2 = parse_node(left)
            # print(l)
            if not sink_insn:
                sink_insn = insn1
            if stmt2 == "STARTPATH" and not right:
                sources.add(insn2)
                source_insn = insn2
                src_insn_sink_ins_pairs.add((source_insn, sink_insn))
                src_sink_ins_pairs.add((stmt1, sink_insn))
                src_sink_pairs.add((stmt1, insn_stmt_map[sink_insn]))
                # print(f"Adding src: {(source_insn, sink_insn)}, {(stmt1, sink_insn)}, {(stmt1, insn_stmt_map[sink_insn])}")
            elif stmt2 != "STARTPATH":
                add_to_graph(graphs_rev[n], insn2, insn1)
                insn_stmt_map[insn1] = stmt1
                insn_stmt_map[insn2] = stmt2

            if right:
                # print(right)
                stmt3, insn3 = parse_node(right)
                add_to_graph(graphs_rev[n], insn3, insn1)
                insn_stmt_map[insn1] = stmt1
                insn_stmt_map[insn3] = stmt3
            
    graphs = dict()
    for n in graphs_rev:
        # print(f"Report #: {n}")
        graphs[n] = split_graphs_by_source_statement_instance(graphs_rev[n], sources)
    
    # print(f"Graphs: {graphs}", flush=True)
    return graphs, insn_stmt_map, src_insn_sink_ins_pairs, src_sink_ins_pairs, src_sink_pairs


def split_graphs_by_source_statement_instance(graph_rev, sources):
    graphs = list()
    
    for src in sources:
        if src in graph_rev:
            graphs.append(traverse_graph_from_stmt_inst_and_reverse(graph_rev, src))
    return graphs


def traverse_graph_from_stmt_inst_and_reverse(graph_rev, src):
    graph = dict()
    to_visit = list()
    to_visit.append(src)
    visited = set()
    # print(f"Src: {src}", flush=True)
    while len(to_visit):
        n = to_visit.pop()
        if n in visited:
            continue
        visited.add(n)
        if n in graph_rev:
            for next_node in graph_rev[n]:
                if next_node not in graph:
                    graph[next_node] = set()
                graph[next_node].add(n)
                to_visit.append(next_node)
    # print(f"Graph: {graph}", flush=True)
    return graph


def parse_node(node):
    if "STARTPATH" in node:
        insn = node.split("STARTPATH(")[1]
        stmt = "STARTPATH"
    else:
        # print(node)
        stmt, insn = node.split("id(")
    insn = int(insn.split(")")[0])
    return stmt, insn


def add_to_graph(graph, node, neighbour):
    if node not in graph:
        graph[node] = set()
    graph[node].add(neighbour)


def get_graphs_from_reports_ordered(report):
    graphs = list()
    num = 0
    g = dict()
    for line in report:
        if "SinkFound" in line and len(g):
            graphs.append(g)
            num += 1
            g = dict()
        if "DumpTaint-" in line and "STARTPATH" not in line:
            start, tail = line.split(": ->")
            num = int(start.split("-")[1])
            # print(line)
            # print("--------")
            # print(tail)
            node, left = tail.split("->left->")
            if "->right->" in left:
                left, right = left.split("->right->")
            else:
                right = None

            stmt1, insn1 = parse_node(node)
            stmt2, insn2 = parse_node(left)
            add_to_graph(g, insn1, insn2)
            if right:
                stmt3, insn3 = parse_node(right)
                add_to_graph(g, insn1, insn3)

            
    if g:
        graphs.append(g)

    return graphs

def translate_graphs_to_paths(graphs, insn_stmt_map):
    paths = dict()
    divergent = dict()
    for n in graphs:
        paths[n] = []
        divergent[n] = []
        for g in graphs[n]:
            p, div = translate_single_graphs_to_paths(g, insn_stmt_map)
            paths[n].append(p)
            divergent[n].append(div)
    # print(f"Translated paths: {paths}", flush=True)
    # print(f"Divergent: {divergent}", flush=True)
    return paths, divergent

def translate_single_graphs_to_paths(graph, insn_stmt_map):
    sink = get_sink(graph)
    print(f"Sink: {sink}-{insn_stmt_map[sink]}")
    to_visit = list()
    to_visit.append(sink)
    path = list()
    visited_si = set()
    path_is_divergant = False
    while len(to_visit):
        n = to_visit.pop(0)
        visited_si.add(n)
        if insn_stmt_map[n] not in path:
            path.append(insn_stmt_map[n])
        if n in graph:
            if len(graph[n]) > 1:
                path_is_divergant = True
            for next_node in graph[n]:
                if next_node not in visited_si:
                    to_visit.append(next_node)
    return path, path_is_divergant
    

def get_sink(graph):
    vals = set()
    for k in graph:
        for n in graph[k]:
            vals.add(n)
    for k in graph:
        if k not in vals:
            return k
    raise Exception("Can't find a sink!")


def translate_paths_to_bytecode(paths, loaded_classes):
    print(loaded_classes)
    jimple_paths = dict()
    for n in paths:
        jimple_paths[n] = list()
        for p in paths[n]:
            for stmt in p:
                if ";->" in stmt:
                    jimple_paths[n].append(stmt_to_bytecode(stmt, loaded_classes))
                else: # Parcels
                    # print(stmt)
                    parcel_num = int(stmt.split("(")[0])
                    # print(f"PARCEL: {stmt}-->{jimple_paths[parcel_num]}")
                    if parcel_num in jimple_paths:
                        for x in jimple_paths[parcel_num]:
                            jimple_paths[n].append(x)
    return jimple_paths


def stmt_to_bytecode(stmt, loaded_classes):
    class_name, rest = stmt.split(";->")
    class_name = class_name.replace("_", "/")
    method_name, rest = rest.rsplit("(", 1)
    line_num = rest.split(")")[0]
    method_code = loaded_classes[class_name][method_name]
    if line_num in method_code:
        bytecode = method_code[line_num]
        if "move-result" in bytecode:
            bytecode = method_code[str(int(line_num)-1)]
    else:
        for b in method_code:
            bytecode = method_code[b]
    return bytecode

def load_all_classes(folder):
    loaded_classes = dict()
    files = get_all_files(folder)
    for path in files:
        class_name = path.split("/")[-1].replace(".json", "").replace("_", "/")
        # print(f"loaded class {class_name}")
        with open(path, 'r') as f:
            loaded_classes[class_name] = json.load(f)
        # print(f"loaded content: {loaded_classes[class_name]}")
    return loaded_classes


def convert_type_from_bytecode_to_jimple(old_type):

    if old_type.startswith("["):
        is_array = True
        old_type = old_type[1:]
    else:
        is_array = False

    if old_type == "V":
        new_type = "void"
    elif old_type == "B":
        new_type = "byte"
    elif old_type == "S":
        new_type = "short"
    elif old_type == "I":
        new_type = "int"
    elif old_type == "J":
        new_type = "long"
    elif old_type == "D":
        new_type = "double"
    elif old_type == "F":
        new_type = "float"
    elif old_type == "Z":
        new_type = "boolean"
    elif old_type == "C":
        new_type = "char"
    elif old_type.startswith("L"):
        new_type = old_type[1:-1].replace("/", ".")
    else:
        raise Exception("Un-supported type: "+ old_type)
    if is_array:
        new_type = new_type + "[]"
    return new_type


def convert_param_list_from_bytecode_to_jimple(params):
    params_list = []
    new_param = ""
    is_object = False
    for c in params:
        if c == "[":
            new_param += c
            new_param = ""
        elif (not is_object) and c == "L":
            new_param = "L"
            is_object = True
        elif is_object:
            new_param += c
        elif not is_object:
            new_param += c
            params_list.append(new_param) 
            new_param = ""
        if c == ";":
            params_list.append(new_param)
            new_param = ""
            is_object = False
    # print(f"paramlist: {params_list}")
    return params_list


def convert_bytecode_stmt_to_jimple(line):
    # print(line)
    line = line.strip().split(" ")
    instruction = line[0]
    jimple_line = ""
    if instruction.startswith("invoke"):
        kind = instruction.split("-")[1]
        kind = kind.replace("/range", "")
        jimple_instr =  kind+"invoke"
        jimple_line += jimple_instr + " "
        if kind != "static":
            jimple_line += "R."
        desc = line[-1]
        class_name, method_name = desc.split("->")
        method_name, params = method_name.split("(")
        params, ret = params.split(")")
        jimple_class = convert_type_from_bytecode_to_jimple(class_name)
        jimple_params = ",".join([convert_type_from_bytecode_to_jimple(x) for x in convert_param_list_from_bytecode_to_jimple(params)])
        jimple_ret = convert_type_from_bytecode_to_jimple(ret)
        jimple_line += "<" + jimple_class + ": " + jimple_ret + " " + method_name + "(" + jimple_params + ")>(" + ",".join(["R" for x in convert_param_list_from_bytecode_to_jimple(params)]) +  ")"
        return jimple_line
    if instruction.startswith("iget") or instruction.startswith("sget"):
        if "-" in instruction:
            jimple_line += "R."
        desc = line[-1]
        class_name, field_name = desc.split("->")
        field_name, field_type = field_name.split(":")
        jimple_class = convert_type_from_bytecode_to_jimple(class_name)
        jimple_type = convert_type_from_bytecode_to_jimple(field_type)
        jimple_line += "<" + jimple_class + ": " + jimple_type + " " + field_name + "> = R"
        return jimple_line
    if instruction.startswith("iput") or instruction.startswith("sput"):
        jimple_line += "R = "
        if "-" in instruction:
            jimple_line += "R."
        desc = line[-1]
        class_name, field_name = desc.split("->")
        field_name, field_type = field_name.split(":")
        jimple_class = convert_type_from_bytecode_to_jimple(class_name)
        jimple_type = convert_type_from_bytecode_to_jimple(field_type)
        jimple_line += "<" + jimple_class + ": " + jimple_type + " " + field_name + ">"
        return jimple_line
    if instruction.startswith("aget"):
        return "R = R[R]"
    if instruction.startswith("aput"):
        return "R[R] = R"
    if instruction.startswith("move"):
        return "R = R"
    if instruction.startswith("int-to-long"):
        return "R = (long) R"
    if instruction.startswith("return"):
        if instruction == "return-void" or instruction == "return":
            return "return"
        else:
            return "return R"

    raise Exception(f"Un-supported instruction: {line}")



def translate_paths_to_jimple(path_bytecode):
    jimple_path = list()
    for line in path_bytecode:
        jimple_stmt = convert_bytecode_stmt_to_jimple(line)
        jimple_path.append(jimple_stmt)
    return jimple_path


def print_list_reverse(out_dir, file_name, path):
    
    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)
    with open(out_dir + "/" + file_name, 'w') as f:
        for p in reversed(path):
            f.write(p + "\n")

def print_path_consol(path):
    print("---------")
    for l in reversed(path):
        print(l)
    print("---------")