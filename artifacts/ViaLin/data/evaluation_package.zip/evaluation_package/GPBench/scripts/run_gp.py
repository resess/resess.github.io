import os
import sys
import time
import subprocess
import signal

experiment = sys.argv[1]

if experiment == "cov":
    mode = "cov"
    out_dir = "coverage"
    results_tag = "cov"
elif experiment == "pt":
    mode = "pt"
    out_dir = "results_vialin"
    results_tag = "paths"
elif experiment == "td":
    mode = "td"
    out_dir = "results_taintdroid"
    results_tag = "paths"
elif experiment == "orig":
    mode = "orig"
    out_dir = "results_orig"
    results_tag = "time?"
else:
    raise "Error, invalid experiment"

device_id = sys.argv[2]


app_names = {
    1: "1.com.echangecadeaux",
    2: "2.com.rtp.livepass.android.mod",
    3: "3.com.tripadvisor.tripadvisor",
    4: "4.ca.intact.mydrivingdiscount",
    5: "5.com.asiandate",
    6: "6.ca.passportparking.mobile.passportcanada",
    7: "7.com.aldiko.android",
    8: "8.com.passportparking.mobile.parkvictoria",
    9: "9.com.passportparking.mobile.toronto",
    10: "10.tc.tc.scsm.phonegap",
    11: "11.com.onetapsolutions.morneau.activity",
    12: "12.net.fieldwire.app",
    13: "13.com.ackroo.mrgas",
    14: "14.com.airbnb.android",
    15: "15.com.bose.gd.events",
    16: "16.com.phonehalo.itemtracker",
    17: "17.com.viagogo.consumer.viagogo.playstore",
    18: "18.com.yelp.android",
    19: "19.onxmaps.hunt"
}

print("Must run from path-taint directory")

app_num = input("Select app number to run \n\
    [1] 1.com.echangecadeaux \n\
    [2] 2.com.rtp.livepass.android.mod \n\
    [3] 3.com.tripadvisor.tripadvisor \n\
    [4] 4.ca.intact.mydrivingdiscount \n\
    [5] 5.com.asiandate \n\
    [6] 6.ca.passportparking.mobile.passportcanada \n\
    [7] 7.com.aldiko.android \n\
    [8] 8.com.passportparking.mobile.parkvictoria \n\
    [9] 9.com.passportparking.mobile.toronto \n\
    [10] 10.tc.tc.scsm.phonegap \n\
    [11] 11.com.onetapsolutions.morneau.activity \n\
    [12] 12.net.fieldwire.app \n\
    [13] 13.com.ackroo.mrgas \n\
    [14] 14.com.airbnb.android \n\
    [15] 15.com.bose.gd.events \n\
    [16] 16.com.phonehalo.itemtracker \n\
    [17] 17.com.viagogo.consumer.viagogo.playstore \n\
    [18] 18.com.yelp.android \n\
    [19] 19.onxmaps.hunt \n\
")
app_num = int(app_num)

list_type = input("Select source/sink list to use \n\
    [1] App specific list \n\
    [2] TSE + FD list \n\
")
list_type = int(list_type)

app_name = app_names[app_num]
apk_name = app_name + ".apk"

if list_type == 2:
    source_list = "source_full_list.txt"
    sink_list = "tse_sinks.txt"
    list_type = "big_list"
elif list_type == 1:
    source_list = app_name + ".src.txt"
    sink_list = app_name + ".sink.txt"
    list_type = "single_list"
else:
    raise "Error, must select 1 or 2"

out_dir_path = f"evaluation/gp_apps/{out_dir}/"
if not os.path.exists(out_dir_path):
  os.makedirs(out_dir_path)

log_name = f"evaluation/gp_apps/{out_dir}/{app_name}.{list_type}.log"
results_log = f"evaluation/gp_apps/{out_dir}/{app_name}.{list_type}.{results_tag}.log"
replay_file = f"evaluation/gp_apps/config/{app_name}.replay.txt"
replay_file1 = f"evaluation/gp_apps/config/{app_name}.replay1.txt"
replay_file2 = f"evaluation/gp_apps/config/{app_name}.replay2.txt"


os.system(f"cd path-taint/; mvn package install; cd -; rm -r temp; mkdir temp; \
    java -Xss16M -jar path-taint/target/pathtaint-jar-with-dependencies.jar \
    t false {mode} temp /home/user/data/2022_composite_taints/code/path-taint/framework_analysis_results \
    evaluation/gp_apps/config/{source_list} evaluation/gp_apps/config/{sink_list} \
    ~/data/apps/{apk_name} > {log_name} 2>&1")

os.system(f"cp -r temp/class_info evaluation/gp_apps/{out_dir}/{app_name}.{list_type}.class_info")


proc = subprocess.Popen(f"/home/user/data/android-aosp-pixel-2-xl-taintart/out/host/linux-x86/bin/aapt dump badging temp/new-jar/{apk_name}", stdout=subprocess.PIPE, shell=True)
(out, err) = proc.communicate()
package_name = out.decode("utf-8").split()[1][5:].replace("\'", "")

if experiment == "cov":
    os.system(f"cp temp/full_coverage.log evaluation/gp_apps/{out_dir}/{app_name}.{list_type}.all_lines.log")

proc = subprocess.Popen(f"adb -s {device_id} shell dumpsys power | grep \'mHolding\'", stdout=subprocess.PIPE, shell=True)
(out, err) = proc.communicate()
power_stats = out.decode("utf-8")

os.system(f"adb -s {device_id} uninstall {package_name} 2>/dev/null")
os.system(f"yes vialin | apksigner sign --ks vialin.keystore temp/new-jar/{apk_name}")
os.system(f"adb -s {device_id} logcat -c")
os.system(f"adb -s {device_id} install temp/new-jar/{apk_name}")
os.system(f"adb -s {device_id} logcat -G 100M")
proc = subprocess.Popen(f"adb -s {device_id} logcat >> {log_name}", stdout=subprocess.PIPE, shell=True)

if "mHoldingWakeLockSuspendBlocker=false" in power_stats or "mHoldingDisplaySuspendBlocker=false" in power_stats:
    print("Unlocking")
    os.system(f"adb -s {device_id} shell input keyevent 26")

time.sleep(10)
os.system(f"adb -s {device_id} shell monkey -p {package_name} -c android.intent.category.LAUNCHER 1")
time.sleep(60)
os.chdir("../android-touch-record-replay/")

# if app_num == 19: # TODO: remove
#     input("presse enter when done")
if app_num == 6 or app_num == 8 or app_num == 9 or app_num == 10:
    os.system(f"./replay_touch_events_device.sh {device_id} ../path-taint/{replay_file1}")
    input("enter code then presse enter")
    if app_num != 10:
        os.system(f"./replay_touch_events_device.sh {device_id} ../path-taint/{replay_file2}")
else:
    os.system(f"./replay_touch_events_device.sh {device_id} ../path-taint/{replay_file}")
os.chdir("../path-taint")


os.system(f"adb -s {device_id} shell input keyevent 26")

if app_num == 14:
    time.sleep(120)

os.system(f"adb -s {device_id} uninstall {package_name}")
if experiment == "cov":
    os.system(f"python3 compute_coverage.py {log_name} evaluation/gp_apps/{out_dir}/{app_name}.{list_type}.all_lines.log > {results_log} 2>&1")
os.killpg(os.getpgid(proc.pid), signal.SIGTERM)

print(f"Finished running {app_num}:{app_name} with list {list_type} and mode {mode}")