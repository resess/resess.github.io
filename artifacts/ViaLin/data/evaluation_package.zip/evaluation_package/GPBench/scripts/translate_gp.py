import os
import sys
import utils
import shutil
import statistics


def method_class_stats(path):
    methods = set()
    classes = set()
    for p in path:
        if "->" in p:
            class_name, method_name = p.split("->")
            method_name = method_name.rsplit("(", 1)[0]
            methods.add(f"{class_name}, {method_name}")
            classes.add(class_name)
    return len(methods), len(classes)

droidbench_folder = sys.argv[1]
f = sys.argv[2]
# files = utils.get_all_files(droidbench_folder)
# print(files)
def translate_file(f):
    # print("======")
    print(f, flush=True)
    log = utils.read_file(f)
    # print(f"log size is {len(log)}", flush=True)
    # log = log[0:int(len(log)/4)]
    # print(f"log size now is {len(log)}", flush=True)
    report, parcels = utils.get_dumptaint_report_from_log(log)
    graphs, insn_stmt_map, src_insn_sink_ins_pairs, src_sink_ins_pairs, src_sink_pairs = utils.get_graphs_from_reports_threaded(report)

    # print(f"Map: {insn_stmt_map}")
    # print("========")
    num_graphs = 0
    for n in graphs:
        # print(n)
        for g in graphs[n]:
            # print(g)
            num_graphs += 1
    print(f"Num_graphs: {num_graphs}")

    paths, divergent = utils.translate_graphs_to_paths(graphs, insn_stmt_map)
    # print(f"Paths: ")
    # for path in paths:
    #     print("===========")
    #     for p in paths:
    #         print(paths[p])

    for p in parcels:
        # print(p)
        if p in paths:
            paths.pop(p)
            divergent.pop(p)
    
    # print(f"Divergent: {divergent}", flush=True)
    num_divergent_unique = 0
    divergent_unique = list()
    paths_unique = list()
    for n in paths:
        for p in paths[n]:
            i = 0
            if p not in paths_unique:
                paths_unique.append(p)
                divergent_unique.append(divergent[n][i])
                if divergent[n][i] == True:
                    num_divergent_unique += 1
                i +=1

    for path in paths_unique:
        print("===========")
        for p in path:
            print(p)

    # print(f"Pair stats: {len(src_insn_sink_ins_pairs)}, {len(src_sink_ins_pairs)}, {len(src_sink_pairs)}")
    
    paths_num_methods = list()
    paths_num_classes = list()

    for path in paths_unique:
        num_methods, num_classes = method_class_stats(path)
        paths_num_methods.append(num_methods)
        paths_num_classes.append(num_classes)

    min_length_s_paths_no_dup = min([len(p) for p in paths_unique])
    max_length_s_paths_no_dup = max([len(p) for p in paths_unique])
    avg_length_s_paths_no_dup = sum([len(p) for p in paths_unique])/len(paths_unique)
    median_length_s_paths_no_dup = statistics.median([len(p) for p in paths_unique])


    min_methods_s_paths_no_dup = min(paths_num_methods)
    max_methods_s_paths_no_dup = max(paths_num_methods)
    avg_methods_s_paths_no_dup = sum(paths_num_methods)/len(paths_unique)
    median_methods_s_paths_no_dup = statistics.median(paths_num_methods)

    min_classes_s_paths_no_dup = min(paths_num_classes)
    max_classes_s_paths_no_dup = max(paths_num_classes)
    avg_classes_s_paths_no_dup = sum(paths_num_classes)/len(paths_unique)
    median_classes_s_paths_no_dup = statistics.median(paths_num_classes)

    print(f"Num_graphs: {num_graphs}")
    print(f"# reports: source statement instance to sink statement instance: {len(src_insn_sink_ins_pairs)}")
    # print(f"# ViaLin paths that consist of multiple routes: source statement instance to sink statement instance: {num_graphs_non_linear_paths_si}")
    print(f"# reported source statmenet to sink statement flows (ViaLin): {len(src_sink_pairs)}")
    print(f"# reported source statement to sink statement paths (ViaLin): {len(paths_unique)}")
    print(f"# ViaLin paths that combine multiple routes: source statement to sink statement: {num_divergent_unique}")
    print(f"# reports: source statmenet to sink statement instance (TD+S reports): {len(src_sink_ins_pairs)}")
    # print(f"Number of routes within a graph between source instance to sink instance pair (raw, no dup): {num_si_paths}")

    print(f"======Paths at stmt level=======")
    print(f"min_length_s_paths_no_dup: {min_length_s_paths_no_dup}")
    print(f"max_length_s_paths_no_dup: {max_length_s_paths_no_dup}")
    print(f"avg_length_s_paths_no_dup: {avg_length_s_paths_no_dup}")
    print(f"median_length_s_paths_no_dup: {median_length_s_paths_no_dup}")

    print(f"======Methods on paths at stmt level=======")
    print(f"min_methods_s_paths_no_dup: {min_methods_s_paths_no_dup}")
    print(f"max_methods_s_paths_no_dup: {max_methods_s_paths_no_dup}")
    print(f"avg_methods_s_paths_no_dup: {avg_methods_s_paths_no_dup}")
    print(f"median_methods_s_paths_no_dup: {median_methods_s_paths_no_dup}")

    print(f"======Classes on paths at stmt level=======")
    print(f"min_classes_s_paths_no_dup: {min_classes_s_paths_no_dup}")
    print(f"max_classes_s_paths_no_dup: {max_classes_s_paths_no_dup}")
    print(f"avg_classes_s_paths_no_dup: {avg_classes_s_paths_no_dup}")
    print(f"median_classes_s_paths_no_dup: {median_classes_s_paths_no_dup}")


    classed_dir = f.replace(".log", ".class_info")
    loaded_classes = utils.load_all_classes(classed_dir)


    paths = utils.translate_paths_to_bytecode(paths, loaded_classes)
    # print(f"Paths here: {paths}")
    # for n in paths:
    #     print(n)
    # print("+++++")
    for p in parcels:
        # print(p)
        if p in paths:
            paths.pop(p)
    # print(f"Paths after removing parcels: {paths}")

    paths_unique = list()
    for n in paths:
        if paths[n] not in paths_unique:
            paths_unique.append(paths[n])

    out_dir = f.replace(".log", ".paths")
    shutil.rmtree(out_dir, ignore_errors=True)
    i = 0
    for path_bytecode in paths_unique:
        path_jimple = utils.translate_paths_to_jimple(path_bytecode)
        utils.print_path_consol(path_jimple)
        i += 1
        file_name = "path_" + str(i) + ".log"
        utils.print_list_reverse(out_dir, file_name, path_jimple)
        # print(path_jimple)

translate_file(f)