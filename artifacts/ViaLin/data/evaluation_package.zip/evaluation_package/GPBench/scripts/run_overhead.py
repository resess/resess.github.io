import os
import sys
import time
import subprocess
import signal
import threading

mode = sys.argv[1]

if "_" in mode:
    mode = mode.split("_")
else:
    mode = [mode]

def get_paths(type):
    # print("Stuck here 1")
    out_dir_path = f"evaluation/gp_apps/results_mem_overhead/{type}/"
    if not os.path.exists(out_dir_path):
        os.makedirs(out_dir_path)
    log_name = f"{out_dir_path}/{app_name}.{list_type}.log"
    paths_log = f"{out_dir_path}/{app_name}.{list_type}.paths.log"
    # print("Stuck here 2")
    return log_name, paths_log


def instrument(apk_name, log_name, source_list, sink_list, type, temp_dir):
    # print("Stuck here 3")
    os.system(f"rm -r {temp_dir}; mkdir {temp_dir}; \
        java -Xmx4g -jar pathtaint-jar-with-dependencies.jar \
        t false {type} {temp_dir} /home/user/data/2022_composite_taints/code/path-taint/framework_analysis_results \
        evaluation/gp_apps/config/{source_list} evaluation/gp_apps/config/{sink_list} \
        ~/data/apps/{apk_name} > {log_name} 2>&1")

    # print("Stuck here 4")

    if type == "pt":
        result_path = "evaluation/gp_apps/tool_gp_apps"
    elif type == "td":
        result_path = "evaluation/gp_apps/taintdroid_gp_apps"
    elif type == "tdS":
        result_path = "evaluation/gp_apps/taintdroidS_gp_apps"
    elif type == "orig":
        result_path = "evaluation/gp_apps/orig_timing_gp_apps"
    else:
        raise "Error, invalid tool"

    os.system(f"yes vialin | apksigner sign --ks vialin.keystore {temp_dir}/new-jar/{apk_name}")

    # print("Stuck here 5")
    # print(f"cp {temp_dir}/new-jar/{apk_name} {result_path}")
    os.system(f"cp {temp_dir}/new-jar/{apk_name} {result_path}")

    # print("Stuck here 6")

    proc = subprocess.Popen(f"/home/user/data/android-aosp-pixel-2-xl-taintart/out/host/linux-x86/bin/aapt dump badging {result_path}/{apk_name}", stdout=subprocess.PIPE, shell=True)
    (out, err) = proc.communicate()
    package_name = out.decode("utf-8").split()[1][5:].replace("\'", "")

    # print("Stuck here 7")

    return package_name


def get_mem_file(device_id, log_name, i, pid, stop):
    # print("Stuck here 8")
    file_name = os.path.abspath(f"{log_name}.mem.{i}.log")
    with open(file_name, 'w') as f:
        f.write("")

    # print("Stuck here 9")
    t = 0
    while True:
        # print("Stuck here 10")
        time.sleep(1)
        t = t + 1
        proc = subprocess.Popen(f"adb -s {device_id} shell cat /proc/{pid}/status", stdout=subprocess.PIPE, shell=True)
        (out, err) = proc.communicate()
        status = out.decode("utf-8").strip()
        with open(file_name, 'a') as f:
            f.write(f"TimeStamp: {t}\n")
            f.write(f"{status}\n")
            f.write(f"----------------------------\n")
        if stop():
            break

# def get_smaps_file(device_id, log_name, i, pid, stop):

#     # file_name = os.path.abspath(f"{log_name}.mem.{i}.log")
#     # with open(file_name, 'w') as f:
#     #     f.write("")

#     t = 0
#     while True:
#         time.sleep(1)
#         t = t + 1
#         proc = subprocess.Popen(f"adb -s {device_id} shell cat /proc/{pid}/smaps", stdout=subprocess.PIPE, shell=True)
#         (out, err) = proc.communicate()
#         status = out.decode("utf-8").strip()
#         print(f"TimeStamp: {t}, Contents: {status}")
#         # with open(file_name, 'a') as f:
#         #     f.write(f"TimeStamp: {t}\n")
#         #     f.write(f"{status}\n")
#         #     f.write(f"----------------------------\n")
#         if stop():
#             break


def run_experiment(device_id, apk_to_install, package_name, log_name, replay_file, replay_file1, replay_file2, paths_log, i):
    # print("Stuck here 11")
    os.system(f"adb -s {device_id} uninstall {package_name} 2>/dev/null")
    os.system(f"adb -s {device_id} reboot")
    time.sleep(10)
    os.system(f"adb -s {device_id} logcat -c")
    time.sleep(10)
    print(f"Phone rebooted")
    # print("Stuck here 12")
    os.system(f"adb -s {device_id} logcat -c")
    # print("Stuck here 13")
    os.system(f"adb -s {device_id} install {apk_to_install}")
    # print("Stuck here 14")
    os.system(f"adb -s {device_id} logcat -G 100M")
    # print("Stuck here 15")
    # proc = subprocess.Popen(f"adb -s {device_id} shell dumpsys power | grep \'mHolding\'", stdout=subprocess.PIPE, shell=True)
    # (out, err) = proc.communicate()
    # power_stats = out.decode("utf-8")
    # print("Stuck here 16")
    # os.system(f"adb -s {device_id} shell input keyevent 26")
    # time.sleep(1)
    # print("Stuck here 17")
    # if "mHoldingWakeLockSuspendBlocker=false" in power_stats or "mHoldingDisplaySuspendBlocker=false" in power_stats:
    #     print("Unlocking")
    #     os.system(f"adb -s {device_id} shell input keyevent 26")

    # print("Stuck here 18")
    procLog = subprocess.Popen(f"exec adb -s {device_id} logcat > {log_name}.{i}.log", stdout=subprocess.PIPE, shell=True)
    # procVid = subprocess.Popen(f"exec adb -s {device_id} shell screenrecord /sdcard/video.mp4", stdout=subprocess.PIPE, shell=True)
    # print("Stuck here 19")

    print("**********************************************************************")
    print(f"creating {log_name}.{i}.log")
    print("**********************************************************************")
    time.sleep(10)
    os.system(f"adb -s {device_id} shell monkey -p {package_name} -c android.intent.category.LAUNCHER 1")
    # print("Stuck here 20")
    proc = subprocess.Popen(f"adb -s {device_id} shell pidof {package_name}", stdout=subprocess.PIPE, shell=True)
    (out, err) = proc.communicate()
    pid = out.decode("utf-8").strip()
    # print("Stuck here 21")
    print(f"pid is {pid}")

    # print("Stuck here 21")
    stop_threads = False
    th = threading.Thread(target=get_mem_file, args=(device_id, log_name, i, pid, lambda : stop_threads))
    th.start()

    # th2 = threading.Thread(target=get_smaps_file, args=(device_id, log_name, i, pid, lambda : stop_threads))
    # th2.start()



    # print("Stuck here 22")
    if app_num == 14:
        time.sleep(120)
    else:
        time.sleep(30)
    
    print(f"At {os.getcwd()}")

    os.chdir("../android-touch-record-replay/")

    print(f"Switching {os.getcwd()}")
    # print("Stuck here 23")

    # if app_num == 6 or app_num == 8 or app_num == 9 or app_num == 10:
    #     os.system(f"./replay_touch_events_device.sh {device_id} ../path-taint/{replay_file1}")
    #     input("enter code then presse enter")
    #     if app_num != 10:
    #         os.system(f"./replay_touch_events_device.sh {device_id} ../path-taint/{replay_file2}")
    # else:
    #     os.system(f"./replay_touch_events_device.sh {device_id} ../path-taint/{replay_file}")

    print(f"./replay_touch_events_device.sh {device_id} ../path-taint/{replay_file}")
    os.system(f"./replay_touch_events_device.sh {device_id} ../path-taint/{replay_file}")
    # print("Stuck here 24")

    # input("play then presse enter")

    if app_num == 14:
        time.sleep(120)
    else:
        time.sleep(10)

    os.chdir("../path-taint")
    # print("Stuck here 25")


    stop_threads = True
    th.join()
    # th2.join()
    # print("Stuck here 26")

    # Compute up time
    try:
        proc = subprocess.Popen(f"adb -s {device_id} shell cat /proc/{pid}/stat", stdout=subprocess.PIPE, shell=True)
        (out, err) = proc.communicate()
        proc_time = out.decode("utf-8").strip()
        utime = proc_time.split(" ")[13]
        stime = proc_time.split(" ")[14]
        starttime = proc_time.split(" ")[21]
        print(f"utime: {utime}, stime:{stime}, start:{starttime}")

        total_time = (int(utime) + int(stime))/100
        print(f"total time: {total_time}")
    except:
        total_time = -1

    os.system(f"adb -s {device_id} uninstall {package_name}")
    os.system(f"adb -s {device_id} shell input keyevent 26")
    # print("Stuck here 27")
    os.system(f"python3 translate_path.py {log_name}.{i}.log > {paths_log}.{i}.log 2>&1")
    # print("Stuck here 28")
    proc.kill()
    procLog.kill()
    # procVid.send_signal(signal.SIGINT)
    time.sleep(10)
    # os.system(f"adb -s {device_id} pull /sdcard/video.mp4 {log_name}.{i}.video.mp4")
    
    os.system(f"echo \"Total time (utime+stime): {total_time} s\" >> {log_name}.{i}.log")
    # print("Stuck here 29")


app_names = {
    1: "1.com.echangecadeaux",
    5: "5.com.asiandate",
    6: "6.ca.passportparking.mobile.passportcanada",
    7: "7.com.aldiko.android",
    8: "8.com.passportparking.mobile.parkvictoria",
    9: "9.com.passportparking.mobile.toronto",
    10: "10.tc.tc.scsm.phonegap",
    11: "11.com.onetapsolutions.morneau.activity",
    12: "12.net.fieldwire.app",
    13: "13.com.ackroo.mrgas",
    14: "14.com.airbnb.android",
    15: "15.com.bose.gd.events",
    16: "16.com.phonehalo.itemtracker",
    17: "17.com.viagogo.consumer.viagogo.playstore",
    18: "18.com.yelp.android",
    19: "19.onxmaps.hunt"
}

print("Must run from path-taint directory")

prompt = input("Did you remeber to build and copy the jar to path-taint dir?")
prompt = input("Did you remeber to remove swipe lock and open wifi?")

device_num = input("Select device \n\
    [1] 712KPWQ1047761 \n\
    [2] 711KPED0968020 \n\
")
device_num = int(device_num)

if device_num == 1:
    device_id = "712KPWQ1047761"
    temp_dir = "temp"
    # app_num_list = [ 5, 11, 13, 12, 18, 15]
    app_num_list = [10] #18, 5, 1, 6,  7, 16, 17, 19]

elif device_num == 2:
    device_id = "711KPED0968020"
    temp_dir = "temp2"
    # app_num_list = [16, 17, 19,  1, 14]
    # app_num_list = [ 5, 17, 12, 18, 13, 16, 11, 15, 19,  1, 14]
    app_num_list = [12, 13, 15, 8,  9, 10, 11, 14]
else:
    raise "Error, must select device 1 or 2"

list_type_select = input("Select source/sink list to use \n\
    [1] App specific list \n\
    [2] TSE + FD list \n\
")
list_type_select = int(list_type_select)

# for app_num in [1, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]:
# for app_num in [11, 12, 13, 14, 15, 16, 17, 18, 19]: # do 6, 8, 9, 10, 7 
# for app_num in [8, 9, 10, 6]: # 
# for app_num in [15, 16, 17, 18, 19, 14, 1, 5, 7, 11, 12, 13, 14]:
for app_num in app_num_list: 

    app_name = app_names[app_num]
    apk_name = app_name + ".apk"

    # source_list = "empty.txt"
    # sink_list = "empty.txt"
    if list_type_select == 2:
        source_list = "source_full_list.txt"
        sink_list = "tse_sinks.txt"
        list_type = "big_list"
    elif list_type_select == 1:
        source_list = app_name + ".src.txt"
        sink_list = app_name + ".sink.txt"
        list_type = "single_list"
    else:
        raise "Error, must select 1 or 2"

    


    replay_file = f"evaluation/gp_apps/config/{app_name}.replay.txt"
    replay_file1 = f"evaluation/gp_apps/config/{app_name}.replay1.txt"
    replay_file2 = f"evaluation/gp_apps/config/{app_name}.replay2.txt"

    log_name_orig, paths_log_orig = get_paths("orig")
    log_name_td, paths_log_td = get_paths("td")
    log_name_tdS, paths_log_tdS = get_paths("tdS")
    log_name_pt, paths_log_pt = get_paths("pt")

    # print("Stuck here 30")
    print(mode)
    if "orig" in mode:
        print(f"Instrumenting orig app {app_name}")
        package_name = instrument(apk_name, log_name_orig, source_list, sink_list, "orig", temp_dir)
    if "td" in mode:
        print(f"Instrumenting td app {app_name}")
        package_name = instrument(apk_name, log_name_td, source_list, sink_list, "td", temp_dir)
    if "tdS" in mode:
        print(f"Instrumenting tdS app {app_name}")
        package_name = instrument(apk_name, log_name_tdS, source_list, sink_list, "tdS", temp_dir)
    if "pt" in mode:
        print(f"Instrumenting pt app {app_name}")
        package_name = instrument(apk_name, log_name_pt, source_list, sink_list, "pt", temp_dir)

    # print("Stuck here 31")

    for i in range(0, 5):
        if "orig" in mode:
            run_experiment(device_id, f"evaluation/gp_apps/orig_timing_gp_apps/{apk_name}", package_name, log_name_orig, replay_file, replay_file1, replay_file2, paths_log_orig, i)
        if "pt" in mode:
            run_experiment(device_id, f"evaluation/gp_apps/tool_gp_apps/{apk_name}", package_name, log_name_pt, replay_file, replay_file1, replay_file2, paths_log_pt, i)
        if "td" in mode:
            run_experiment(device_id, f"evaluation/gp_apps/taintdroid_gp_apps/{apk_name}", package_name, log_name_td, replay_file, replay_file1, replay_file2, paths_log_td, i)
        if "tdS" in mode:
            run_experiment(device_id, f"evaluation/gp_apps/taintdroidS_gp_apps/{apk_name}", package_name, log_name_tdS, replay_file, replay_file1, replay_file2, paths_log_tdS, i)