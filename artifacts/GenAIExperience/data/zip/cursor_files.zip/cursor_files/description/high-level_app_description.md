# Description

The name of the app is MovieSwipe. In the app, a user can create a group and invite other users to join the group via an invitation code. The group owner can also delete the group. Upon joining a group, users are asked to specify what genres of movies they like (comedy, horror, action, etc.). The group owner can then start a voting session and MovieSwipe’s smart recommendation system shows movie recommendations that group members can swipe right for “interested” or left for “not interested”. The app then looks at everyone’s choices and finds the best match that most people will be happy with. When voting ends, the app shows the winning movie with its details to everyone in the group. 

