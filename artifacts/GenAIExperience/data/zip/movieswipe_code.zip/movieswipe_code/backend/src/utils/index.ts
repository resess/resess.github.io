// Helper and utility functions

