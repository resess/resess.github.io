// User domain repositories

import { UserModel, UserDocument, SessionModel, SessionDocument } from '../models/user.model';
import mongoose from 'mongoose';

export interface CreateUserData {
  googleId: string;
  email: string;
  name: string;
  profilePictureUrl?: string;
}

export interface CreateSessionData {
  userId: string;
  idToken: string;
  expiresAt: Date;
}

export const getUserByGoogleId = async (googleId: string): Promise<UserDocument | null> => {
  return await UserModel.findOne({ googleId }).exec();
};

export const createUser = async (userData: CreateUserData): Promise<UserDocument> => {
  const newUser = new UserModel(userData);
  return await newUser.save();
};

export const getUserById = async (userId: string): Promise<UserDocument | null> => {
  return await UserModel.findById(userId).exec();
};

export const createSession = async (sessionData: CreateSessionData): Promise<SessionDocument> => {
  const newSession = new SessionModel({
    userId: new mongoose.Types.ObjectId(sessionData.userId),
    idToken: sessionData.idToken,
    expiresAt: sessionData.expiresAt,
  });
  return await newSession.save();
};

export const getSessionByIdToken = async (idToken: string): Promise<SessionDocument | null> => {
  return await SessionModel.findOne({ idToken }).exec();
};

export const revokeSessionByIdToken = async (idToken: string): Promise<SessionDocument | null> => {
  return await SessionModel.findOneAndUpdate(
    { idToken, revokedAt: null },
    { revokedAt: new Date() },
    { new: true }
  ).exec();
};

export const revokeAllUserSessions = async (userId: string): Promise<void> => {
  await SessionModel.updateMany(
    { userId: new mongoose.Types.ObjectId(userId), revokedAt: null },
    { revokedAt: new Date() }
  ).exec();
};

export const getValidSessionByIdToken = async (idToken: string): Promise<SessionDocument | null> => {
  const now = new Date();
  return await SessionModel.findOne({
    idToken,
    revokedAt: null,
    expiresAt: { $gt: now },
  }).exec();
};

export const getFcmTokensByUserIds = async (userIds: string[]): Promise<string[]> => {
  if (userIds.length === 0) {
    return [];
  }

  const userObjectIds = userIds.map((userId) => new mongoose.Types.ObjectId(userId));
  
  const users = await UserModel.find({
    _id: { $in: userObjectIds },
    fcmToken: { $exists: true, $ne: null },
  })
    .select('fcmToken')
    .lean()
    .exec();

  return users
    .map((user) => (user as { fcmToken?: string }).fcmToken)
    .filter((token): token is string => token !== undefined && token.trim().length > 0);
};

export const updateUserFcmToken = async (userId: string, fcmToken: string): Promise<void> => {
  await UserModel.findByIdAndUpdate(
    new mongoose.Types.ObjectId(userId),
    { fcmToken },
    { new: true }
  ).exec();
};
