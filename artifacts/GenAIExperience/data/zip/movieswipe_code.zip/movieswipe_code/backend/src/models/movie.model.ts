// Movie domain models

import mongoose, { Schema, Document } from 'mongoose';

export interface GenreDocument extends Document {
  genreId: number;
  name: string;
  createdAt: Date;
  updatedAt: Date;
}

const genreSchema = new Schema<GenreDocument>(
  {
    genreId: {
      type: Number,
      required: true,
      unique: true,
      index: true,
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

export const GenreModel = mongoose.model<GenreDocument>('Genre', genreSchema);

