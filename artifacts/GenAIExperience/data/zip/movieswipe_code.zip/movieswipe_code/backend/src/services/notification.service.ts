// Notification services

import * as admin from 'firebase-admin';

let firebaseApp: admin.app.App | null = null;

const initializeFirebase = (): void => {
  if (firebaseApp) {
    return;
  }

  try {
    // Check if Firebase is already initialized (might be initialized elsewhere)
    try {
      const existingApps = admin.apps;
      if (existingApps.length > 0) {
        firebaseApp = existingApps[0] as admin.app.App;
        console.log('Using existing Firebase Admin app');
        return;
      }
    } catch {
      // Continue to initialize if no existing app
    }

    const serviceAccountJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
    
    if (!serviceAccountJson) {
      console.error('FIREBASE_SERVICE_ACCOUNT_JSON environment variable is not set');
      throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON environment variable is not set');
    }

    const serviceAccount = JSON.parse(serviceAccountJson);
    
    firebaseApp = admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
    });
    
    console.log('Firebase Admin initialized successfully');
  } catch (error) {
    console.error('Failed to initialize Firebase Admin:', error);
    
    // If error is about duplicate app, try to get existing app
    if (error instanceof Error && error.message.includes('already exists')) {
      try {
        firebaseApp = admin.app() as admin.app.App;
        console.log('Using existing Firebase Admin app after duplicate error');
        return;
      } catch {
        // If we can't get existing app, rethrow original error
      }
    }
    
    throw new Error(`Failed to initialize Firebase Admin: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
};

export const sendNotificationToUsers = async (
  fcmTokens: string[],
  notificationTitle: string,
  notificationBody: string,
  data?: Record<string, string>
): Promise<void> => {
  try {
    initializeFirebase();

    if (!firebaseApp) {
      console.error('Firebase Admin is not initialized');
      throw new Error('Firebase Admin is not initialized');
    }

    const validTokens = fcmTokens.filter((token) => token && token.trim().length > 0);
    
    if (validTokens.length === 0) {
      console.log('No valid FCM tokens to send notifications to');
      return;
    }

    console.log(`Sending notifications to ${validTokens.length} device(s). Tokens: ${validTokens.map((t, i) => `Token${i + 1}: ${t.substring(0, 20)}...`).join(', ')}`);

    const message: admin.messaging.MulticastMessage = {
      notification: {
        title: notificationTitle,
        body: notificationBody,
      },
      tokens: validTokens,
      ...(data && { data }),
    };

    const response = await admin.messaging().sendEachForMulticast(message);
    
    console.log(`Notifications sent. Success: ${response.successCount}, Failure: ${response.failureCount}`);
    
    if (response.failureCount > 0) {
      const failedTokens: string[] = [];
      response.responses.forEach((resp, idx) => {
        if (!resp.success) {
          const token = validTokens[idx];
          if (token) {
            console.error(`Failed to send to token ${idx}:`, resp.error?.message);
            failedTokens.push(token);
          }
        }
      });
      
      if (response.successCount === 0) {
        throw new Error('All notifications failed to send');
      }
    }
  } catch (error) {
    console.error('Error sending notifications:', error);
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to send notifications');
  }
};
