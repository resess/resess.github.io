// VotingGroup domain models

import mongoose, { Schema, Document } from 'mongoose';

export interface Vote {
  userId: mongoose.Types.ObjectId;
  movieId: number;
  voteType: 'like' | 'dislike';
  votedAt: Date;
}

export interface SelectedMovie {
  movieId: number;
  title: string;
  posterUrl?: string;
  genres: number[];
  rating: number;
  length: number;
  summary: string;
}

export interface VotingSession {
  state: 'notStarted' | 'started' | 'ended';
  startedAt?: Date;
  endedAt?: Date;
  moviesToVoteOn: SelectedMovie[];
  votes: Vote[];
  selectedMovie?: SelectedMovie;
}

export interface MemberGenrePreferences {
  userId: mongoose.Types.ObjectId;
  genres: number[];
}

export interface VotingGroupDocument extends Document {
  name: string;
  ownerId: mongoose.Types.ObjectId;
  members: mongoose.Types.ObjectId[];
  genrePreferences: number[];
  memberGenrePreferences: MemberGenrePreferences[];
  invitationCode: string;
  votingSession: VotingSession;
  createdAt: Date;
  updatedAt: Date;
}

const voteSchema = new Schema<Vote>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    movieId: {
      type: Number,
      required: true,
    },
    voteType: {
      type: String,
      enum: ['like', 'dislike'],
      required: true,
    },
    votedAt: {
      type: Date,
      required: true,
      default: Date.now,
    },
  },
  {
    _id: false,
  }
);

const selectedMovieSchema = new Schema<SelectedMovie>(
  {
    movieId: {
      type: Number,
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    posterUrl: {
      type: String,
      required: false,
    },
    genres: {
      type: [Number],
      required: true,
    },
    rating: {
      type: Number,
      required: true,
    },
    length: {
      type: Number,
      required: true,
    },
    summary: {
      type: String,
      required: true,
    },
  },
  {
    _id: false,
  }
);

const votingSessionSchema = new Schema<VotingSession>(
  {
    state: {
      type: String,
      enum: ['notStarted', 'started', 'ended'],
      required: true,
      default: 'notStarted',
    },
    startedAt: {
      type: Date,
      required: false,
    },
    endedAt: {
      type: Date,
      required: false,
    },
    moviesToVoteOn: {
      type: [selectedMovieSchema],
      default: [],
    },
    votes: {
      type: [voteSchema],
      default: [],
    },
    selectedMovie: {
      type: selectedMovieSchema,
      required: false,
    },
  },
  {
    _id: false,
  }
);

const memberGenrePreferencesSchema = new Schema<MemberGenrePreferences>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    genres: {
      type: [Number],
      required: true,
      validate: {
        validator: (value: number[]) => value.length > 0,
        message: 'At least one genre preference is required.',
      },
    },
  },
  {
    _id: false,
  }
);

const votingGroupSchema = new Schema<VotingGroupDocument>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      minlength: 3,
      maxlength: 30,
      validate: {
        validator: (value: string) => /^[a-zA-Z0-9]+$/.test(value),
        message: 'Group name must be 3-30 alphanumeric characters.',
      },
    },
    ownerId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    members: {
      type: [Schema.Types.ObjectId],
      ref: 'User',
      default: [],
      index: true,
    },
    genrePreferences: {
      type: [Number],
      required: true,
      validate: {
        validator: (value: number[]) => value.length >= 2,
        message: 'At least two genre preferences are required.',
      },
    },
    memberGenrePreferences: {
      type: [memberGenrePreferencesSchema],
      default: [],
    },
    invitationCode: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    votingSession: {
      type: votingSessionSchema,
      required: true,
      default: () => ({
        state: 'notStarted',
        moviesToVoteOn: [],
        votes: [],
      }),
    },
  },
  {
    timestamps: true,
  }
);

// Compound index for efficient vote queries (checking if a user has voted on a specific movie)
votingGroupSchema.index(
  { 'votingSession.votes.userId': 1, 'votingSession.votes.movieId': 1 },
  { sparse: true }
);

export const VotingGroupModel = mongoose.model<VotingGroupDocument>(
  'VotingGroup',
  votingGroupSchema
);

