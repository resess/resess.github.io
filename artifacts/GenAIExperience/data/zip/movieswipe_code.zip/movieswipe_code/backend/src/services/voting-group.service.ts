// VotingGroup domain services

import { createVotingGroup, CreateVotingGroupData, getGroupsByUserId, GroupWithRole, getGroupDetailsById, GroupDetails, deleteGroupById, getGroupByInvitationCode, GroupByInvitationCodeResult, getGroupGenresByInvitationCode, GroupGenresResult, joinGroupByInvitationCode, JoinGroupData, JoinGroupResult, leaveGroupById, LeaveGroupResult, getGroupForStartingVotingSession, startVotingSession as startVotingSessionRepository, StartVotingSessionData, getNextMovieToVoteOn as getNextMovieToVoteOnRepository, submitVote as submitVoteRepository, SubmitVoteData, SubmitVoteResult, getVotingSessionState as getVotingSessionStateRepository, VotingSessionState, endVotingSession as endVotingSessionRepository } from '../repositories/voting-group.repository';
import { VotingGroupDocument, VotingGroupModel } from '../models/voting-group.model';
import mongoose from 'mongoose';
import { getFcmTokensByUserIds, getUserById } from '../repositories/user.repository';
import { sendNotificationToUsers } from './notification.service';
import { selectMoviesForVotingSession } from './movie.service';
import type { GroupDeletionNotificationData, UserJoiningGroupNotificationData, UserLeavingGroupNotificationData } from '../types';

export interface CreateGroupInput {
  name: string;
  ownerId: string;
  genrePreferences: number[];
}

const validateGroupName = (name: string): void => {
  if (!name || name.trim().length === 0) {
    throw new Error('Group name is required and must be 3-30 alphanumeric characters.');
  }
  if (name.length < 3 || name.length > 30) {
    throw new Error('Group name is required and must be 3-30 alphanumeric characters.');
  }
  if (!/^[a-zA-Z0-9]+$/.test(name)) {
    throw new Error('Group name is required and must be 3-30 alphanumeric characters.');
  }
};

const validateGenrePreferences = (genrePreferences: number[], isOwner: boolean = true): void => {
  if (!genrePreferences || genrePreferences.length === 0) {
    if (isOwner) {
      throw new Error('Genre selection is required. Please choose at least two preferred movie genres.');
    } else {
      throw new Error('Genre selection is required. Please choose at least one preferred movie genre.');
    }
  }
  if (isOwner && genrePreferences.length < 2) {
    throw new Error('Genre selection is required. Please choose at least two preferred movie genres.');
  }
};

export const createGroup = async (input: CreateGroupInput): Promise<VotingGroupDocument> => {
  validateGroupName(input.name);
  validateGenrePreferences(input.genrePreferences, true);

  try {
    const votingGroupData: CreateVotingGroupData = {
      name: input.name.trim(),
      ownerId: input.ownerId,
      genrePreferences: input.genrePreferences,
    };
    return await createVotingGroup(votingGroupData);
  } catch (error) {
    if (error instanceof Error && error.message.includes('Group name')) {
      throw error;
    }
    if (error instanceof Error && error.message.includes('genre')) {
      throw error;
    }
    if (error instanceof Error && error.message.includes('invitation code')) {
      throw error;
    }
    console.error('Error creating group:', error);
    throw new Error('Failed to create group. Please try again.');
  }
};

export const getGroupsList = async (userId: string): Promise<GroupWithRole[]> => {
  try {
    return await getGroupsByUserId(userId);
  } catch (error) {
    throw new Error('Failed to load groups. Please retry.');
  }
};

export const getGroupDetails = async (
  groupId: string,
  userId: string
): Promise<GroupDetails> => {
  try {
    return await getGroupDetailsById(groupId, userId);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'This group has been deleted.') {
        throw error;
      }
      if (error.message === 'You are no longer a member of this group.') {
        throw error;
      }
    }
    throw new Error('Failed to load group information.');
  }
};

export type { GroupDetails } from '../repositories/voting-group.repository';

export interface DeleteGroupResult {
  notificationSent: boolean;
}

export const deleteGroup = async (
  groupId: string,
  userId: string
): Promise<DeleteGroupResult> => {
  try {
    const deleteResult = await deleteGroupById(groupId, userId);

    let notificationSent = false;

    // If there are no members, there's no one to notify - this is success
    if (deleteResult.memberIds.length === 0) {
      console.log('Group has no members - no notifications needed');
      return {
        notificationSent: true, // Success because there's no one to notify
      };
    }

    // Safety check: ensure the owner (userId) is not in the memberIds list
    // The repository should already exclude the owner, but we add this check for extra safety
    const memberIdsToNotify = deleteResult.memberIds.filter((memberId) => memberId !== userId);
    
    if (memberIdsToNotify.length !== deleteResult.memberIds.length) {
      console.warn(`Warning: Owner (${userId}) was found in memberIds list. Filtered out.`);
    }

    if (memberIdsToNotify.length === 0) {
      console.log('No members to notify after filtering out owner');
      return {
        notificationSent: true, // Success because there's no one to notify
      };
    }

    try {
      // Send individual notifications to each member with their own recipientUserId
      // This ensures each member receives the notification with their specific recipientUserId
      const notificationPromises = memberIdsToNotify.map(async (memberId) => {
        const memberFcmTokens = await getFcmTokensByUserIds([memberId]);
        
        if (memberFcmTokens.length > 0) {
          const notificationMessage = `Group ${deleteResult.groupName} has been deleted by the owner.`;
          const notificationData: Record<string, string> = {
            notificationType: 'groupDeleted',
            groupId: deleteResult.groupId,
            groupName: deleteResult.groupName,
            recipientUserId: memberId, // Each member gets their own recipientUserId
          };
          
          console.log(`Sending notification to member (${memberId}) with ${memberFcmTokens.length} FCM token(s). Group owner is ${userId}.`);
          
          await sendNotificationToUsers(memberFcmTokens, 'Group Deleted', notificationMessage, notificationData);
          return true;
        } else {
          console.log(`No FCM token found for member (${memberId}) - member may not have registered token yet`);
          return false;
        }
      });

      const notificationResults = await Promise.allSettled(notificationPromises);
      
      // Consider it successful if at least one notification was sent
      const successfulNotifications = notificationResults.filter(
        (result) => result.status === 'fulfilled' && result.value === true
      ).length;
      
      if (successfulNotifications > 0) {
        notificationSent = true;
        console.log(`Notifications sent successfully to ${successfulNotifications} out of ${memberIdsToNotify.length} member(s)`);
      } else {
        console.log('No notifications were sent - members may not have registered tokens yet');
      }
      
      // Log any failures
      notificationResults.forEach((result, index) => {
        if (result.status === 'rejected') {
          console.error(`Failed to send notification to member ${memberIdsToNotify[index]}:`, result.reason);
        }
      });
    } catch (notificationError) {
      console.error('Error sending notifications:', notificationError);
      notificationSent = false;
    }

    return {
      notificationSent,
    };
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'This group has been deleted.') {
        throw new Error('This group has been deleted.');
      }
      if (error.message === 'Only the group owner can delete the group.') {
        throw new Error('Only the group owner can delete the group.');
      }
    }
    throw new Error('Failed to delete group. Please try again.');
  }
};

export interface ValidateInvitationCodeResult {
  groupId: string;
  groupName: string;
}

export const validateInvitationCode = async (
  invitationCode: string,
  userId: string
): Promise<ValidateInvitationCodeResult> => {
  try {
    const groupResult = await getGroupByInvitationCode(invitationCode, userId);
    return {
      groupId: groupResult.id,
      groupName: groupResult.name,
    };
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'Invalid invitation code. Please check the code and try again.') {
        throw error;
      }
      if (error.message === 'You are already a member of this group') {
        const groupId = (error as any).groupId;
        if (groupId) {
          const alreadyMemberError = new Error('You are already a member of this group');
          (alreadyMemberError as any).groupId = groupId;
          throw alreadyMemberError;
        }
        throw error;
      }
    }
    throw new Error('Failed to validate invitation code. Please try again.');
  }
};

export const getGroupGenres = async (
  invitationCode: string
): Promise<GroupGenresResult> => {
  try {
    return await getGroupGenresByInvitationCode(invitationCode);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'Invalid invitation code. Please check the code and try again.') {
        throw error;
      }
    }
    throw new Error('Failed to load movie genres. Please try again.');
  }
};

export interface JoinGroupInput {
  invitationCode: string;
  userId: string;
  genrePreferences: number[];
}

export interface JoinGroupServiceResult {
  groupId: string;
  notificationSent: boolean;
}

export const joinGroup = async (
  input: JoinGroupInput
): Promise<JoinGroupServiceResult> => {
  validateGenrePreferences(input.genrePreferences, false);

  try {
    const joinData: JoinGroupData = {
      invitationCode: input.invitationCode,
      userId: input.userId,
      genrePreferences: input.genrePreferences,
    };

    const joinResult = await joinGroupByInvitationCode(joinData);

    let notificationSent = false;

    try {
      // Fetch the group directly from the database to get the actual owner ID
      // This ensures we have the correct owner ID regardless of any edge cases
      // We do this to guarantee that only the group owner receives the notification,
      // not the joining user or any other members
      const group = await VotingGroupModel.findById(new mongoose.Types.ObjectId(joinResult.groupId))
        .select('ownerId')
        .lean()
        .exec();
      
      if (!group) {
        console.error('Group not found after join - cannot send notification');
        notificationSent = false;
      } else {
        const actualOwnerId = (group.ownerId as mongoose.Types.ObjectId).toString();
        
        // Verify that ownerId is not the joining user (safety check)
        if (actualOwnerId === input.userId) {
          console.error(`Error: ownerId (${actualOwnerId}) matches joining userId (${input.userId}) - skipping notification to prevent sending to wrong user`);
          notificationSent = false;
        } else {
          // Send notification to the group owner (not the joining user or other members)
          // Get the owner's FCM tokens - these are tokens registered to the owner's user account
          const ownerFcmTokens = await getFcmTokensByUserIds([actualOwnerId]);
          
          if (ownerFcmTokens.length > 0) {
            const joiningUser = await getUserById(input.userId);
            const userName = joiningUser?.name ?? 'Someone';
            const notificationMessage = `${userName} has joined the group ${joinResult.groupName}`;
            const notificationData: Record<string, string> = {
              notificationType: 'userJoinedGroup',
              groupId: joinResult.groupId,
              groupName: joinResult.groupName,
              recipientUserId: actualOwnerId,
            };
            
            console.log(`Sending notification to group owner (${actualOwnerId}) with ${ownerFcmTokens.length} FCM token(s). Joining user is ${input.userId}.`);
            
            await sendNotificationToUsers(ownerFcmTokens, 'New Group Member', notificationMessage, notificationData);
            notificationSent = true;
            console.log(`Notification sent to group owner (${actualOwnerId}) successfully - joining user was ${input.userId}`);
          } else {
            console.log(`No FCM token found for group owner (${actualOwnerId}) - owner may not have registered token yet`);
          }
        }
      }
    } catch (notificationError) {
      console.error('Error sending notification to group owner:', notificationError);
      notificationSent = false;
    }

    return {
      groupId: joinResult.groupId,
      notificationSent,
    };
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'Invalid invitation code. Please check the code and try again.') {
        throw error;
      }
      if (error.message === 'You are already a member of this group') {
        const groupId = (error as any).groupId;
        if (groupId) {
          const alreadyMemberError = new Error('You are already a member of this group');
          (alreadyMemberError as any).groupId = groupId;
          throw alreadyMemberError;
        }
        throw error;
      }
      if (error.message === 'Genre selection is required. Please choose at least one preferred movie genre.') {
        throw error;
      }
      if (error.message.includes('Invalid genre selection')) {
        throw error;
      }
    }
    throw new Error('Failed to join group. Please try again.');
  }
};

export interface LeaveGroupServiceResult {
  notificationSent: boolean;
}

export const leaveGroup = async (
  groupId: string,
  userId: string
): Promise<LeaveGroupServiceResult> => {
  try {
    const leaveResult = await leaveGroupById(groupId, userId);

    let notificationSent = false;

    try {
      // Verify that ownerId is not the leaving user (safety check)
      // The repository already prevents owners from leaving, but we add this check for extra safety
      if (leaveResult.ownerId === userId) {
        console.error(`Error: ownerId (${leaveResult.ownerId}) matches leaving userId (${userId}) - skipping notification to prevent sending to wrong user`);
        notificationSent = false;
      } else {
        // Send notification to the group owner (not the leaving user or other members)
        // Get the owner's FCM tokens - these are tokens registered to the owner's user account
        const ownerFcmTokens = await getFcmTokensByUserIds([leaveResult.ownerId]);
        
        if (ownerFcmTokens.length > 0) {
          const notificationMessage = `${leaveResult.userName} has left the group ${leaveResult.groupName}`;
          const notificationData: Record<string, string> = {
            notificationType: 'userLeftGroup',
            groupId: leaveResult.groupId,
            groupName: leaveResult.groupName,
            recipientUserId: leaveResult.ownerId, // Added recipientUserId
          };
          
          console.log(`Sending notification to group owner (${leaveResult.ownerId}) with ${ownerFcmTokens.length} FCM token(s). Leaving user is ${userId}.`);
          
          await sendNotificationToUsers(ownerFcmTokens, 'Member Left Group', notificationMessage, notificationData);
          notificationSent = true;
          console.log(`Notification sent to group owner (${leaveResult.ownerId}) successfully - leaving user was ${userId}`);
        } else {
          console.log(`No FCM token found for group owner (${leaveResult.ownerId}) - owner may not have registered token yet`);
        }
      }
    } catch (notificationError) {
      console.error('Error sending notification to group owner:', notificationError);
      notificationSent = false;
    }

    return {
      notificationSent,
    };
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'This group has been deleted.') {
        throw error;
      }
      if (error.message === 'Group owners cannot leave the group. Please delete the group instead.') {
        throw error;
      }
      if (error.message === 'You are not a member of this group.') {
        throw error;
      }
      if (error.message === 'User not found.') {
        throw error;
      }
    }
    throw new Error('Failed to leave group. Please try again.');
  }
};

export interface StartVotingSessionServiceResult {
  groupDetails: GroupDetails;
  notificationSent: boolean;
}

export const startVotingSession = async (
  groupId: string,
  userId: string
): Promise<StartVotingSessionServiceResult> => {
  try {
    const groupInfo = await getGroupForStartingVotingSession(groupId, userId);

    let selectedMovies;
    try {
      const memberGenrePreferences = groupInfo.memberGenrePreferences.map((pref) => ({
        userId: pref.userId,
        genres: pref.genres,
      }));

      selectedMovies = await selectMoviesForVotingSession(
        groupInfo.ownerGenrePreferences,
        memberGenrePreferences
      );
    } catch (error) {
      if (error instanceof Error && error.message.includes('Failed to load movies')) {
        throw new Error('Failed to load movies. Please try again.');
      }
      console.error('Error selecting movies:', error);
      throw new Error('Failed to load movies. Please try again.');
    }

    const startVotingSessionData: StartVotingSessionData = {
      groupId: groupInfo.id,
      movies: selectedMovies,
    };

    const startResult = await startVotingSessionRepository(startVotingSessionData, userId);

    let notificationSent = false;

    try {
      // Get all member IDs (includes owner + members) and exclude the owner from notification recipients
      // since they triggered the action. All other members should receive the notification.
      const memberIdsToNotify = groupInfo.allMemberIds.filter((memberId) => memberId !== userId);
      
      if (memberIdsToNotify.length > 0) {
        const fcmTokens = await getFcmTokensByUserIds(memberIdsToNotify);

        console.log(`Found ${fcmTokens.length} FCM tokens for ${memberIdsToNotify.length} members to notify`);

        if (fcmTokens.length > 0) {
          const notificationMessage = `Group ${startResult.groupName}'s voting session has started`;
          await sendNotificationToUsers(
            fcmTokens,
            'Voting Session Started',
            notificationMessage,
            {
              groupId,
              notificationType: 'votingSessionStarted',
            }
          );
          notificationSent = true;
          console.log('Notifications sent successfully to group members');
        } else {
          console.log(
            'No FCM tokens found for group members - members may not have registered tokens yet'
          );
        }
      } else {
        console.log('No members to notify - group has no members other than the owner');
      }
    } catch (notificationError) {
      console.error('Error sending notifications:', notificationError);
      notificationSent = false;
    }

    const groupDetails = await getGroupDetailsById(groupId, userId);

    return {
      groupDetails,
      notificationSent,
    };
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'This group has been deleted.') {
        throw error;
      }
      if (error.message === 'Only the group owner can start a voting session.') {
        throw error;
      }
      if (error.message === 'A voting session is already in progress for this group.') {
        throw error;
      }
      if (error.message === 'Failed to load movies. Please try again.') {
        throw error;
      }
    }
    console.error('Error starting voting session:', error);
    throw new Error('Failed to start voting session. Please try again.');
  }
};

export interface GetNextMovieToVoteOnResult {
  movie: {
    movieId: number;
    title: string;
    posterUrl?: string;
    genres: number[];
    rating: number;
    length: number;
    summary: string;
  } | null;
  hasVotedOnAllMovies: boolean;
}

export const getNextMovieToVoteOn = async (
  groupId: string,
  userId: string
): Promise<GetNextMovieToVoteOnResult> => {
  try {
    const result = await getNextMovieToVoteOnRepository(groupId, userId);
    return {
      movie: result.movie,
      hasVotedOnAllMovies: result.hasVotedOnAllMovies,
    };
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'This group has been deleted.') {
        throw error;
      }
      if (error.message === 'The voting session has ended.') {
        throw error;
      }
      if (error.message === 'You are no longer a member of this group.') {
        throw error;
      }
    }
    throw new Error('Failed to load next movie. Please try again.');
  }
};

export interface SubmitVoteInput {
  groupId: string;
  userId: string;
  movieId: number;
  voteType: 'like' | 'dislike';
}

export interface SubmitVoteServiceResult {
  hasVotedOnAllMovies: boolean;
}

export const submitVoteForMovie = async (
  input: SubmitVoteInput
): Promise<SubmitVoteServiceResult> => {
  if (input.voteType !== 'like' && input.voteType !== 'dislike') {
    throw new Error('Invalid vote type. Vote must be either "like" or "dislike".');
  }

  try {
    const submitVoteData: SubmitVoteData = {
      groupId: input.groupId,
      userId: input.userId,
      movieId: input.movieId,
      voteType: input.voteType,
    };

    const result = await submitVoteRepository(submitVoteData);
    return {
      hasVotedOnAllMovies: result.hasVotedOnAllMovies,
    };
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'This group has been deleted.') {
        throw error;
      }
      if (error.message === 'The voting session has ended.') {
        throw error;
      }
      if (error.message === 'You are no longer a member of this group.') {
        throw error;
      }
      if (error.message === 'This movie is not part of the voting session.') {
        throw error;
      }
    }
    throw new Error('Failed to submit vote. Please try again.');
  }
};

export const getVotingSessionStateForGroup = async (
  groupId: string
): Promise<VotingSessionState> => {
  try {
    return await getVotingSessionStateRepository(groupId);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'This group has been deleted.') {
        throw error;
      }
    }
    throw new Error('Failed to get voting session state. Please try again.');
  }
};

export interface EndVotingSessionServiceResult {
  groupDetails: GroupDetails;
  notificationSent: boolean;
}

export const endVotingSession = async (
  groupId: string,
  userId: string
): Promise<EndVotingSessionServiceResult> => {
  try {
    const endResult = await endVotingSessionRepository(groupId, userId);

    let notificationSent = false;

    try {
      // Exclude the owner from notification recipients since they triggered the action
      const memberIdsToNotify = endResult.memberIds.filter((memberId) => memberId !== userId);
      
      if (memberIdsToNotify.length > 0) {
        const fcmTokens = await getFcmTokensByUserIds(memberIdsToNotify);

        console.log(`Found ${fcmTokens.length} FCM tokens for ${memberIdsToNotify.length} members to notify`);

        if (fcmTokens.length > 0) {
          const notificationMessage = `Group ${endResult.groupName}'s selected movie is out!`;
          await sendNotificationToUsers(
            fcmTokens,
            'Voting Session Ended',
            notificationMessage,
            {
              groupId,
              notificationType: 'votingSessionEnded',
            }
          );
          notificationSent = true;
          console.log('Notifications sent successfully to group members');
        } else {
          console.log(
            'No FCM tokens found for group members - members may not have registered tokens yet'
          );
        }
      } else {
        console.log('No members to notify - group has no members other than the owner');
      }
    } catch (notificationError) {
      console.error('Error sending notifications:', notificationError);
      notificationSent = false;
    }

    const groupDetails = await getGroupDetailsById(groupId, userId);

    return {
      groupDetails,
      notificationSent,
    };
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'This group has been deleted.') {
        throw error;
      }
      if (error.message === 'Only the group owner can end the voting session.') {
        throw error;
      }
      if (error.message === 'A voting session is not currently in progress for this group.') {
        throw error;
      }
      if (error.message === 'No movies available in the voting session.') {
        throw error;
      }
      if (error.message === 'Failed to determine the selected movie.') {
        throw error;
      }
      if (error.message === 'You are no longer a member of this group.') {
        throw error;
      }
    }
    console.error('Error ending voting session:', error);
    throw new Error('Failed to end the voting session. Please try again.');
  }
};

