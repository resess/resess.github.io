// Movie domain routes

import { Router } from 'express';
import { getGenresController } from '../controllers/movie.controller';

const router = Router();

router.get('/genres', getGenresController);

export default router;

