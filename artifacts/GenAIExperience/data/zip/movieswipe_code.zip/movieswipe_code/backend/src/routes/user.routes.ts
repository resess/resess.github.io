// User domain routes

import { Router } from 'express';
import { signIn, signOutController, registerFcmTokenController } from '../controllers/user.controller';

const router = Router();

router.post('/sign-in', signIn);
router.post('/sign-out', signOutController);
router.post('/register-fcm-token', registerFcmTokenController);

export default router;
