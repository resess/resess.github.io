// VotingGroup domain routes

import { Router } from 'express';
import { createGroupController, getGroupsListController, getGroupDetailsController, deleteGroupController, validateInvitationCodeController, getGroupGenresController, joinGroupController, leaveGroupController, startVotingSessionController, getNextMovieToVoteOnController, submitVoteController, endVotingSessionController } from '../controllers/voting-group.controller';

const router = Router();

router.post('/', createGroupController);
router.get('/', getGroupsListController);
router.post('/validate-invitation-code', validateInvitationCodeController);
router.get('/genres/by-invitation-code', getGroupGenresController);
router.post('/join', joinGroupController);
router.post('/:groupId/leave', leaveGroupController);
router.post('/:groupId/start-voting-session', startVotingSessionController);
router.post('/:groupId/end-voting-session', endVotingSessionController);
router.get('/:groupId/next-movie-to-vote-on', getNextMovieToVoteOnController);
router.post('/:groupId/vote', submitVoteController);
router.get('/:groupId', getGroupDetailsController);
router.delete('/:groupId', deleteGroupController);

export default router;

