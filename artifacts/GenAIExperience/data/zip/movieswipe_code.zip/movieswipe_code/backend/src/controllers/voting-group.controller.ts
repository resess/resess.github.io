// VotingGroup domain controllers

import { Request, Response } from 'express';
import { createGroup, CreateGroupInput, getGroupsList, getGroupDetails, deleteGroup, validateInvitationCode, getGroupGenres, joinGroup, leaveGroup, startVotingSession, getNextMovieToVoteOn, submitVoteForMovie, endVotingSession } from '../services/voting-group.service';

interface CreateGroupRequest {
  name: string;
  genrePreferences: number[];
  userId: string;
}

export const createGroupController = async (req: Request, res: Response): Promise<void> => {
  try {
    const { name, genrePreferences, userId } = req.body as CreateGroupRequest;

    if (!userId) {
      res.status(401).json({ error: 'User authentication required' });
      return;
    }

    if (!name) {
      res.status(400).json({ error: 'Group name is required and must be 3-30 alphanumeric characters.' });
      return;
    }

    if (!genrePreferences || genrePreferences.length === 0) {
      res.status(400).json({ error: 'Genre selection is required. Please choose at least two preferred movie genres.' });
      return;
    }

    if (genrePreferences.length < 2) {
      res.status(400).json({ error: 'Genre selection is required. Please choose at least two preferred movie genres.' });
      return;
    }

    const input: CreateGroupInput = {
      name,
      ownerId: userId,
      genrePreferences,
    };

    const votingGroup = await createGroup(input);
    
    res.status(201).json({
      id: votingGroup.id,
      name: votingGroup.name,
      ownerId: votingGroup.ownerId.toString(),
      genrePreferences: votingGroup.genrePreferences,
      createdAt: votingGroup.createdAt,
      updatedAt: votingGroup.updatedAt,
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage.includes('Group name is required')) {
      res.status(400).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage.includes('Genre selection is required')) {
      res.status(400).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage.includes('Failed to create group')) {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'An unexpected error occurred' });
  }
};

export const getGroupsListController = async (req: Request, res: Response): Promise<void> => {
  try {
    const userId = req.query.userId as string | undefined;

    if (!userId) {
      res.status(401).json({ error: 'User authentication required' });
      return;
    }

    const groups = await getGroupsList(userId);
    
    res.status(200).json(groups);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage.includes('Failed to load groups')) {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'An unexpected error occurred' });
  }
};

export const getGroupDetailsController = async (req: Request, res: Response): Promise<void> => {
  try {
    const groupId = req.params.groupId as string | undefined;
    const userId = req.query.userId as string | undefined;

    if (!userId) {
      res.status(401).json({ error: 'User authentication required' });
      return;
    }

    if (!groupId) {
      res.status(400).json({ error: 'Group ID is required' });
      return;
    }

    const groupDetails = await getGroupDetails(groupId, userId);
    
    res.status(200).json(groupDetails);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage === 'This group has been deleted.') {
      res.status(404).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'You are no longer a member of this group.') {
      res.status(403).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'Failed to load group information.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'An unexpected error occurred' });
  }
};

export const deleteGroupController = async (req: Request, res: Response): Promise<void> => {
  try {
    const groupId = req.params.groupId as string | undefined;
    const userId = req.query.userId as string | undefined;

    if (!userId) {
      res.status(401).json({ error: 'User authentication required' });
      return;
    }

    if (!groupId) {
      res.status(400).json({ error: 'Group ID is required' });
      return;
    }

    const deleteResult = await deleteGroup(groupId, userId);
    
    if (!deleteResult.notificationSent) {
      res.status(200).json({
        message: 'You deleted the group successfully but members could not be notified. You might want to contact them directly.',
      });
      return;
    }

    res.status(200).json({
      message: 'Group deleted successfully.',
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage === 'This group has been deleted.') {
      res.status(404).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'Only the group owner can delete the group.') {
      res.status(403).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'Failed to delete group. Please try again.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'Failed to delete group. Please try again.' });
  }
};

interface ValidateInvitationCodeRequest {
  invitationCode: string;
  userId: string;
}

export const validateInvitationCodeController = async (req: Request, res: Response): Promise<void> => {
  try {
    const { invitationCode, userId } = req.body as ValidateInvitationCodeRequest;

    if (!userId) {
      res.status(401).json({ error: 'User authentication required' });
      return;
    }

    if (!invitationCode) {
      res.status(400).json({ error: 'Invitation code is required' });
      return;
    }

    const result = await validateInvitationCode(invitationCode, userId);
    
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage === 'Invalid invitation code. Please check the code and try again.') {
      res.status(400).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'You are already a member of this group') {
      const groupId = (error as any).groupId;
      if (groupId) {
        res.status(400).json({ error: errorMessage, groupId });
      } else {
        res.status(400).json({ error: errorMessage });
      }
      return;
    }
    
    if (errorMessage === 'Failed to validate invitation code. Please try again.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'An unexpected error occurred' });
  }
};

export const getGroupGenresController = async (req: Request, res: Response): Promise<void> => {
  try {
    const invitationCode = req.query.invitationCode as string | undefined;

    if (!invitationCode) {
      res.status(400).json({ error: 'Invitation code is required' });
      return;
    }

    const result = await getGroupGenres(invitationCode);
    
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage === 'Invalid invitation code. Please check the code and try again.') {
      res.status(400).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'Failed to load movie genres. Please try again.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'Failed to load movie genres. Please try again.' });
  }
};

interface JoinGroupRequest {
  invitationCode: string;
  userId: string;
  genrePreferences: number[];
}

export const joinGroupController = async (req: Request, res: Response): Promise<void> => {
  try {
    const { invitationCode, userId, genrePreferences } = req.body as JoinGroupRequest;

    if (!userId) {
      res.status(401).json({ error: 'User authentication required' });
      return;
    }

    if (!invitationCode) {
      res.status(400).json({ error: 'Invitation code is required' });
      return;
    }

    if (!genrePreferences || genrePreferences.length === 0) {
      res.status(400).json({ error: 'Genre selection is required. Please choose at least one preferred movie genre.' });
      return;
    }

    const result = await joinGroup({
      invitationCode,
      userId,
      genrePreferences,
    });
    
    if (!result.notificationSent) {
      res.status(200).json({
        groupId: result.groupId,
        message: 'You joined the group successfully but the owner could not be notified. You might want to contact them directly.',
      });
      return;
    }

    res.status(200).json({
      groupId: result.groupId,
      message: 'Successfully joined the group.',
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage === 'Invalid invitation code. Please check the code and try again.') {
      res.status(400).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'You are already a member of this group') {
      const groupId = (error as any).groupId;
      if (groupId) {
        res.status(400).json({ error: errorMessage, groupId });
      } else {
        res.status(400).json({ error: errorMessage });
      }
      return;
    }
    
    if (errorMessage === 'Genre selection is required. Please choose at least one preferred movie genre.') {
      res.status(400).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage.includes('Invalid genre selection')) {
      res.status(400).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'Failed to join group. Please try again.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'Failed to join group. Please try again.' });
  }
};

export const leaveGroupController = async (req: Request, res: Response): Promise<void> => {
  try {
    const groupId = req.params.groupId as string | undefined;
    const userId = req.query.userId as string | undefined;

    if (!userId) {
      res.status(401).json({ error: 'User authentication required' });
      return;
    }

    if (!groupId) {
      res.status(400).json({ error: 'Group ID is required' });
      return;
    }

    const leaveResult = await leaveGroup(groupId, userId);
    
    if (!leaveResult.notificationSent) {
      res.status(200).json({
        message: 'You left the group successfully but the group owner could not be notified. You might want to contact them directly.',
      });
      return;
    }

    res.status(200).json({
      message: 'Successfully left the group.',
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage === 'This group has been deleted.') {
      res.status(404).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'Group owners cannot leave the group. Please delete the group instead.') {
      res.status(403).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'You are not a member of this group.') {
      res.status(403).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'User not found.') {
      res.status(404).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'Failed to leave group. Please try again.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'Failed to leave group. Please try again.' });
  }
};

export const startVotingSessionController = async (req: Request, res: Response): Promise<void> => {
  const groupId = req.params.groupId as string | undefined;
  const userId = req.query.userId as string | undefined;

  if (!userId) {
    res.status(401).json({ error: 'User authentication required' });
    return;
  }

  if (!groupId) {
    res.status(400).json({ error: 'Group ID is required' });
    return;
  }

  try {
    const result = await startVotingSession(groupId, userId);

    if (!result.notificationSent) {
      res.status(200).json({
        ...result.groupDetails,
        message: 'You started the voting session successfully but members could not be notified. You might want to contact them directly.',
      });
      return;
    }

    res.status(200).json(result.groupDetails);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';

    if (errorMessage === 'This group has been deleted.') {
      res.status(404).json({ error: errorMessage });
      return;
    }

    if (errorMessage === 'Only the group owner can start a voting session.') {
      res.status(403).json({ error: errorMessage });
      return;
    }

    if (errorMessage === 'A voting session is already in progress for this group.') {
      res.status(400).json({ error: errorMessage });
      return;
    }

    if (errorMessage === 'Failed to load movies. Please try again.') {
      try {
        const groupDetails = await getGroupDetails(groupId, userId);
        res.status(200).json({
          ...groupDetails,
          error: 'Failed to load movies. Please try again.',
        });
      } catch (detailsError) {
        res.status(500).json({ error: 'Failed to load movies. Please try again.' });
      }
      return;
    }

    if (errorMessage === 'Failed to start voting session. Please try again.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'Failed to start voting session. Please try again.' });
  }
};

export const getNextMovieToVoteOnController = async (req: Request, res: Response): Promise<void> => {
  try {
    const groupId = req.params.groupId as string | undefined;
    const userId = req.query.userId as string | undefined;

    if (!userId) {
      res.status(401).json({ error: 'User authentication required' });
      return;
    }

    if (!groupId) {
      res.status(400).json({ error: 'Group ID is required' });
      return;
    }

    const result = await getNextMovieToVoteOn(groupId, userId);
    
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage === 'This group has been deleted.') {
      res.status(404).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'The voting session has ended.') {
      res.status(400).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'You are no longer a member of this group.') {
      res.status(403).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'Failed to load next movie. Please try again.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'An unexpected error occurred' });
  }
};

interface SubmitVoteRequest {
  movieId: number;
  voteType: 'like' | 'dislike';
  userId: string;
}

export const submitVoteController = async (req: Request, res: Response): Promise<void> => {
  try {
    const groupId = req.params.groupId as string | undefined;
    const { movieId, voteType, userId } = req.body as SubmitVoteRequest;

    if (!userId) {
      res.status(401).json({ error: 'User authentication required' });
      return;
    }

    if (!groupId) {
      res.status(400).json({ error: 'Group ID is required' });
      return;
    }

    if (!movieId) {
      res.status(400).json({ error: 'Movie ID is required' });
      return;
    }

    if (!voteType) {
      res.status(400).json({ error: 'Vote type is required' });
      return;
    }

    if (voteType !== 'like' && voteType !== 'dislike') {
      res.status(400).json({ error: 'Swipe right for "interested" or left for "not interested". No other swiping gesture allowed.' });
      return;
    }

    const result = await submitVoteForMovie({
      groupId,
      userId,
      movieId,
      voteType,
    });
    
    res.status(200).json(result);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage === 'This group has been deleted.') {
      res.status(404).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'The voting session has ended.') {
      res.status(400).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'You are no longer a member of this group.') {
      res.status(403).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'This movie is not part of the voting session.') {
      res.status(400).json({ error: errorMessage });
      return;
    }
    
    if (errorMessage === 'Invalid vote type. Vote must be either "like" or "dislike".') {
      res.status(400).json({ error: 'Swipe right for "interested" or left for "not interested". No other swiping gesture allowed.' });
      return;
    }
    
    if (errorMessage === 'Failed to submit vote. Please try again.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'Failed to submit vote. Please try again.' });
  }
};

export const endVotingSessionController = async (req: Request, res: Response): Promise<void> => {
  const groupId = req.params.groupId as string | undefined;
  const userId = req.query.userId as string | undefined;

  if (!userId) {
    res.status(401).json({ error: 'User authentication required' });
    return;
  }

  if (!groupId) {
    res.status(400).json({ error: 'Group ID is required' });
    return;
  }

  try {
    const result = await endVotingSession(groupId, userId);

    if (!result.notificationSent) {
      res.status(200).json({
        ...result.groupDetails,
        message: 'You ended the voting session successfully but members could not be notified. You might want to contact them directly.',
      });
      return;
    }

    res.status(200).json(result.groupDetails);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';

    if (errorMessage === 'This group has been deleted.') {
      res.status(404).json({ error: errorMessage });
      return;
    }

    if (errorMessage === 'Only the group owner can end the voting session.') {
      res.status(403).json({ error: errorMessage });
      return;
    }

    if (errorMessage === 'A voting session is not currently in progress for this group.') {
      res.status(400).json({ error: errorMessage });
      return;
    }

    if (errorMessage === 'No movies available in the voting session.') {
      res.status(400).json({ error: errorMessage });
      return;
    }

    if (errorMessage === 'Failed to determine the selected movie.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    if (errorMessage === 'You are no longer a member of this group.') {
      res.status(403).json({ error: errorMessage });
      return;
    }

    if (errorMessage === 'Failed to end the voting session. Please try again.') {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'Failed to end the voting session. Please try again.' });
  }
};

