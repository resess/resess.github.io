// User domain services

import { OAuth2Client } from 'google-auth-library';
import { getUserByGoogleId, createUser, CreateUserData, revokeSessionByIdToken, updateUserFcmToken } from '../repositories/user.repository';
import { UserDocument } from '../models/user.model';

export interface GoogleTokenPayload {
  sub: string;
  email: string;
  name: string;
  picture?: string;
}

export interface AuthenticatedUser {
  id: string;
  email: string;
  name: string;
  profilePictureUrl?: string;
}

const oauth2Client = new OAuth2Client();

export const verifyGoogleToken = async (idToken: string): Promise<GoogleTokenPayload> => {
  try {
    const googleClientId = process.env.GOOGLE_CLIENT_ID;
    if (!googleClientId) {
      throw new Error('Google client ID not configured');
    }

    const ticket = await oauth2Client.verifyIdToken({
      idToken,
      audience: googleClientId,
    });
    const payload = ticket.getPayload();
    
    if (!payload) {
      throw new Error('Authentication unsuccessful. Invalid token payload.');
    }

    if (!payload.email || !payload.name || !payload.sub) {
      throw new Error('Authentication unsuccessful. Missing required user information.');
    }

    return {
      sub: payload.sub,
      email: payload.email,
      name: payload.name,
      ...(payload.picture && { picture: payload.picture }),
    };
  } catch (error) {
    if (error instanceof Error && error.message.includes('Authentication unsuccessful')) {
      throw error;
    }
    throw new Error('Google authentication service temporarily unavailable. Please try again.');
  }
};

export const authenticateUser = async (idToken: string): Promise<AuthenticatedUser> => {
  const googlePayload = await verifyGoogleToken(idToken);
  
  let user = await getUserByGoogleId(googlePayload.sub);
  
  if (!user) {
    const userData: CreateUserData = {
      googleId: googlePayload.sub,
      email: googlePayload.email,
      name: googlePayload.name,
      ...(googlePayload.picture && { profilePictureUrl: googlePayload.picture }),
    };
    user = await createUser(userData);
  }

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    ...(user.profilePictureUrl && { profilePictureUrl: user.profilePictureUrl }),
  };
};

export const signOut = async (idToken: string): Promise<void> => {
  // ID tokens are stateless JWT tokens that cannot be revoked via Google's revocation endpoint.
  // They expire naturally. Attempting to revoke an ID token may fail, so we skip this step.
  // The revocation endpoint is primarily for access tokens and refresh tokens.
  
  // Attempt to revoke the session in our database if it exists
  // Note: It's okay if the session doesn't exist - it might have never been created or already expired
  // Sign out is still considered successful even without a session record
  const revokedSession = await revokeSessionByIdToken(idToken);
  // If revokedSession is null, it means the session didn't exist, which is acceptable
};

export const registerFcmToken = async (userId: string, fcmToken: string): Promise<void> => {
  if (!fcmToken || fcmToken.trim().length === 0) {
    throw new Error('FCM token is required');
  }
  
  await updateUserFcmToken(userId, fcmToken.trim());
};
