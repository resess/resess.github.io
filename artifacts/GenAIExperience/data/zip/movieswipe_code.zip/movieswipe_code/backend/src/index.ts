import 'dotenv/config';
import express from 'express';
import { connectDatabase } from './config/index';
import userRoutes from './routes/user.routes';
import votingGroupRoutes from './routes/voting-group.routes';
import movieRoutes from './routes/movie.routes';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ message: 'Server is running.' });
});

app.use('/api/users', userRoutes);
app.use('/api/voting-groups', votingGroupRoutes);
app.use('/api/movies', movieRoutes);

const startServer = async (): Promise<void> => {
  try {
    await connectDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
