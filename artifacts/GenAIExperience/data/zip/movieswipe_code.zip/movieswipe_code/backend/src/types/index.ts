// Shared TypeScript type definitions and interfaces

export interface GroupDeletionNotificationData {
  notificationType: 'groupDeleted';
  groupId: string;
  groupName: string;
}

export interface UserJoiningGroupNotificationData {
  notificationType: 'userJoinedGroup';
  groupId: string;
  groupName: string;
}

export interface UserLeavingGroupNotificationData {
  notificationType: 'userLeftGroup';
  groupId: string;
  groupName: string;
}

