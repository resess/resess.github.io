// Movie domain repositories

import { GenreModel, GenreDocument } from '../models/movie.model';

export interface TmdbGenre {
  id: number;
  name: string;
}

export interface TmdbGenresResponse {
  genres: TmdbGenre[];
}

export const fetchGenresFromTmdb = async (): Promise<TmdbGenre[]> => {
  const tmdbApiKey = process.env.TMDB_API_KEY;
  if (!tmdbApiKey) {
    console.error('TMDB_API_KEY is not configured in environment variables');
    throw new Error('Failed to load movie genres. Please try again.');
  }

  try {
    const response = await fetch(
      `https://api.themoviedb.org/3/genre/movie/list?api_key=${tmdbApiKey}`
    );

    if (!response.ok) {
      const errorText = await response.text().catch(() => 'Unknown error');
      console.error(`TMDB API error: ${response.status} ${response.statusText}`, errorText);
      throw new Error('Failed to load movie genres. Please try again.');
    }

    const data = (await response.json()) as TmdbGenresResponse;
    if (!data.genres || !Array.isArray(data.genres)) {
      console.error('Invalid TMDB response format:', data);
      throw new Error('Failed to load movie genres. Please try again.');
    }
    console.log(`Fetched ${data.genres.length} genres from TMDB`);
    return data.genres;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Failed to load movie genres')) {
      throw error;
    }
    console.error('Unexpected error fetching genres from TMDB:', error);
    throw new Error('Failed to load movie genres. Please try again.');
  }
};

export const getAllGenres = async (): Promise<GenreDocument[]> => {
  const genres = await GenreModel.find().sort({ name: 1 }).exec();
  console.log(`Retrieved ${genres.length} genres from database`);
  return genres;
};

export const getGenreById = async (genreId: number): Promise<GenreDocument | null> => {
  return await GenreModel.findOne({ genreId }).exec();
};

export const upsertGenres = async (genres: TmdbGenre[]): Promise<void> => {
  try {
    console.log(`Upserting ${genres.length} genres to database`);
    
    // Drop old index if it exists (from previous schema versions)
    try {
      await GenreModel.collection.dropIndex('tmdbId_1').catch(() => {
        // Index doesn't exist, which is fine
      });
    } catch (dropError) {
      // Ignore errors when dropping index - it might not exist
      console.log('Note: Could not drop tmdbId index (may not exist)');
    }

    // Clean up any old documents that might have tmdbId field or null genreId
    try {
      await GenreModel.deleteMany({ genreId: { $exists: false } }).exec();
      await GenreModel.deleteMany({ genreId: null }).exec();
    } catch (cleanupError) {
      console.log('Note: Could not clean up old documents');
    }

    const operations = genres.map((genre) => ({
      updateOne: {
        filter: { genreId: genre.id },
        update: { 
          $set: { 
            genreId: genre.id, 
            name: genre.name 
          },
          $unset: { tmdbId: '' } // Remove old tmdbId field if it exists
        },
        upsert: true,
      },
    }));

    if (operations.length > 0) {
      const result = await GenreModel.bulkWrite(operations, { ordered: false });
      console.log(`BulkWrite result: ${result.upsertedCount} inserted, ${result.modifiedCount} modified, ${result.matchedCount} matched`);
    }
  } catch (error: unknown) {
    console.error('Error in upsertGenres:', error);
    
    // Handle MongoDB duplicate key errors more gracefully
    if (error && typeof error === 'object' && 'code' in error && error.code === 11000) {
      console.error('Duplicate key error detected. This might be due to old schema. Retrying with cleanup...');
      // Try to clean up and retry once
      try {
        await GenreModel.collection.dropIndex('tmdbId_1').catch(() => {});
        await GenreModel.deleteMany({ genreId: null }).exec().catch(() => {});
        // Retry the operation
        const operations = genres.map((genre) => ({
          updateOne: {
            filter: { genreId: genre.id },
            update: { 
              $set: { genreId: genre.id, name: genre.name },
              $unset: { tmdbId: '' }
            },
            upsert: true,
          },
        }));
        if (operations.length > 0) {
          await GenreModel.bulkWrite(operations, { ordered: false });
        }
        return; // Success on retry
      } catch (retryError) {
        console.error('Retry also failed:', retryError);
      }
    }
    throw new Error('Failed to load movie genres. Please try again.');
  }
};

export interface TmdbMovie {
  id: number;
  title: string;
  overview?: string | null;
  poster_path: string | null;
  release_date: string;
  vote_average: number;
  genre_ids?: number[];
  genres?: TmdbGenre[];
  runtime?: number;
}

export interface TmdbDiscoverResponse {
  results: TmdbMovie[];
  total_pages: number;
  total_results: number;
}

export const fetchMoviesFromTmdbByGenres = async (
  genreIds: number[],
  page: number = 1
): Promise<TmdbDiscoverResponse> => {
  const tmdbApiKey = process.env.TMDB_API_KEY;
  if (!tmdbApiKey) {
    console.error('TMDB_API_KEY is not configured in environment variables');
    throw new Error('Failed to load movies. Please try again.');
  }

  if (!genreIds || genreIds.length === 0) {
    throw new Error('At least one genre is required to fetch movies.');
  }

  const genreIdsString = genreIds.join(',');
  const url = `https://api.themoviedb.org/3/discover/movie?api_key=${tmdbApiKey}&with_genres=${genreIdsString}&page=${page}&sort_by=popularity.desc&include_adult=false`;

  try {
    const response = await fetch(url);

    if (!response.ok) {
      const errorText = await response.text().catch(() => 'Unknown error');
      console.error(`TMDB API error: ${response.status} ${response.statusText}`, errorText);
      throw new Error('Failed to load movies. Please try again.');
    }

    const data = (await response.json()) as TmdbDiscoverResponse;
    if (!data.results || !Array.isArray(data.results)) {
      console.error('Invalid TMDB response format:', data);
      throw new Error('Failed to load movies. Please try again.');
    }

    console.log(`Fetched ${data.results.length} movies from TMDB for genres: ${genreIdsString}`);
    return data;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Failed to load movies')) {
      throw error;
    }
    console.error('Unexpected error fetching movies from TMDB:', error);
    throw new Error('Failed to load movies. Please try again.');
  }
};

export const fetchMovieDetailsFromTmdb = async (movieId: number): Promise<TmdbMovie | null> => {
  const tmdbApiKey = process.env.TMDB_API_KEY;
  if (!tmdbApiKey) {
    console.error('TMDB_API_KEY is not configured in environment variables');
    throw new Error('Failed to load movie details. Please try again.');
  }

  const url = `https://api.themoviedb.org/3/movie/${movieId}?api_key=${tmdbApiKey}`;

  try {
    const response = await fetch(url);

    if (!response.ok) {
      if (response.status === 404) {
        return null;
      }
      const errorText = await response.text().catch(() => 'Unknown error');
      console.error(`TMDB API error: ${response.status} ${response.statusText}`, errorText);
      throw new Error('Failed to load movie details. Please try again.');
    }

    const data = (await response.json()) as TmdbMovie;
    console.log(`Fetched movie details from TMDB for movie ID: ${movieId}`);
    return data;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Failed to load movie details')) {
      throw error;
    }
    console.error('Unexpected error fetching movie details from TMDB:', error);
    throw new Error('Failed to load movie details. Please try again.');
  }
};

