// Movie domain services

import {
  fetchGenresFromTmdb,
  getAllGenres,
  upsertGenres,
  fetchMoviesFromTmdbByGenres,
  fetchMovieDetailsFromTmdb,
  TmdbMovie,
} from '../repositories/movie.repository';
import { GenreDocument } from '../models/movie.model';
import { SelectedMovie } from '../models/voting-group.model';

export interface Genre {
  id: number;
  name: string;
}

export const getGenres = async (): Promise<Genre[]> => {
  try {
    let genres = await getAllGenres();

    // TMDB typically returns around 19-20 genres for movies
    // If we have fewer than 10, refresh from TMDB to ensure we have all genres
    const MIN_EXPECTED_GENRES = 10;
    if (genres.length === 0 || genres.length < MIN_EXPECTED_GENRES) {
      try {
        const tmdbGenres = await fetchGenresFromTmdb();
        try {
          await upsertGenres(tmdbGenres);
          genres = await getAllGenres();
        } catch (dbError) {
          console.error('Error saving genres to database:', dbError);
          throw new Error('Failed to load movie genres. Please try again.');
        }
      } catch (tmdbError) {
        if (tmdbError instanceof Error) {
          if (tmdbError.message.includes('Failed to load movie genres')) {
            throw tmdbError;
          }
        }
        throw new Error('Failed to load movie genres. Please try again.');
      }
    }

    return genres.map((genre: GenreDocument) => ({
      id: genre.genreId,
      name: genre.name,
    }));
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('Failed to load movie genres')) {
        throw error;
      }
    }
    throw new Error('Failed to load movie genres. Please try again.');
  }
};

export interface MemberGenrePreferences {
  userId: string;
  genres: number[];
}

const getCommonGenres = (
  ownerGenres: number[],
  memberGenrePreferences: MemberGenrePreferences[]
): number[] => {
  const genreFrequency: Map<number, number> = new Map();

  ownerGenres.forEach((genreId) => {
    genreFrequency.set(genreId, (genreFrequency.get(genreId) ?? 0) + 1);
  });

  memberGenrePreferences.forEach((member) => {
    member.genres.forEach((genreId) => {
      genreFrequency.set(genreId, (genreFrequency.get(genreId) ?? 0) + 1);
    });
  });

  return Array.from(genreFrequency.entries())
    .sort((a, b) => b[1] - a[1])
    .map((entry) => entry[0]);
};

const calculateMovieScore = (
  movie: TmdbMovie,
  commonGenres: number[],
  allGenres: Set<number>
): number => {
  let score = 0;
  const movieGenres = new Set(movie.genre_ids);

  commonGenres.forEach((genreId, index) => {
    if (movieGenres.has(genreId)) {
      score += commonGenres.length - index;
    }
  });

  allGenres.forEach((genreId) => {
    if (movieGenres.has(genreId)) {
      score += 1;
    }
  });

  score += movie.vote_average * 0.1;

  return score;
};

const convertTmdbMovieToSelectedMovie = (tmdbMovie: TmdbMovie): SelectedMovie => {
  // Handle both formats: genre_ids (from discover) and genres (from details)
  let genreIds: number[] = [];
  if (tmdbMovie.genre_ids && tmdbMovie.genre_ids.length > 0) {
    genreIds = tmdbMovie.genre_ids;
  } else if (tmdbMovie.genres && tmdbMovie.genres.length > 0) {
    genreIds = tmdbMovie.genres.map((genre) => genre.id);
  }

  const selectedMovie: SelectedMovie = {
    movieId: tmdbMovie.id,
    title: tmdbMovie.title,
    genres: genreIds,
    rating: tmdbMovie.vote_average,
    length: tmdbMovie.runtime ?? 0,
    summary: tmdbMovie.overview && tmdbMovie.overview.trim() !== '' 
      ? tmdbMovie.overview.trim() 
      : 'No summary available.',
  };

  if (tmdbMovie.poster_path) {
    selectedMovie.posterUrl = `https://image.tmdb.org/t/p/w500${tmdbMovie.poster_path}`;
  }

  return selectedMovie;
};

export const selectMoviesForVotingSession = async (
  ownerGenrePreferences: number[],
  memberGenrePreferences: MemberGenrePreferences[]
): Promise<SelectedMovie[]> => {
  try {
    const commonGenres = getCommonGenres(ownerGenrePreferences, memberGenrePreferences);

    const allGenresSet = new Set<number>();
    ownerGenrePreferences.forEach((g) => allGenresSet.add(g));
    memberGenrePreferences.forEach((member) => {
      member.genres.forEach((g) => allGenresSet.add(g));
    });

    const allGenres = Array.from(allGenresSet);

    if (allGenres.length === 0) {
      throw new Error('No genre preferences found for group members.');
    }

    const MAX_MOVIES_TO_FETCH = 50;
    const TARGET_MOVIES = 10;
    const movies: TmdbMovie[] = [];
    const seenMovieIds = new Set<number>();
    let page = 1;

    while (movies.length < MAX_MOVIES_TO_FETCH && page <= 5) {
      try {
        const discoverResponse = await fetchMoviesFromTmdbByGenres(allGenres, page);
        const newMovies = discoverResponse.results.filter(
          (movie) => !seenMovieIds.has(movie.id)
        );
        newMovies.forEach((movie) => seenMovieIds.add(movie.id));
        movies.push(...newMovies);

        if (discoverResponse.results.length === 0) {
          break;
        }
        page++;
      } catch (error) {
        console.error(`Error fetching page ${page} from TMDB:`, error);
        if (error instanceof Error && error.message.includes('Failed to load movies')) {
          throw error;
        }
        page++;
        continue;
      }
    }

    if (movies.length === 0) {
      throw new Error('Failed to load movies. Please try again.');
    }

    const scoredMovies = movies.map((movie) => ({
      movie,
      score: calculateMovieScore(movie, commonGenres, allGenresSet),
    }));

    scoredMovies.sort((a, b) => b.score - a.score);

    const selectedMovies: SelectedMovie[] = [];

    for (const { movie } of scoredMovies) {
      if (selectedMovies.length >= TARGET_MOVIES) {
        break;
      }

      const movieDetails = await fetchMovieDetailsFromTmdb(movie.id);
      if (movieDetails && movieDetails.runtime) {
        const selectedMovie = convertTmdbMovieToSelectedMovie(movieDetails);
        selectedMovies.push(selectedMovie);
      } else {
        const selectedMovie = convertTmdbMovieToSelectedMovie(movie);
        selectedMovies.push(selectedMovie);
      }
    }

    if (selectedMovies.length < TARGET_MOVIES && selectedMovies.length > 0) {
      console.log(
        `Warning: Only found ${selectedMovies.length} movies, but requested ${TARGET_MOVIES}`
      );
    }

    if (selectedMovies.length === 0) {
      throw new Error('Failed to load movies. Please try again.');
    }

    return selectedMovies;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Failed to load movies')) {
      throw error;
    }
    console.error('Error selecting movies for voting session:', error);
    throw new Error('Failed to load movies. Please try again.');
  }
};

