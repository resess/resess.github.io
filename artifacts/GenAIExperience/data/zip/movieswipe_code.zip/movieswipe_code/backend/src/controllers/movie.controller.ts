// Movie domain controllers

import { Request, Response } from 'express';
import { getGenres } from '../services/movie.service';

export const getGenresController = async (req: Request, res: Response): Promise<void> => {
  try {
    const genres = await getGenres();
    res.status(200).json({ genres });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage.includes('Failed to load movie genres')) {
      res.status(500).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'Failed to load movie genres. Please try again.' });
  }
};

