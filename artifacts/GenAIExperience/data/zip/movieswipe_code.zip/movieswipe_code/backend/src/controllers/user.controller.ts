// User domain controllers

import { Request, Response } from 'express';
import { authenticateUser, signOut, registerFcmToken } from '../services/user.service';

interface SignInRequest {
  idToken: string;
}

interface SignOutRequest {
  idToken: string;
}

interface RegisterFcmTokenRequest {
  userId: string;
  fcmToken: string;
}

export const signIn = async (req: Request, res: Response): Promise<void> => {
  try {
    const { idToken } = req.body as SignInRequest;

    if (!idToken) {
      res.status(400).json({ error: 'ID token is required' });
      return;
    }

    const authenticatedUser = await authenticateUser(idToken);
    res.status(200).json(authenticatedUser);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage.includes('temporarily unavailable')) {
      res.status(503).json({ error: 'Authentication service temporarily unavailable. Please try again.' });
      return;
    }
    
    if (errorMessage.includes('Invalid token') || errorMessage.includes('authentication')) {
      res.status(401).json({ error: 'Authentication unsuccessful. Please try again.' });
      return;
    }

    res.status(500).json({ error: 'An unexpected error occurred' });
  }
};

export const signOutController = async (req: Request, res: Response): Promise<void> => {
  try {
    const { idToken } = req.body as SignOutRequest;

    if (!idToken) {
      res.status(400).json({ error: 'ID token is required' });
      return;
    }

    await signOut(idToken);
    res.status(200).json({ message: 'Successfully signed out' });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage.includes('temporarily unavailable') || errorMessage.includes('cannot sign out')) {
      res.status(503).json({ error: 'Authentication service temporarily unavailable, cannot sign out. Please try again.' });
      return;
    }
    
    if (errorMessage.includes('Session not found') || errorMessage.includes('already revoked')) {
      res.status(400).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'An unexpected error occurred' });
  }
};

export const registerFcmTokenController = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId, fcmToken } = req.body as RegisterFcmTokenRequest;

    if (!userId) {
      res.status(401).json({ error: 'User authentication required' });
      return;
    }

    if (!fcmToken) {
      res.status(400).json({ error: 'FCM token is required' });
      return;
    }

    await registerFcmToken(userId, fcmToken);
    res.status(200).json({ message: 'FCM token registered successfully' });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
    
    if (errorMessage.includes('FCM token is required')) {
      res.status(400).json({ error: errorMessage });
      return;
    }

    res.status(500).json({ error: 'Failed to register FCM token. Please try again.' });
  }
};
