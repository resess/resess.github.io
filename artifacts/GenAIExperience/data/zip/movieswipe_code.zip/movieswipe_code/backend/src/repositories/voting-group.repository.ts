// VotingGroup domain repositories

import { VotingGroupModel, VotingGroupDocument, SelectedMovie } from '../models/voting-group.model';
import { UserModel, UserDocument } from '../models/user.model';
import mongoose from 'mongoose';

export interface CreateVotingGroupData {
  name: string;
  ownerId: string;
  genrePreferences: number[];
}

const generateInvitationCode = (): string => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return code;
};

const generateUniqueInvitationCode = async (): Promise<string> => {
  let code = generateInvitationCode();
  let attempts = 0;
  const maxAttempts = 10;

  while (attempts < maxAttempts) {
    const existingGroup = await VotingGroupModel.findOne({ invitationCode: code }).exec();
    if (!existingGroup) {
      return code;
    }
    code = generateInvitationCode();
    attempts++;
  }

  throw new Error('Failed to generate unique invitation code. Please try again.');
};

export const createVotingGroup = async (
  votingGroupData: CreateVotingGroupData
): Promise<VotingGroupDocument> => {
  const invitationCode = await generateUniqueInvitationCode();
  
  const newVotingGroup = new VotingGroupModel({
    name: votingGroupData.name,
    ownerId: new mongoose.Types.ObjectId(votingGroupData.ownerId),
    genrePreferences: votingGroupData.genrePreferences,
    invitationCode,
  });
  return await newVotingGroup.save();
};

export interface GroupWithRole {
  id: string;
  name: string;
  role: 'owner' | 'member';
}

export const getGroupsByUserId = async (userId: string): Promise<GroupWithRole[]> => {
  const userObjectId = new mongoose.Types.ObjectId(userId);
  
  const groups = await VotingGroupModel.find({
    $or: [
      { ownerId: userObjectId },
      { members: userObjectId },
    ],
  })
    .select('_id name ownerId')
    .lean()
    .exec();

  return groups.map((group) => {
    const groupDoc = group as unknown as { _id: mongoose.Types.ObjectId; name: string; ownerId: mongoose.Types.ObjectId };
    return {
      id: groupDoc._id.toString(),
      name: groupDoc.name,
      role: groupDoc.ownerId.toString() === userId ? 'owner' : 'member',
    };
  });
};

export interface GroupMember {
  id: string;
  name: string;
  email: string;
  profilePictureUrl?: string | undefined;
}

export interface GroupDetails {
  id: string;
  name: string;
  role: 'owner' | 'member';
  invitationCode?: string;
  members?: GroupMember[];
  votingSession: {
    state: 'notStarted' | 'started' | 'ended';
    moviesToVoteOn?: SelectedMovie[];
    userVotingProgress: {
      hasNotVoted: boolean;
      hasVotedForSubset: boolean;
      hasVotedForAll: boolean;
    };
    selectedMovie?: {
      movieId: number;
      title: string;
      posterUrl?: string | undefined;
      genres: number[];
      rating: number;
      length: number;
      summary: string;
    };
  };
}

export const getGroupDetailsById = async (
  groupId: string,
  userId: string
): Promise<GroupDetails> => {
  const groupObjectId = new mongoose.Types.ObjectId(groupId);

  const group = await VotingGroupModel.findById(groupObjectId)
    .populate<{ ownerId: UserDocument; members: UserDocument[] }>('ownerId members')
    .exec();

  if (!group) {
    throw new Error('This group has been deleted.');
  }

  const populatedOwner = group.ownerId as UserDocument;
  const ownerIdString = (populatedOwner._id as mongoose.Types.ObjectId).toString();
  const isOwner = ownerIdString === userId;
  
  const membersArray = group.members as UserDocument[];
  const isMember = membersArray.some(
    (member) => (member._id as mongoose.Types.ObjectId).toString() === userId
  );

  if (!isOwner && !isMember) {
    throw new Error('You are no longer a member of this group.');
  }

  const role: 'owner' | 'member' = isOwner ? 'owner' : 'member';

  const userVotedMovieIds = new Set(
    group.votingSession.votes
      .filter((vote) => vote.userId.toString() === userId)
      .map((vote) => vote.movieId)
  );

  const totalMoviesCount = group.votingSession.moviesToVoteOn.length;
  const hasVotedCount = userVotedMovieIds.size;
  
  const hasNotVoted = hasVotedCount === 0;
  const hasVotedForSubset = hasVotedCount > 0 && hasVotedCount < totalMoviesCount;
  const hasVotedForAll = totalMoviesCount > 0 && hasVotedCount === totalMoviesCount;

  const members: GroupMember[] = isOwner
    ? membersArray.map((member) => {
        const memberId = (member._id as mongoose.Types.ObjectId).toString();
        return {
          id: memberId,
          name: member.name,
          email: member.email,
          profilePictureUrl: member.profilePictureUrl ?? undefined,
        };
      })
    : [];

  const result: GroupDetails = {
    id: (group._id as mongoose.Types.ObjectId).toString(),
    name: group.name,
    role,
    votingSession: {
      state: group.votingSession.state,
      userVotingProgress: {
        hasNotVoted,
        hasVotedForSubset,
        hasVotedForAll,
      },
    },
  };

  if (isOwner) {
    result.invitationCode = group.invitationCode;
    result.members = members;
  }

  if (group.votingSession.state === 'started' && group.votingSession.moviesToVoteOn.length > 0) {
    result.votingSession.moviesToVoteOn = group.votingSession.moviesToVoteOn.map((movie) => {
      const mappedMovie: SelectedMovie = {
        movieId: movie.movieId,
        title: movie.title,
        genres: movie.genres,
        rating: movie.rating,
        length: movie.length,
        summary: movie.summary,
      };
      if (movie.posterUrl) {
        mappedMovie.posterUrl = movie.posterUrl;
      }
      return mappedMovie;
    });
  }

  if (group.votingSession.state === 'ended' && group.votingSession.selectedMovie) {
    const selectedMovie = group.votingSession.selectedMovie;
    result.votingSession.selectedMovie = {
      movieId: selectedMovie.movieId,
      title: selectedMovie.title,
      posterUrl: selectedMovie.posterUrl ?? undefined,
      genres: selectedMovie.genres,
      rating: selectedMovie.rating,
      length: selectedMovie.length,
      summary: selectedMovie.summary,
    };
  }

  return result;
};

export interface DeleteGroupResult {
  groupId: string;
  groupName: string;
  memberIds: string[];
}

export const deleteGroupById = async (
  groupId: string,
  userId: string
): Promise<DeleteGroupResult> => {
  const groupObjectId = new mongoose.Types.ObjectId(groupId);

  const group = await VotingGroupModel.findById(groupObjectId)
    .populate<{ ownerId: UserDocument; members: UserDocument[] }>('ownerId members')
    .exec();

  if (!group) {
    throw new Error('This group has been deleted.');
  }

  const populatedOwner = group.ownerId as UserDocument;
  const ownerIdString = (populatedOwner._id as mongoose.Types.ObjectId).toString();
  
  if (ownerIdString !== userId) {
    throw new Error('Only the group owner can delete the group.');
  }

  const membersArray = group.members as UserDocument[];
  const memberIds = membersArray.map(
    (member) => (member._id as mongoose.Types.ObjectId).toString()
  );

  const groupName = group.name;

  await VotingGroupModel.findByIdAndDelete(groupObjectId).exec();

  return {
    groupId,
    groupName,
    memberIds,
  };
};

export interface GroupByInvitationCodeResult {
  id: string;
  name: string;
  genrePreferences: number[];
  ownerId: string;
  memberIds: string[];
}

export const getGroupByInvitationCode = async (
  invitationCode: string,
  userId: string
): Promise<GroupByInvitationCodeResult> => {
  const group = await VotingGroupModel.findOne({ invitationCode }).exec();

  if (!group) {
    throw new Error('Invalid invitation code. Please check the code and try again.');
  }

  const groupId = (group._id as mongoose.Types.ObjectId).toString();
  const ownerIdString = (group.ownerId as mongoose.Types.ObjectId).toString();
  const memberIds = group.members.map(
    (memberId) => (memberId as mongoose.Types.ObjectId).toString()
  );

  const isOwner = ownerIdString === userId;
  const isMember = memberIds.includes(userId);

  if (isOwner) {
    const alreadyMemberError = new Error('You are already a member of this group');
    (alreadyMemberError as any).groupId = groupId;
    throw alreadyMemberError;
  }

  if (isMember) {
    const alreadyMemberError = new Error('You are already a member of this group');
    (alreadyMemberError as any).groupId = groupId;
    throw alreadyMemberError;
  }

  return {
    id: groupId,
    name: group.name,
    genrePreferences: group.genrePreferences,
    ownerId: ownerIdString,
    memberIds,
  };
};

export interface GroupGenresResult {
  genres: number[];
}

export const getGroupGenresByInvitationCode = async (
  invitationCode: string
): Promise<GroupGenresResult> => {
  const group = await VotingGroupModel.findOne({ invitationCode })
    .select('genrePreferences')
    .exec();

  if (!group) {
    throw new Error('Invalid invitation code. Please check the code and try again.');
  }

  return {
    genres: group.genrePreferences,
  };
};

export interface JoinGroupData {
  invitationCode: string;
  userId: string;
  genrePreferences: number[];
}

export interface JoinGroupResult {
  groupId: string;
  groupName: string;
  ownerId: string;
}

export const joinGroupByInvitationCode = async (
  joinGroupData: JoinGroupData
): Promise<JoinGroupResult> => {
  const userObjectId = new mongoose.Types.ObjectId(joinGroupData.userId);

  const group = await VotingGroupModel.findOne({
    invitationCode: joinGroupData.invitationCode,
  }).exec();

  if (!group) {
    throw new Error('Invalid invitation code. Please check the code and try again.');
  }

  const ownerIdString = (group.ownerId as mongoose.Types.ObjectId).toString();
  const memberIds = group.members.map(
    (memberId) => (memberId as mongoose.Types.ObjectId).toString()
  );

  const isOwner = ownerIdString === joinGroupData.userId;
  const isMember = memberIds.includes(joinGroupData.userId);

  if (isOwner) {
    const alreadyMemberError = new Error('You are already a member of this group');
    (alreadyMemberError as any).groupId = (group._id as mongoose.Types.ObjectId).toString();
    throw alreadyMemberError;
  }

  if (isMember) {
    const alreadyMemberError = new Error('You are already a member of this group');
    (alreadyMemberError as any).groupId = (group._id as mongoose.Types.ObjectId).toString();
    throw alreadyMemberError;
  }

  if (joinGroupData.genrePreferences.length === 0) {
    throw new Error('Genre selection is required. Please choose at least one preferred movie genre.');
  }

  const groupGenres = group.genrePreferences;
  const invalidGenres = joinGroupData.genrePreferences.filter(
    (genre) => !groupGenres.includes(genre)
  );

  if (invalidGenres.length > 0) {
    throw new Error('Invalid genre selection. Please choose from the available genres.');
  }

  group.members.push(userObjectId);
  group.memberGenrePreferences.push({
    userId: userObjectId,
    genres: joinGroupData.genrePreferences,
  });

  await group.save();

  return {
    groupId: (group._id as mongoose.Types.ObjectId).toString(),
    groupName: group.name,
    ownerId: ownerIdString,
  };
};

export interface LeaveGroupResult {
  userName: string;
  groupName: string;
  groupId: string;
  ownerId: string;
}

export const leaveGroupById = async (
  groupId: string,
  userId: string
): Promise<LeaveGroupResult> => {
  const groupObjectId = new mongoose.Types.ObjectId(groupId);
  const userObjectId = new mongoose.Types.ObjectId(userId);

  const group = await VotingGroupModel.findById(groupObjectId)
    .populate<{ ownerId: UserDocument }>('ownerId')
    .exec();

  if (!group) {
    throw new Error('This group has been deleted.');
  }

  const populatedOwner = group.ownerId as UserDocument;
  const ownerIdString = (populatedOwner._id as mongoose.Types.ObjectId).toString();

  if (ownerIdString === userId) {
    throw new Error('Group owners cannot leave the group. Please delete the group instead.');
  }

  const memberIds = group.members.map(
    (memberId) => (memberId as mongoose.Types.ObjectId).toString()
  );

  if (!memberIds.includes(userId)) {
    throw new Error('You are not a member of this group.');
  }

  const user = await UserModel.findById(userObjectId).exec();
  if (!user) {
    throw new Error('User not found.');
  }

  const userName = (user as UserDocument).name;
  const groupName = group.name;
  const groupIdString = (group._id as mongoose.Types.ObjectId).toString();

  group.members = group.members.filter(
    (memberId) => (memberId as mongoose.Types.ObjectId).toString() !== userId
  );

  group.memberGenrePreferences = group.memberGenrePreferences.filter(
    (pref) => (pref.userId as mongoose.Types.ObjectId).toString() !== userId
  );

  await group.save();

  return {
    userName,
    groupName,
    groupId: groupIdString,
    ownerId: ownerIdString,
  };
};

export interface MemberGenrePreference {
  userId: string;
  genres: number[];
}

export interface GroupForStartingVotingSession {
  id: string;
  name: string;
  ownerId: string;
  ownerGenrePreferences: number[];
  memberGenrePreferences: MemberGenrePreference[];
  allMemberIds: string[];
}

export const getGroupForStartingVotingSession = async (
  groupId: string,
  userId: string
): Promise<GroupForStartingVotingSession> => {
  const groupObjectId = new mongoose.Types.ObjectId(groupId);

  const group = await VotingGroupModel.findById(groupObjectId).exec();

  if (!group) {
    throw new Error('This group has been deleted.');
  }

  const ownerIdString = (group.ownerId as mongoose.Types.ObjectId).toString();

  if (ownerIdString !== userId) {
    throw new Error('Only the group owner can start a voting session.');
  }

  if (group.votingSession.state === 'started') {
    throw new Error('A voting session is already in progress for this group.');
  }

  const allMemberIds = group.members.map(
    (memberId) => (memberId as mongoose.Types.ObjectId).toString()
  );

  const memberGenrePreferences: MemberGenrePreference[] = group.memberGenrePreferences.map(
    (pref) => ({
      userId: (pref.userId as mongoose.Types.ObjectId).toString(),
      genres: pref.genres,
    })
  );

  return {
    id: (group._id as mongoose.Types.ObjectId).toString(),
    name: group.name,
    ownerId: ownerIdString,
    ownerGenrePreferences: group.genrePreferences,
    memberGenrePreferences,
    allMemberIds: [ownerIdString, ...allMemberIds],
  };
};

export interface StartVotingSessionData {
  groupId: string;
  movies: SelectedMovie[];
}

export interface StartVotingSessionResult {
  groupName: string;
  memberIds: string[];
}

export const startVotingSession = async (
  startVotingSessionData: StartVotingSessionData,
  userId: string
): Promise<StartVotingSessionResult> => {
  const groupObjectId = new mongoose.Types.ObjectId(startVotingSessionData.groupId);

  const group = await VotingGroupModel.findById(groupObjectId).exec();

  if (!group) {
    throw new Error('This group has been deleted.');
  }

  const ownerIdString = (group.ownerId as mongoose.Types.ObjectId).toString();

  if (ownerIdString !== userId) {
    throw new Error('Only the group owner can start a voting session.');
  }

  if (group.votingSession.state === 'started') {
    throw new Error('A voting session is already in progress for this group.');
  }

  group.votingSession.state = 'started';
  group.votingSession.startedAt = new Date();
  group.votingSession.moviesToVoteOn = startVotingSessionData.movies;
  group.votingSession.votes = [];

  await group.save();

  const allMemberIds = group.members.map(
    (memberId) => (memberId as mongoose.Types.ObjectId).toString()
  );

  return {
    groupName: group.name,
    memberIds: [ownerIdString, ...allMemberIds],
  };
};

export interface NextMovieToVoteOnResult {
  movie: SelectedMovie | null;
  hasVotedOnAllMovies: boolean;
}

export const getNextMovieToVoteOn = async (
  groupId: string,
  userId: string
): Promise<NextMovieToVoteOnResult> => {
  const groupObjectId = new mongoose.Types.ObjectId(groupId);
  const userObjectId = new mongoose.Types.ObjectId(userId);

  const group = await VotingGroupModel.findById(groupObjectId).exec();

  if (!group) {
    throw new Error('This group has been deleted.');
  }

  if (group.votingSession.state !== 'started') {
    throw new Error('The voting session has ended.');
  }

  const ownerIdString = (group.ownerId as mongoose.Types.ObjectId).toString();
  const memberIds = group.members.map(
    (memberId) => (memberId as mongoose.Types.ObjectId).toString()
  );

  const isOwner = ownerIdString === userId;
  const isMember = memberIds.includes(userId);

  if (!isOwner && !isMember) {
    throw new Error('You are no longer a member of this group.');
  }

  const userVotedMovieIds = new Set(
    group.votingSession.votes
      .filter((vote) => vote.userId.toString() === userId)
      .map((vote) => vote.movieId)
  );

  const nextMovie = group.votingSession.moviesToVoteOn.find(
    (movie) => !userVotedMovieIds.has(movie.movieId)
  );

  const hasVotedOnAllMovies =
    group.votingSession.moviesToVoteOn.length > 0 &&
    userVotedMovieIds.size === group.votingSession.moviesToVoteOn.length;

  if (!nextMovie) {
    return {
      movie: null,
      hasVotedOnAllMovies,
    };
  }

  const result: SelectedMovie = {
    movieId: nextMovie.movieId,
    title: nextMovie.title,
    genres: nextMovie.genres,
    rating: nextMovie.rating,
    length: nextMovie.length,
    summary: nextMovie.summary,
  };

  if (nextMovie.posterUrl) {
    result.posterUrl = nextMovie.posterUrl;
  }

  return {
    movie: result,
    hasVotedOnAllMovies,
  };
};

export interface SubmitVoteData {
  groupId: string;
  userId: string;
  movieId: number;
  voteType: 'like' | 'dislike';
}

export interface SubmitVoteResult {
  hasVotedOnAllMovies: boolean;
}

export const submitVote = async (
  submitVoteData: SubmitVoteData
): Promise<SubmitVoteResult> => {
  const groupObjectId = new mongoose.Types.ObjectId(submitVoteData.groupId);
  const userObjectId = new mongoose.Types.ObjectId(submitVoteData.userId);

  const group = await VotingGroupModel.findById(groupObjectId).exec();

  if (!group) {
    throw new Error('This group has been deleted.');
  }

  if (group.votingSession.state !== 'started') {
    throw new Error('The voting session has ended.');
  }

  const ownerIdString = (group.ownerId as mongoose.Types.ObjectId).toString();
  const memberIds = group.members.map(
    (memberId) => (memberId as mongoose.Types.ObjectId).toString()
  );

  const isOwner = ownerIdString === submitVoteData.userId;
  const isMember = memberIds.includes(submitVoteData.userId);

  if (!isOwner && !isMember) {
    throw new Error('You are no longer a member of this group.');
  }

  const movieExists = group.votingSession.moviesToVoteOn.some(
    (movie) => movie.movieId === submitVoteData.movieId
  );

  if (!movieExists) {
    throw new Error('This movie is not part of the voting session.');
  }

  const existingVoteIndex = group.votingSession.votes.findIndex(
    (vote) =>
      vote.userId.toString() === submitVoteData.userId &&
      vote.movieId === submitVoteData.movieId
  );

  const newVote = {
    userId: userObjectId,
    movieId: submitVoteData.movieId,
    voteType: submitVoteData.voteType,
    votedAt: new Date(),
  };

  if (existingVoteIndex !== -1) {
    group.votingSession.votes[existingVoteIndex] = newVote;
  } else {
    group.votingSession.votes.push(newVote);
  }

  await group.save();

  const userVotedMovieIds = new Set(
    group.votingSession.votes
      .filter((vote) => vote.userId.toString() === submitVoteData.userId)
      .map((vote) => vote.movieId)
  );

  const hasVotedOnAllMovies =
    group.votingSession.moviesToVoteOn.length > 0 &&
    userVotedMovieIds.size === group.votingSession.moviesToVoteOn.length;

  return {
    hasVotedOnAllMovies,
  };
};

export interface VotingSessionState {
  state: 'notStarted' | 'started' | 'ended';
}

export const getVotingSessionState = async (
  groupId: string
): Promise<VotingSessionState> => {
  const groupObjectId = new mongoose.Types.ObjectId(groupId);

  const group = await VotingGroupModel.findById(groupObjectId)
    .select('votingSession.state')
    .exec();

  if (!group) {
    throw new Error('This group has been deleted.');
  }

  return {
    state: group.votingSession.state,
  };
};

export interface EndVotingSessionResult {
  groupName: string;
  memberIds: string[];
  selectedMovie: SelectedMovie;
}

export const endVotingSession = async (
  groupId: string,
  userId: string
): Promise<EndVotingSessionResult> => {
  const groupObjectId = new mongoose.Types.ObjectId(groupId);

  const group = await VotingGroupModel.findById(groupObjectId).exec();

  if (!group) {
    throw new Error('This group has been deleted.');
  }

  const ownerIdString = (group.ownerId as mongoose.Types.ObjectId).toString();

  if (ownerIdString !== userId) {
    throw new Error('Only the group owner can end the voting session.');
  }

  if (group.votingSession.state !== 'started') {
    throw new Error('A voting session is not currently in progress for this group.');
  }

  if (group.votingSession.moviesToVoteOn.length === 0) {
    throw new Error('No movies available in the voting session.');
  }

  const movieVoteCounts = new Map<
    number,
    { likes: number; dislikes: number; movie: SelectedMovie }
  >();

  for (const movie of group.votingSession.moviesToVoteOn) {
    movieVoteCounts.set(movie.movieId, {
      likes: 0,
      dislikes: 0,
      movie,
    });
  }

  for (const vote of group.votingSession.votes) {
    const movieId = vote.movieId;
    const countData = movieVoteCounts.get(movieId);
    if (countData) {
      if (vote.voteType === 'like') {
        countData.likes++;
      } else {
        countData.dislikes++;
      }
    }
  }

  let selectedMovieData: { likes: number; dislikes: number; movie: SelectedMovie } | null = null;

  for (const [, countData] of movieVoteCounts) {
    if (!selectedMovieData) {
      selectedMovieData = countData;
    } else {
      if (countData.likes > selectedMovieData.likes) {
        selectedMovieData = countData;
      } else if (
        countData.likes === selectedMovieData.likes &&
        countData.dislikes < selectedMovieData.dislikes
      ) {
        selectedMovieData = countData;
      } else if (
        countData.likes === selectedMovieData.likes &&
        countData.dislikes === selectedMovieData.dislikes &&
        countData.movie.rating > selectedMovieData.movie.rating
      ) {
        selectedMovieData = countData;
      }
    }
  }

  if (!selectedMovieData) {
    throw new Error('Failed to determine the selected movie.');
  }

  const selectedMovie: SelectedMovie = {
    movieId: selectedMovieData.movie.movieId,
    title: selectedMovieData.movie.title,
    genres: selectedMovieData.movie.genres,
    rating: selectedMovieData.movie.rating,
    length: selectedMovieData.movie.length,
    summary: selectedMovieData.movie.summary,
  };

  if (selectedMovieData.movie.posterUrl) {
    selectedMovie.posterUrl = selectedMovieData.movie.posterUrl;
  }

  group.votingSession.state = 'ended';
  group.votingSession.endedAt = new Date();
  group.votingSession.selectedMovie = selectedMovie;

  await group.save();

  const allMemberIds = group.members.map(
    (memberId) => (memberId as mongoose.Types.ObjectId).toString()
  );

  return {
    groupName: group.name,
    memberIds: [ownerIdString, ...allMemberIds],
    selectedMovie,
  };
};

