// Navigation configuration

package com.movieswipe.ui.navigation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import android.util.Log
import com.movieswipe.data.datasources.movie.Genre as DataGenre
import com.movieswipe.ui.stateholders.group.CreateGroupViewModel
import com.movieswipe.ui.stateholders.group.GroupDetailViewModel
import com.movieswipe.ui.stateholders.group.GroupListViewModel
import com.movieswipe.ui.stateholders.group.JoinGroupViewModel
import com.movieswipe.ui.stateholders.voting.VotingViewModel
import com.movieswipe.ui.ui_elements.authentication.AuthenticationScreen
import com.movieswipe.ui.ui_elements.group.GroupDetailScreen
import com.movieswipe.ui.ui_elements.group.GroupListScreenWithCreateGroup
import com.movieswipe.ui.ui_elements.group.InvitationCodeDialog
import com.movieswipe.ui.ui_elements.group.JoinGroupGenrePreferencesScreen
import com.movieswipe.ui.ui_elements.group.Genre
import com.movieswipe.ui.ui_elements.voting.VotingScreen

sealed class Screen(val route: String) {
    object Authentication : Screen("authentication")
    object GroupList : Screen("group_list")
    data class GroupDetails(val groupId: String = "{groupId}") : Screen("group_details/{groupId}") {
        fun createRoute(groupId: String) = "group_details/$groupId"
    }
    data class Voting(val groupId: String = "{groupId}") : Screen("voting/{groupId}") {
        fun createRoute(groupId: String) = "voting/$groupId"
    }
}

@Composable
fun AppNavigation(
    navController: NavHostController,
    startDestination: String = Screen.Authentication.route,
    onSignInClick: () -> Unit,
    onSignOutClick: () -> Unit,
    onCreateGroupClick: () -> Unit,
    createGroupViewModel: CreateGroupViewModel,
    createGroupUiState: com.movieswipe.ui.stateholders.group.CreateGroupUiState,
    groupListViewModel: GroupListViewModel,
    groupListUiState: com.movieswipe.ui.stateholders.group.GroupListUiState,
    groupDetailViewModel: GroupDetailViewModel,
    joinGroupViewModel: JoinGroupViewModel,
    joinGroupUiState: com.movieswipe.ui.stateholders.group.JoinGroupUiState,
    votingViewModel: VotingViewModel,
    userId: String?,
    isLoading: Boolean,
    isSigningOut: Boolean,
    errorMessage: String?,
    signOutError: String?,
    paddingValues: PaddingValues = PaddingValues()
) {
    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = Modifier.padding(paddingValues)
    ) {
        composable(Screen.Authentication.route) {
            AuthenticationScreen(
                onSignInClick = onSignInClick,
                isLoading = isLoading,
                errorMessage = errorMessage,
                modifier = Modifier.fillMaxSize()
            )
        }

        composable(Screen.GroupList.route) {
            LaunchedEffect(userId) {
                userId?.let { groupListViewModel.loadGroups(it) }
            }

            GroupListScreenWithCreateGroup(
                groups = groupListUiState.groups,
                isLoading = groupListUiState.isLoading,
                loadError = groupListUiState.loadError,
                showErrorDialog = groupListUiState.showErrorDialog,
                onRetryClick = { 
                    userId?.let { groupListViewModel.retryLoadGroups(it) }
                },
                onDismissErrorDialog = { groupListViewModel.dismissErrorDialog() },
                onSignOutClick = onSignOutClick,
                onCreateGroupClick = onCreateGroupClick,
                onJoinGroupClick = { joinGroupViewModel.openInvitationCodeDialog() },
                onGroupClick = { groupId ->
                    navController.navigate(Screen.GroupDetails(groupId).createRoute(groupId))
                },
                showGroupNameDialog = createGroupUiState.showGroupNameDialog,
                showGenrePreferencesScreen = createGroupUiState.showGenrePreferencesScreen,
                groupName = createGroupUiState.groupName,
                onGroupNameChange = { createGroupViewModel.updateGroupName(it) },
                onNextClick = { createGroupViewModel.validateAndProceedToGenres() },
                onCloseGroupNameDialog = { createGroupViewModel.closeGroupNameDialog() },
                genres = createGroupUiState.genres,
                selectedGenres = createGroupUiState.selectedGenres,
                onGenreToggle = { createGroupViewModel.toggleGenreSelection(it) },
                onCreateGroupClickFromGenres = { 
                    userId?.let { createGroupViewModel.createGroup(it) }
                },
                onBackFromGenres = { createGroupViewModel.goBackToGroupNameDialog() },
                isLoadingGenres = createGroupUiState.isLoadingGenres,
                isLoadingCreateGroup = createGroupUiState.isLoadingCreateGroup,
                groupNameError = createGroupUiState.groupNameError,
                genresError = createGroupUiState.genresError,
                createGroupError = createGroupUiState.createGroupError,
                onRetryLoadGenres = { createGroupViewModel.retryLoadGenres() },
                isSigningOut = isSigningOut,
                signOutError = signOutError,
                showInvitationCodeDialog = joinGroupUiState.showInvitationCodeDialog,
                invitationCode = joinGroupUiState.invitationCode,
                onInvitationCodeChange = { joinGroupViewModel.updateInvitationCode(it) },
                onInvitationCodeNextClick = { 
                    userId?.let { joinGroupViewModel.validateInvitationCode(it) }
                },
                onCloseInvitationCodeDialog = { joinGroupViewModel.closeInvitationCodeDialog() },
                isLoadingValidateCode = joinGroupUiState.isLoadingValidateCode,
                invitationCodeError = joinGroupUiState.invitationCodeError,
                showJoinGroupGenrePreferencesScreen = joinGroupUiState.showGenrePreferencesScreen,
                joinGroupGenres = joinGroupUiState.genres,
                joinGroupSelectedGenres = joinGroupUiState.selectedGenres,
                onJoinGroupGenreToggle = { joinGroupViewModel.toggleGenreSelection(it) },
                onConfirmJoinGroupClick = { 
                    userId?.let { joinGroupViewModel.joinGroup(it) }
                },
                onBackFromJoinGroupGenres = { joinGroupViewModel.goBackToInvitationCodeDialog() },
                isLoadingJoinGroupGenres = joinGroupUiState.isLoadingGenres,
                isLoadingJoin = joinGroupUiState.isLoadingJoin,
                joinGroupGenresError = joinGroupUiState.genresError,
                joinGroupError = joinGroupUiState.joinGroupError,
                showRetryJoinGroupGenresDialog = joinGroupUiState.showRetryGenresDialog,
                onDismissRetryJoinGroupGenresDialog = { joinGroupViewModel.dismissRetryGenresDialog() },
                onRetryLoadJoinGroupGenres = { joinGroupViewModel.retryLoadGenres() },
                modifier = Modifier.fillMaxSize()
            )
        }

        composable(
            route = "group_details/{groupId}",
            arguments = listOf(
                navArgument("groupId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val groupId = backStackEntry.arguments?.getString("groupId") ?: ""
            // Check if we should show the already member message based on savedStateHandle
            val savedStateHandle = backStackEntry.savedStateHandle
            val showAlreadyMemberMessage = savedStateHandle.get<Boolean>("showAlreadyMemberMessage") ?: false
            val refreshGroupDetails = savedStateHandle.get<Boolean>("refreshGroupDetails") ?: false
            val groupDetailUiState by groupDetailViewModel.uiState.collectAsState()
            
            LaunchedEffect(groupId, userId) {
                // Reset state and load when navigating to a different group
                // Check if we need to refresh (coming back from voting) or just normal load
                val shouldRefresh = savedStateHandle.get<Boolean>("refreshGroupDetails") ?: false
                if (groupId.isNotEmpty()) {
                    if (userId != null) {
                        // Only reset state if we have a userId (user is authenticated)
                        groupDetailViewModel.resetState()
                        if (shouldRefresh) {
                            // If refresh flag is set, delay and refresh (handled by refresh LaunchedEffect)
                            // Just reset the initial load here
                            kotlinx.coroutines.delay(300)
                            groupDetailViewModel.loadGroupDetails(groupId, userId)
                            savedStateHandle["refreshGroupDetails"] = false
                        } else {
                            // Normal load when navigating to a different group
                            groupDetailViewModel.loadGroupDetails(groupId, userId)
                        }
                    }
                    // If userId is null but we have a groupId, we're waiting for authentication
                    // The LaunchedEffect will trigger again when userId becomes available
                }
            }

            LaunchedEffect(showAlreadyMemberMessage) {
                if (showAlreadyMemberMessage) {
                    groupDetailViewModel.showAlreadyMemberMessage()
                    // Clear the flag after showing
                    savedStateHandle["showAlreadyMemberMessage"] = false
                }
            }
            
            // Watch for refresh flag - this will trigger whenever we return from voting screen
            LaunchedEffect(refreshGroupDetails) {
                if (refreshGroupDetails && groupId.isNotEmpty() && userId != null) {
                    // Small delay to ensure navigation is complete and screen is visible
                    kotlinx.coroutines.delay(300)
                    // Reload group details to reflect latest voting state
                    groupDetailViewModel.loadGroupDetails(groupId, userId)
                    // Clear the flag after refreshing - wait a bit to ensure state updates
                    kotlinx.coroutines.delay(100)
                    savedStateHandle["refreshGroupDetails"] = false
                }
            }
            
            LaunchedEffect(groupId) {
                if (groupId.isNotEmpty()) {
                    groupDetailViewModel.loadGenres()
                }
            }
            
            // Listen for FCM notifications about members joining/leaving (live updates)
            val context = LocalContext.current
            DisposableEffect(groupId, userId) {
                val capturedGroupId = groupId
                val capturedUserId = userId
                
                val receiver = object : BroadcastReceiver() {
                    override fun onReceive(context: Context?, intent: Intent?) {
                        val action = intent?.action
                        val notificationGroupId = intent?.getStringExtra("groupId")
                        
                        if (action == "com.movieswipe.USER_JOINED_GROUP") {
                            Log.d("Navigation", "Received USER_JOINED_GROUP broadcast - groupId: $notificationGroupId, current groupId: $capturedGroupId")
                            // Only refresh if this notification is for the currently viewed group
                            // Check current role dynamically from state (don't capture, as it may change)
                            if (notificationGroupId == capturedGroupId && capturedUserId != null) {
                                // Check role from current state dynamically (don't capture, as it may change)
                                CoroutineScope(Dispatchers.Main).launch {
                                    // Get current state to check role
                                    val currentState = groupDetailViewModel.uiState.value
                                    Log.d("Navigation", "Current role: ${currentState.groupDetails?.role}")
                                    if (currentState.groupDetails?.role == "owner") {
                                        Log.d("Navigation", "Triggering silent refresh for owner (user joined)")
                                        groupDetailViewModel.silentlyRefreshGroupDetails(capturedGroupId, capturedUserId)
                                    } else {
                                        Log.d("Navigation", "Not refreshing - user is not owner (role: ${currentState.groupDetails?.role})")
                                    }
                                }
                            } else {
                                Log.d("Navigation", "Not refreshing - groupId mismatch or userId is null")
                            }
                        } else if (action == "com.movieswipe.USER_LEFT_GROUP") {
                            Log.d("Navigation", "Received USER_LEFT_GROUP broadcast - groupId: $notificationGroupId, current groupId: $capturedGroupId")
                            // Only refresh if this notification is for the currently viewed group
                            // Check current role dynamically from state (don't capture, as it may change)
                            if (notificationGroupId == capturedGroupId && capturedUserId != null) {
                                // Check role from current state dynamically (don't capture, as it may change)
                                CoroutineScope(Dispatchers.Main).launch {
                                    // Get current state to check role
                                    val currentState = groupDetailViewModel.uiState.value
                                    Log.d("Navigation", "Current role: ${currentState.groupDetails?.role}")
                                    if (currentState.groupDetails?.role == "owner") {
                                        Log.d("Navigation", "Triggering silent refresh for owner (user left)")
                                        groupDetailViewModel.silentlyRefreshGroupDetails(capturedGroupId, capturedUserId)
                                    } else {
                                        Log.d("Navigation", "Not refreshing - user is not owner (role: ${currentState.groupDetails?.role})")
                                    }
                                }
                            } else {
                                Log.d("Navigation", "Not refreshing - groupId mismatch or userId is null")
                            }
                        }
                    }
                }
                val filter = IntentFilter().apply {
                    addAction("com.movieswipe.USER_JOINED_GROUP")
                    addAction("com.movieswipe.USER_LEFT_GROUP")
                }
                context.registerReceiver(receiver, filter)
                
                onDispose {
                    context.unregisterReceiver(receiver)
                }
            }
            
            GroupDetailScreen(
                groupDetails = groupDetailUiState.groupDetails,
                genres = groupDetailUiState.genres,
                isLoading = groupDetailUiState.isLoading,
                errorMessage = groupDetailUiState.errorMessage,
                showErrorDialog = groupDetailUiState.showErrorDialog,
                showDeleteConfirmationDialog = groupDetailUiState.showDeleteConfirmationDialog,
                showDeleteSuccessDialog = groupDetailUiState.showDeleteSuccessDialog,
                deleteSuccessMessage = groupDetailUiState.deleteSuccessMessage,
                showLeaveConfirmationDialog = groupDetailUiState.showLeaveConfirmationDialog,
                showLeaveSuccessDialog = groupDetailUiState.showLeaveSuccessDialog,
                leaveSuccessMessage = groupDetailUiState.leaveSuccessMessage,
                showEndVotingSessionConfirmationDialog = groupDetailUiState.showEndVotingSessionConfirmationDialog,
                showEndVotingSessionSuccessDialog = groupDetailUiState.showEndVotingSessionSuccessDialog,
                endVotingSessionSuccessMessage = groupDetailUiState.endVotingSessionSuccessMessage,
                selectedMovieAfterEnding = groupDetailUiState.selectedMovieAfterEnding,
                showAlreadyMemberSnackbar = groupDetailUiState.showAlreadyMemberSnackbar,
                onDismissAlreadyMemberSnackbar = { groupDetailViewModel.dismissAlreadyMemberSnackbar() },
                onRetryClick = { 
                    userId?.let { groupDetailViewModel.retryLoadGroupDetails(groupId, it) }
                },
                onDismissErrorDialog = { 
                    val errorMessage = groupDetailUiState.errorMessage
                    groupDetailViewModel.dismissErrorDialog()
                    // If the group was deleted, navigate back to Group List and refresh
                    if (errorMessage?.contains("This group has been deleted", ignoreCase = true) == true) {
                        userId?.let { groupListViewModel.refreshGroups(it) }
                        navController.navigate(Screen.GroupList.route) {
                            popUpTo(Screen.GroupList.route) { inclusive = false }
                        }
                    }
                },
                onBackClick = { navController.popBackStack() },
                onStartVotingSessionClick = { 
                    userId?.let { groupDetailViewModel.startVotingSession(groupId, it) }
                },
                onJoinVotingSessionClick = { 
                    userId?.let { 
                        groupDetailViewModel.joinVotingSession(groupId, it)
                        navController.navigate(Screen.Voting(groupId).createRoute(groupId))
                    }
                },
                onResumeVotingSessionClick = { 
                    userId?.let { 
                        groupDetailViewModel.resumeVotingSession(groupId, it)
                        navController.navigate(Screen.Voting(groupId).createRoute(groupId))
                    }
                },
                onEndVotingSessionClick = { 
                    groupDetailViewModel.showEndVotingSessionConfirmationDialog()
                },
                onConfirmEndVotingSessionClick = {
                    userId?.let { groupDetailViewModel.endVotingSession(groupId, it) }
                },
                onDismissEndVotingSessionConfirmationDialog = { 
                    groupDetailViewModel.dismissEndVotingSessionConfirmationDialog()
                },
                onDismissEndVotingSessionSuccessDialog = {
                    groupDetailViewModel.dismissEndVotingSessionSuccessDialog()
                },
                onDeleteGroupClick = { groupDetailViewModel.showDeleteConfirmationDialog() },
                onConfirmDeleteGroupClick = { 
                    userId?.let { groupDetailViewModel.deleteGroup(groupId, it) }
                },
                onDismissDeleteConfirmationDialog = { groupDetailViewModel.dismissDeleteConfirmationDialog() },
                onDismissDeleteSuccessDialog = { 
                    groupDetailViewModel.dismissDeleteSuccessDialog()
                    navController.navigate(Screen.GroupList.route) {
                        popUpTo(Screen.GroupList.route) { inclusive = false }
                    }
                },
                onLeaveGroupClick = { groupDetailViewModel.showLeaveConfirmationDialog() },
                onConfirmLeaveGroupClick = { 
                    userId?.let { groupDetailViewModel.leaveGroup(groupId, it) }
                },
                onDismissLeaveConfirmationDialog = { groupDetailViewModel.dismissLeaveConfirmationDialog() },
                onDismissLeaveSuccessDialog = { 
                    groupDetailViewModel.dismissLeaveSuccessDialog()
                    navController.navigate(Screen.GroupList.route) {
                        popUpTo(Screen.GroupList.route) { inclusive = false }
                    }
                },
                isDeletingGroup = groupDetailUiState.isDeletingGroup,
                isLeavingGroup = groupDetailUiState.isLeavingGroup,
                isStartingVotingSession = groupDetailUiState.isStartingVotingSession,
                isEndingVotingSession = groupDetailUiState.isEndingVotingSession,
                modifier = Modifier.fillMaxSize()
            )
        }

        composable(
            route = Screen.Voting("{groupId}").route,
            arguments = listOf(
                navArgument("groupId") {
                    type = NavType.StringType
                }
            )
        ) { backStackEntry ->
            val votingGroupId = backStackEntry.arguments?.getString("groupId") ?: ""
            val votingUiState by votingViewModel.uiState.collectAsState()
            
            LaunchedEffect(votingGroupId, userId) {
                if (votingGroupId.isNotEmpty() && userId != null) {
                    votingViewModel.resetState()
                    votingViewModel.loadGenres()
                    votingViewModel.loadNextMovieToVoteOn(votingGroupId, userId)
                }
            }
            
            VotingScreen(
                groupId = votingGroupId,
                movie = votingUiState.movie,
                isLoading = votingUiState.isLoading,
                errorMessage = votingUiState.errorMessage,
                showErrorDialog = votingUiState.showErrorDialog,
                showCompletionDialog = votingUiState.showCompletionDialog,
                showInvalidSwipeDialog = votingUiState.showInvalidSwipeDialog,
                genres = votingUiState.genres,
                onSwipeRight = { movieId ->
                    userId?.let {
                        votingViewModel.submitVote(votingGroupId, it, movieId, "like")
                    }
                },
                onSwipeLeft = { movieId ->
                    userId?.let {
                        votingViewModel.submitVote(votingGroupId, it, movieId, "dislike")
                    }
                },
                onInvalidSwipe = {
                    votingViewModel.showInvalidSwipeDialog()
                },
                onExitClick = { 
                    // Set flag to refresh group details when returning
                    try {
                        val groupDetailsRoute = Screen.GroupDetails(votingGroupId).createRoute(votingGroupId)
                        navController.getBackStackEntry(groupDetailsRoute).savedStateHandle.set("refreshGroupDetails", true)
                    } catch (e: Exception) {
                        // Fallback: try previousBackStackEntry
                        navController.previousBackStackEntry?.savedStateHandle?.set("refreshGroupDetails", true)
                    }
                    navController.popBackStack()
                },
                onDismissErrorDialog = { votingViewModel.dismissErrorDialog() },
                onDismissCompletionDialog = { 
                    votingViewModel.dismissCompletionDialog()
                    // Set flag to refresh group details when returning
                    // Try to get the back stack entry for Group Details
                    try {
                        val groupDetailsRoute = Screen.GroupDetails(votingGroupId).createRoute(votingGroupId)
                        val backStackEntry = navController.getBackStackEntry(groupDetailsRoute)
                        backStackEntry.savedStateHandle.set("refreshGroupDetails", true)
                    } catch (e: Exception) {
                        // Fallback: try previousBackStackEntry or use navigate instead
                        navController.previousBackStackEntry?.savedStateHandle?.set("refreshGroupDetails", true)
                    }
                    // Use navigateUp to ensure proper navigation handling
                    if (!navController.popBackStack()) {
                        // If popBackStack fails, navigate directly to Group Details
                        navController.navigate(Screen.GroupDetails(votingGroupId).createRoute(votingGroupId))
                    }
                },
                onDismissInvalidSwipeDialog = { votingViewModel.dismissInvalidSwipeDialog() },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
