// Firebase Cloud Messaging Service

package com.movieswipe.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.movieswipe.MainActivity
import com.movieswipe.ui.navigation.Screen

class MyFirebaseMessagingService : FirebaseMessagingService() {
    
    override fun onNewToken(token: String) {
        Log.d("FCM", "Refreshed token: $token")
        // Token refresh will be handled by registering it with backend
        // This can be done when the user signs in or when token changes
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.d("FCM", "onMessageReceived called - From: ${remoteMessage.from}")
        Log.d("FCM", "Message ID: ${remoteMessage.messageId}")
        Log.d("FCM", "Message Type: ${remoteMessage.messageType}")

        // Check if message contains data payload
        if (remoteMessage.data.isNotEmpty()) {
            Log.d("FCM", "Message data payload: ${remoteMessage.data}")
        } else {
            Log.d("FCM", "No data payload in message")
        }

        // Handle live updates for foreground: send local broadcast for userJoinedGroup and userLeftGroup
        // Do this FIRST before showing notifications, so the update happens immediately
        val notificationType = remoteMessage.data["notificationType"]
        val groupId = remoteMessage.data["groupId"]
        if (notificationType == "userJoinedGroup" && groupId != null) {
            Log.d("FCM", "Sending local broadcast for userJoinedGroup - groupId: $groupId")
            val intent = Intent("com.movieswipe.USER_JOINED_GROUP").apply {
                putExtra("groupId", groupId)
                setPackage(packageName) // Explicitly set package for local broadcast
            }
            sendBroadcast(intent)
            Log.d("FCM", "Broadcast sent successfully for userJoinedGroup - groupId: $groupId")
        } else if (notificationType == "userLeftGroup" && groupId != null) {
            Log.d("FCM", "Sending local broadcast for userLeftGroup - groupId: $groupId")
            val intent = Intent("com.movieswipe.USER_LEFT_GROUP").apply {
                putExtra("groupId", groupId)
                setPackage(packageName) // Explicitly set package for local broadcast
            }
            sendBroadcast(intent)
            Log.d("FCM", "Broadcast sent successfully for userLeftGroup - groupId: $groupId")
        } else {
            Log.d("FCM", "Not sending broadcast - notificationType: $notificationType, groupId: $groupId")
        }
        
        // Check if message contains notification payload
        if (remoteMessage.notification != null) {
            val notification = remoteMessage.notification!!
            Log.d("FCM", "Message has notification payload")
            Log.d("FCM", "Notification Title: ${notification.title}")
            Log.d("FCM", "Notification Body: ${notification.body}")
            
            // Display notification (needed when app is in foreground)
            // Note: When app is in background, FCM displays notification automatically
            // and onMessageReceived is NOT called
            showNotification(
                title = notification.title ?: "MovieSwipe",
                body = notification.body ?: "",
                data = remoteMessage.data
            )
        } else {
            Log.d("FCM", "No notification payload in message")
        }
        
        // Also handle data-only messages
        if (remoteMessage.data.isNotEmpty() && remoteMessage.notification == null) {
            Log.d("FCM", "Handling data-only message")
            val title = remoteMessage.data["title"] ?: "MovieSwipe"
            val body = remoteMessage.data["body"] ?: ""
            showNotification(title, body, remoteMessage.data)
        }
    }
    
    private fun showNotification(title: String, body: String, data: Map<String, String>) {
        Log.d("FCM", "showNotification called - Title: $title, Body: $body")
        
        // Check if this notification is intended for the current user
        val recipientUserId = data["recipientUserId"]
        if (recipientUserId != null) {
            val prefs = getSharedPreferences("movieswipe_prefs", Context.MODE_PRIVATE)
            val currentUserId = prefs.getString("current_user_id", null)
            
            if (currentUserId != null && currentUserId != recipientUserId) {
                Log.d("FCM", "Notification recipientUserId ($recipientUserId) does not match current user ($currentUserId). Skipping notification display.")
                return
            } else if (currentUserId == null) {
                Log.d("FCM", "No current user ID found in SharedPreferences. Displaying notification anyway (user may not be signed in yet).")
            } else {
                Log.d("FCM", "Notification recipientUserId ($recipientUserId) matches current user ($currentUserId). Displaying notification.")
            }
        } else {
            Log.d("FCM", "No recipientUserId in notification data. Displaying notification (legacy notification).")
        }
        
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        // Check if notifications are enabled
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (!notificationManager.areNotificationsEnabled()) {
                Log.e("FCM", "Notifications are disabled for this app")
                return
            }
        }
        
        // Create notification channel for Android 8.0+
        createNotificationChannel(notificationManager)
        
        // Create intent for when notification is tapped
        // Determine which screen to navigate to based on notification type
        val groupId = data["groupId"]
        val notificationType = data["notificationType"]
        
        val intent = Intent(this, MainActivity::class.java).apply {
            // Use CLEAR_TOP to ensure activity is recreated with new intent
            // This ensures onCreate is called even if activity is already running
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            
            // Add all data payload to intent for deep linking
            data.forEach { (key, value) ->
                putExtra(key, value)
            }
            
            // Explicitly set navigation extras based on notification type
            if (notificationType == "votingSessionStarted" && groupId != null) {
                putExtra("navigateTo", "groupDetails")
                putExtra("groupId", groupId)
                Log.d("FCM", "Setting notification navigation - navigateTo: groupDetails, groupId: $groupId")
            } else if (notificationType == "votingSessionEnded" && groupId != null) {
                putExtra("navigateTo", "groupDetails")
                putExtra("groupId", groupId)
                Log.d("FCM", "Setting notification navigation - navigateTo: groupDetails, groupId: $groupId")
            } else if (notificationType == "userJoinedGroup" && groupId != null) {
                putExtra("navigateTo", "groupDetails")
                putExtra("groupId", groupId)
                Log.d("FCM", "Setting notification navigation - navigateTo: groupDetails, groupId: $groupId")
            } else if (notificationType == "userLeftGroup" && groupId != null) {
                putExtra("navigateTo", "groupDetails")
                putExtra("groupId", groupId)
                Log.d("FCM", "Setting notification navigation - navigateTo: groupDetails, groupId: $groupId")
            } else if (notificationType == "groupDeleted") {
                putExtra("navigateTo", "groupList")
                Log.d("FCM", "Setting notification navigation - navigateTo: groupList")
            }
        }
        
        // Use unique request code based on groupId to ensure PendingIntent is updated
        val requestCode = groupId?.hashCode()?.and(0x7FFFFFFF) ?: System.currentTimeMillis().toInt()
        
        val pendingIntent = PendingIntent.getActivity(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
        
        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
        Log.d("FCM", "Notification displayed: $title - $body")
    }
    
    private fun createNotificationChannel(notificationManager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = CHANNEL_DESCRIPTION
                enableLights(true)
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    companion object {
        private const val CHANNEL_ID = "movieswipe_notifications"
        private const val CHANNEL_NAME = "MovieSwipe Notifications"
        private const val CHANNEL_DESCRIPTION = "Notifications for voting sessions and group updates"
    }
}

