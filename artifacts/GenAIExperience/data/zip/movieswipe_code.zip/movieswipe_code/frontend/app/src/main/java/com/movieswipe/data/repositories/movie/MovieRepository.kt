// Movie domain repositories

package com.movieswipe.data.repositories.movie

import com.movieswipe.data.datasources.movie.Genre
import com.movieswipe.data.datasources.movie.MovieDataSource

class MovieRepository(
    private val movieDataSource: MovieDataSource
) {
    suspend fun getGenres(): List<Genre> {
        val result = movieDataSource.getGenres()
        return result.getOrElse { throw it }
    }
}
