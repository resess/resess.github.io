// VotingGroup domain repositories

package com.movieswipe.data.repositories.votinggroup

import com.movieswipe.data.datasources.votinggroup.CreatedVotingGroup
import com.movieswipe.data.datasources.votinggroup.DeleteGroupResponse
import com.movieswipe.data.datasources.votinggroup.GroupDetails
import com.movieswipe.data.datasources.votinggroup.GroupWithRole
import com.movieswipe.data.datasources.votinggroup.JoinGroupResponse
import com.movieswipe.data.datasources.votinggroup.LeaveGroupResponse
import com.movieswipe.data.datasources.votinggroup.NextMovieToVoteOnResponse
import com.movieswipe.data.datasources.votinggroup.SubmitVoteResponse
import com.movieswipe.data.datasources.votinggroup.ValidateInvitationCodeResponse
import com.movieswipe.data.datasources.votinggroup.VotingGroupDataSource

class VotingGroupRepository(
    private val votingGroupDataSource: VotingGroupDataSource
) {
    suspend fun createGroup(
        name: String,
        ownerId: String,
        genrePreferences: List<Int>
    ): CreatedVotingGroup {
        val result = votingGroupDataSource.createGroup(
            name = name,
            ownerId = ownerId,
            genrePreferences = genrePreferences
        )
        return result.getOrElse { throw it }
    }

    suspend fun getGroupsList(userId: String): List<GroupWithRole> {
        val result = votingGroupDataSource.getGroupsList(userId)
        return result.getOrElse { throw it }
    }

    suspend fun getGroupDetails(groupId: String, userId: String): GroupDetails {
        val result = votingGroupDataSource.getGroupDetails(groupId, userId)
        return result.getOrElse { throw it }
    }

    suspend fun deleteGroup(groupId: String, userId: String): DeleteGroupResponse {
        val result = votingGroupDataSource.deleteGroup(groupId, userId)
        return result.getOrElse { throw it }
    }

    suspend fun validateInvitationCode(
        invitationCode: String,
        userId: String
    ): ValidateInvitationCodeResponse {
        val result = votingGroupDataSource.validateInvitationCode(invitationCode, userId)
        return result.getOrElse { throw it }
    }

    suspend fun getGroupGenres(invitationCode: String): List<Int> {
        val result = votingGroupDataSource.getGroupGenres(invitationCode)
        return result.getOrElse { throw it }
    }

    suspend fun joinGroup(
        invitationCode: String,
        userId: String,
        genrePreferences: List<Int>
    ): JoinGroupResponse {
        val result = votingGroupDataSource.joinGroup(invitationCode, userId, genrePreferences)
        return result.getOrElse { throw it }
    }

    suspend fun leaveGroup(groupId: String, userId: String): LeaveGroupResponse {
        val result = votingGroupDataSource.leaveGroup(groupId, userId)
        return result.getOrElse { throw it }
    }

    suspend fun startVotingSession(groupId: String, userId: String): GroupDetails {
        val result = votingGroupDataSource.startVotingSession(groupId, userId)
        return result.getOrElse { throw it }
    }

    suspend fun endVotingSession(groupId: String, userId: String): GroupDetails {
        val result = votingGroupDataSource.endVotingSession(groupId, userId)
        return result.getOrElse { throw it }
    }

    suspend fun getNextMovieToVoteOn(
        groupId: String,
        userId: String
    ): NextMovieToVoteOnResponse {
        val result = votingGroupDataSource.getNextMovieToVoteOn(groupId, userId)
        return result.getOrElse { throw it }
    }

    suspend fun submitVote(
        groupId: String,
        userId: String,
        movieId: Int,
        voteType: String
    ): SubmitVoteResponse {
        val result = votingGroupDataSource.submitVote(groupId, userId, movieId, voteType)
        return result.getOrElse { throw it }
    }
}
