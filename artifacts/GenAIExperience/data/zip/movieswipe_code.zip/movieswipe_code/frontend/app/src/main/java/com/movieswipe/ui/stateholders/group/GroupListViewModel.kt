// Group feature state holders - Group list

package com.movieswipe.ui.stateholders.group

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.movieswipe.data.datasources.votinggroup.GroupWithRole
import com.movieswipe.data.repositories.votinggroup.VotingGroupRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class GroupListUiState(
    val groups: List<GroupWithRole> = emptyList(),
    val isLoading: Boolean = false,
    val loadError: String? = null,
    val showErrorDialog: Boolean = false
)

class GroupListViewModel(
    private val votingGroupRepository: VotingGroupRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(GroupListUiState())
    val uiState: StateFlow<GroupListUiState> = _uiState.asStateFlow()

    fun loadGroups(userId: String) {
        if (_uiState.value.isLoading) {
            return
        }

        _uiState.value = _uiState.value.copy(
            isLoading = true,
            loadError = null,
            showErrorDialog = false
        )

        viewModelScope.launch {
            try {
                val groups = votingGroupRepository.getGroupsList(userId)
                _uiState.value = _uiState.value.copy(
                    groups = groups,
                    isLoading = false,
                    loadError = null,
                    showErrorDialog = false
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("Failed to load groups", ignoreCase = true) == true -> {
                        "Failed to load groups. Please retry."
                    }
                    else -> {
                        "Failed to load groups. Please retry."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    loadError = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun retryLoadGroups(userId: String) {
        loadGroups(userId)
    }

    fun refreshGroups(userId: String) {
        _uiState.value = _uiState.value.copy(
            isLoading = true,
            loadError = null,
            showErrorDialog = false
        )

        viewModelScope.launch {
            try {
                val groups = votingGroupRepository.getGroupsList(userId)
                _uiState.value = _uiState.value.copy(
                    groups = groups,
                    isLoading = false,
                    loadError = null,
                    showErrorDialog = false
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("Failed to load groups", ignoreCase = true) == true -> {
                        "Failed to load groups. Please retry."
                    }
                    else -> {
                        "Failed to load groups. Please retry."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    loadError = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun dismissErrorDialog() {
        _uiState.value = _uiState.value.copy(
            showErrorDialog = false
        )
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(
            loadError = null,
            showErrorDialog = false
        )
    }
}
