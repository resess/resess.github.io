// Voting feature UI elements

package com.movieswipe.ui.ui_elements.voting

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.movieswipe.data.datasources.votinggroup.SelectedMovie

@Composable
fun VotingScreen(
    groupId: String,
    movie: SelectedMovie?,
    isLoading: Boolean = false,
    errorMessage: String? = null,
    showErrorDialog: Boolean = false,
    showCompletionDialog: Boolean = false,
    showInvalidSwipeDialog: Boolean = false,
    genres: Map<Int, String> = emptyMap(),
    onSwipeRight: (Int) -> Unit,
    onSwipeLeft: (Int) -> Unit,
    onInvalidSwipe: () -> Unit,
    onExitClick: () -> Unit,
    onDismissErrorDialog: () -> Unit,
    onDismissCompletionDialog: () -> Unit,
    onDismissInvalidSwipeDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(modifier = modifier.fillMaxSize()) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
                movie == null && errorMessage == null && !isLoading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No more movies to vote on",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                errorMessage != null -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = onExitClick) {
                            Text("Go Back")
                        }
                    }
                }
                else -> {
                    movie?.let { currentMovie ->
                        Column(
                            modifier = Modifier.fillMaxSize()
                        ) {
                            MovieCard(
                                movie = currentMovie,
                                genres = genres,
                                onSwipeRight = { onSwipeRight(currentMovie.movieId) },
                                onSwipeLeft = { onSwipeLeft(currentMovie.movieId) },
                                onInvalidSwipe = onInvalidSwipe,
                                modifier = Modifier.weight(1f)
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            // Swipe instructions
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                SwipeHint(
                                    text = "Not Interested",
                                    modifier = Modifier.weight(1f)
                                )
                                
                                Spacer(modifier = Modifier.width(16.dp))
                                
                                SwipeHint(
                                    text = "Interested",
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Button(
                                onClick = onExitClick,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Text("Exit Voting Session")
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }
                }
            }
            
            if (showErrorDialog && errorMessage != null) {
                ErrorDialog(
                    errorMessage = errorMessage,
                    onDismiss = onDismissErrorDialog,
                    onExitClick = onExitClick
                )
            }
            
            if (showCompletionDialog) {
                CompletionDialog(
                    onDismiss = onDismissCompletionDialog,
                    onConfirm = onExitClick
                )
            }
            
            if (showInvalidSwipeDialog) {
                InvalidSwipeDialog(
                    onDismiss = onDismissInvalidSwipeDialog
                )
            }
        }
    }
}

@Composable
private fun MovieCard(
    movie: SelectedMovie,
    genres: Map<Int, String>,
    onSwipeRight: () -> Unit,
    onSwipeLeft: () -> Unit,
    onInvalidSwipe: () -> Unit,
    modifier: Modifier = Modifier
) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var rotation by remember { mutableFloatStateOf(0f) }
    var alpha by remember { mutableFloatStateOf(1f) }
    
    val swipeThreshold = 200f
    val rotationFactor = 0.1f
    val verticalSwipeThreshold = 150f
    
    // Determine swipe direction for visual feedback
    val isSwipingRight = offsetX > 50f
    val isSwipingLeft = offsetX < -50f
    val swipeFeedbackAlpha = (kotlin.math.abs(offsetX) / 300f).coerceIn(0f, 1f)
    
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        // Swipe feedback overlay
        if (isSwipingRight || isSwipingLeft) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(swipeFeedbackAlpha),
                contentAlignment = Alignment.Center
            ) {
                val feedbackText = if (isSwipingRight) "Interested" else "Not Interested"
                val backgroundColor = if (isSwipingRight) {
                    MaterialTheme.colorScheme.primaryContainer
                } else {
                    MaterialTheme.colorScheme.errorContainer
                }
                val textColor = if (isSwipingRight) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onErrorContainer
                }
                
                Card(
                    modifier = Modifier.padding(32.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = backgroundColor
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = feedbackText,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = textColor,
                        modifier = Modifier.padding(24.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(600.dp)
                .offset(x = offsetX.dp, y = offsetY.dp)
                .rotate(rotation)
                .alpha(alpha)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragEnd = {
                            val absX = kotlin.math.abs(offsetX)
                            val absY = kotlin.math.abs(offsetY)
                            
                            when {
                                absY > verticalSwipeThreshold && absY > absX -> {
                                    onInvalidSwipe()
                                    offsetX = 0f
                                    offsetY = 0f
                                    rotation = 0f
                                    alpha = 1f
                                }
                                offsetX > swipeThreshold -> {
                                    onSwipeRight()
                                }
                                offsetX < -swipeThreshold -> {
                                    onSwipeLeft()
                                }
                                else -> {
                                    offsetX = 0f
                                    offsetY = 0f
                                    rotation = 0f
                                    alpha = 1f
                                }
                            }
                        }
                    ) { change, dragAmount ->
                        offsetX += dragAmount.x
                        offsetY += dragAmount.y
                        
                        val absX = kotlin.math.abs(offsetX)
                        val absY = kotlin.math.abs(offsetY)
                        
                        if (absX > absY) {
                            rotation = offsetX * rotationFactor
                            val distance = absX
                            val maxDistance = 500f
                            alpha = (1f - (distance / maxDistance).coerceIn(0f, 0.5f))
                        } else {
                            rotation = 0f
                        }
                        
                        change.consume()
                    }
                },
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    if (movie.posterUrl != null) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(movie.posterUrl)
                                .crossfade(true)
                                .build(),
                            contentDescription = movie.title,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No Image",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = movie.title,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Rating: ${String.format("%.1f", movie.rating)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        Text(
                            text = "${movie.length} min",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    if (movie.genres.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            movie.genres.take(3).forEach { genreId ->
                                val genreName = genres[genreId] ?: "Genre $genreId"
                                Card(
                                    modifier = Modifier.padding(vertical = 4.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                                    )
                                ) {
                                    Text(
                                        text = genreName,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(
                        text = "Summary",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Text(
                        text = movie.summary,
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 20.sp,
                        maxLines = 8,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun SwipeHint(
    text: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = if (text == "Interested") "→" else "←",
            style = MaterialTheme.typography.displaySmall,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun ErrorDialog(
    errorMessage: String,
    onDismiss: () -> Unit,
    onExitClick: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Error",
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(onClick = onExitClick) {
                Text("Go Back")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Stay")
            }
        }
    )
}

@Composable
private fun CompletionDialog(
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Voting Complete",
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Text(
                text = "You have finished voting for all movies.",
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(onClick = onConfirm) {
                Text("OK")
            }
        }
    )
}

@Composable
private fun InvalidSwipeDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Invalid Swipe",
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Text(
                text = "Swipe right for 'interested' or left for 'not interested'. No other swiping gesture allowed.",
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("OK")
            }
        }
    )
}
