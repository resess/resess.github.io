// Movie domain data sources

package com.movieswipe.data.datasources.movie

import android.util.Log
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.movieswipe.utils.Constants
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import java.io.IOException

interface MovieDataSource {
    suspend fun getGenres(): Result<List<Genre>>
}

data class Genre(
    val id: Int,
    val name: String
)

data class GenresResponse(
    val genres: List<Genre>
)

data class ErrorResponse(
    val error: String
)

interface MovieApiService {
    @GET("movies/genres")
    suspend fun getGenres(): GenresResponse
}

class MovieDataSourceImpl : MovieDataSource {
    private val retrofit = Retrofit.Builder()
        .baseUrl(Constants.BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val apiService = retrofit.create(MovieApiService::class.java)

    override suspend fun getGenres(): Result<List<Genre>> {
        return try {
            val response = apiService.getGenres()
            Result.success(response.genres)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessage(e.code())
            } catch (parseException: Exception) {
                Log.e("MovieDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessage(e.code())
            }
            Log.e("MovieDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("MovieDataSource", "Network error", e)
            Result.failure(Exception("Failed to load movie genres. Please try again."))
        } catch (e: Exception) {
            Log.e("MovieDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to load movie genres. Please try again."))
        }
    }

    private fun getDefaultErrorMessage(code: Int): String {
        return when (code) {
            500 -> "Failed to load movie genres. Please try again."
            else -> "Failed to load movie genres. Please try again."
        }
    }
}
