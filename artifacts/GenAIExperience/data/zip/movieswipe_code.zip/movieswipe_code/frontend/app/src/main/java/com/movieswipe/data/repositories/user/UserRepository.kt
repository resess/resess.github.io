// User domain repositories

package com.movieswipe.data.repositories.user

import com.movieswipe.data.datasources.user.AuthenticatedUser
import com.movieswipe.data.datasources.user.UserDataSource

class UserRepository(
    private val userDataSource: UserDataSource
) {
    suspend fun signIn(idToken: String): AuthenticatedUser {
        val result = userDataSource.signIn(idToken)
        return result.getOrElse { throw it }
    }

    suspend fun signOut(idToken: String) {
        val result = userDataSource.signOut(idToken)
        result.getOrElse { throw it }
    }

    suspend fun registerFcmToken(userId: String, fcmToken: String) {
        val result = userDataSource.registerFcmToken(userId, fcmToken)
        result.getOrElse { throw it }
    }
}
