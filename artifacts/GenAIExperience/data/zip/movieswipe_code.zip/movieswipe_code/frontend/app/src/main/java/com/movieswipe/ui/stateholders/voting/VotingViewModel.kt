// Voting feature state holders

package com.movieswipe.ui.stateholders.voting

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.movieswipe.data.datasources.votinggroup.SelectedMovie
import com.movieswipe.data.repositories.movie.MovieRepository
import com.movieswipe.data.repositories.votinggroup.VotingGroupRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class VotingUiState(
    val movie: SelectedMovie? = null,
    val isLoading: Boolean = false,
    val isLoadingGenres: Boolean = false,
    val errorMessage: String? = null,
    val showErrorDialog: Boolean = false,
    val showCompletionDialog: Boolean = false,
    val showInvalidSwipeDialog: Boolean = false,
    val genres: Map<Int, String> = emptyMap()
)

class VotingViewModel(
    private val votingGroupRepository: VotingGroupRepository,
    private val movieRepository: MovieRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(VotingUiState())
    val uiState: StateFlow<VotingUiState> = _uiState.asStateFlow()

    fun loadGenres() {
        if (_uiState.value.isLoadingGenres || _uiState.value.genres.isNotEmpty()) {
            return
        }

        _uiState.value = _uiState.value.copy(
            isLoadingGenres = true
        )

        viewModelScope.launch {
            try {
                val genresList = movieRepository.getGenres()
                val genresMap = genresList.associate { genre -> genre.id to genre.name }
                _uiState.value = _uiState.value.copy(
                    genres = genresMap,
                    isLoadingGenres = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoadingGenres = false
                )
            }
        }
    }

    fun loadNextMovieToVoteOn(groupId: String, userId: String) {
        if (_uiState.value.isLoading) {
            return
        }

        _uiState.value = _uiState.value.copy(
            isLoading = true,
            errorMessage = null,
            showErrorDialog = false
        )

        viewModelScope.launch {
            try {
                val result = votingGroupRepository.getNextMovieToVoteOn(groupId, userId)
                
                if (result.hasVotedOnAllMovies) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        movie = null,
                        showCompletionDialog = true
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        movie = result.movie,
                        errorMessage = null,
                        showErrorDialog = false
                    )
                }
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("The voting session has ended", ignoreCase = true) == true -> {
                        "The voting session has ended."
                    }
                    e.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                        "This group has been deleted."
                    }
                    e.message?.contains("You are no longer a member", ignoreCase = true) == true -> {
                        "You are no longer a member of this group."
                    }
                    else -> {
                        "Failed to load next movie. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun submitVote(groupId: String, userId: String, movieId: Int, voteType: String) {
        if (_uiState.value.isLoading) {
            return
        }

        if (voteType != "like" && voteType != "dislike") {
            _uiState.value = _uiState.value.copy(
                showInvalidSwipeDialog = true
            )
            return
        }

        _uiState.value = _uiState.value.copy(
            isLoading = true,
            errorMessage = null,
            showErrorDialog = false
        )

        viewModelScope.launch {
            try {
                val result = votingGroupRepository.submitVote(
                    groupId = groupId,
                    userId = userId,
                    movieId = movieId,
                    voteType = voteType
                )
                
                if (result.hasVotedOnAllMovies) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        movie = null,
                        showCompletionDialog = true
                    )
                } else {
                    // Load next movie while keeping loading state
                    try {
                        val nextMovieResult = votingGroupRepository.getNextMovieToVoteOn(groupId, userId)
                        
                        if (nextMovieResult.hasVotedOnAllMovies) {
                            _uiState.value = _uiState.value.copy(
                                isLoading = false,
                                movie = null,
                                showCompletionDialog = true
                            )
                        } else {
                            _uiState.value = _uiState.value.copy(
                                isLoading = false,
                                movie = nextMovieResult.movie,
                                errorMessage = null,
                                showErrorDialog = false
                            )
                        }
                    } catch (nextMovieError: Exception) {
                        val errorMessage = when {
                            nextMovieError.message?.contains("The voting session has ended", ignoreCase = true) == true -> {
                                "The voting session has ended."
                            }
                            nextMovieError.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                                "This group has been deleted."
                            }
                            nextMovieError.message?.contains("You are no longer a member", ignoreCase = true) == true -> {
                                "You are no longer a member of this group."
                            }
                            else -> {
                                "Failed to load next movie. Please try again."
                            }
                        }
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = errorMessage,
                            showErrorDialog = true
                        )
                    }
                }
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("The voting session has ended", ignoreCase = true) == true -> {
                        "The voting session has ended."
                    }
                    e.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                        "This group has been deleted."
                    }
                    e.message?.contains("You are no longer a member", ignoreCase = true) == true -> {
                        "You are no longer a member of this group."
                    }
                    e.message?.contains("This movie is not part", ignoreCase = true) == true -> {
                        "This movie is not part of the voting session."
                    }
                    else -> {
                        "Failed to submit vote. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun dismissErrorDialog() {
        _uiState.value = _uiState.value.copy(
            showErrorDialog = false
        )
    }

    fun dismissCompletionDialog() {
        _uiState.value = _uiState.value.copy(
            showCompletionDialog = false
        )
    }

    fun showInvalidSwipeDialog() {
        _uiState.value = _uiState.value.copy(
            showInvalidSwipeDialog = true
        )
    }

    fun dismissInvalidSwipeDialog() {
        _uiState.value = _uiState.value.copy(
            showInvalidSwipeDialog = false
        )
    }

    fun resetState() {
        _uiState.value = VotingUiState()
    }
}
