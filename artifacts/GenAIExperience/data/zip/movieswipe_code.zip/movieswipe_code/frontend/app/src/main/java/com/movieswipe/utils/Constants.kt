// Common helpers, utilities, constants, and extension functions

package com.movieswipe.utils

object Constants {
    const val BASE_URL = "http://10.0.2.2:3000/api/"
}
