// Group feature UI elements - Group list

package com.movieswipe.ui.ui_elements.group

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.movieswipe.data.datasources.movie.Genre as DataGenre
import com.movieswipe.data.datasources.votinggroup.GroupWithRole
import com.movieswipe.ui.ui_elements.authentication.SignOutButton
import com.movieswipe.ui.ui_elements.group.Genre

@Composable
fun GroupListScreen(
    groups: List<GroupWithRole>,
    isLoading: Boolean = false,
    loadError: String? = null,
    showErrorDialog: Boolean = false,
    onRetryClick: () -> Unit,
    onDismissErrorDialog: () -> Unit,
    onSignOutClick: () -> Unit,
    onCreateGroupClick: () -> Unit,
    onJoinGroupClick: () -> Unit,
    onGroupClick: (String) -> Unit = {},
    isSigningOut: Boolean = false,
    signOutError: String? = null,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "Groups",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            } else if (groups.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No groups yet. Create or join a group to get started.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(groups) { group ->
                        GroupListItem(
                            groupName = group.name,
                            role = group.role,
                            onClick = { onGroupClick(group.id) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onCreateGroupClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Create New Group",
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                Button(
                    onClick = onJoinGroupClick,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Join Group",
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                SignOutButton(
                    onSignOutClick = onSignOutClick,
                    isLoading = isSigningOut,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (showErrorDialog) {
            AlertDialog(
                onDismissRequest = onDismissErrorDialog,
                title = {
                    Text(
                        text = "Error",
                        style = MaterialTheme.typography.headlineSmall
                    )
                },
                text = {
                    Text(
                        text = loadError ?: "Failed to load groups. Please retry.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                confirmButton = {
                    Button(onClick = onRetryClick) {
                        Text(
                            text = "Retry",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            )
        }
    }
}

@Composable
private fun GroupListItem(
    groupName: String,
    role: String,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = groupName,
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = role.replaceFirstChar { it.uppercaseChar() },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun GroupListScreenWithCreateGroup(
    groups: List<GroupWithRole>,
    isLoading: Boolean = false,
    loadError: String? = null,
    showErrorDialog: Boolean = false,
    onRetryClick: () -> Unit,
    onDismissErrorDialog: () -> Unit,
    onSignOutClick: () -> Unit,
    onCreateGroupClick: () -> Unit,
    onJoinGroupClick: () -> Unit,
    onGroupClick: (String) -> Unit = {},
    showGroupNameDialog: Boolean,
    showGenrePreferencesScreen: Boolean,
    groupName: String,
    onGroupNameChange: (String) -> Unit,
    onNextClick: () -> Unit,
    onCloseGroupNameDialog: () -> Unit,
    genres: List<DataGenre>,
    selectedGenres: Set<Int>,
    onGenreToggle: (Int) -> Unit,
    onCreateGroupClickFromGenres: () -> Unit,
    onBackFromGenres: () -> Unit,
    isLoadingGenres: Boolean,
    isLoadingCreateGroup: Boolean,
    groupNameError: String?,
    genresError: String?,
    createGroupError: String?,
    onRetryLoadGenres: () -> Unit,
    isSigningOut: Boolean = false,
    signOutError: String? = null,
    showInvitationCodeDialog: Boolean = false,
    invitationCode: String = "",
    onInvitationCodeChange: (String) -> Unit = {},
    onInvitationCodeNextClick: () -> Unit = {},
    onCloseInvitationCodeDialog: () -> Unit = {},
    isLoadingValidateCode: Boolean = false,
    invitationCodeError: String? = null,
    showJoinGroupGenrePreferencesScreen: Boolean = false,
    joinGroupGenres: List<DataGenre> = emptyList(),
    joinGroupSelectedGenres: Set<Int> = emptySet(),
    onJoinGroupGenreToggle: (Int) -> Unit = {},
    onConfirmJoinGroupClick: () -> Unit = {},
    onBackFromJoinGroupGenres: () -> Unit = {},
    isLoadingJoinGroupGenres: Boolean = false,
    isLoadingJoin: Boolean = false,
    joinGroupGenresError: String? = null,
    joinGroupError: String? = null,
    showRetryJoinGroupGenresDialog: Boolean = false,
    onDismissRetryJoinGroupGenresDialog: () -> Unit = {},
    onRetryLoadJoinGroupGenres: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        // Only show GroupListScreen when not showing genre preferences screen or join group genre preferences screen
        if (!showGenrePreferencesScreen && !showJoinGroupGenrePreferencesScreen) {
            GroupListScreen(
                groups = groups,
                isLoading = isLoading,
                loadError = loadError,
                showErrorDialog = showErrorDialog,
                onRetryClick = onRetryClick,
                onDismissErrorDialog = onDismissErrorDialog,
                onSignOutClick = onSignOutClick,
                onCreateGroupClick = onCreateGroupClick,
                onJoinGroupClick = onJoinGroupClick,
                onGroupClick = onGroupClick,
                isSigningOut = isSigningOut,
                signOutError = signOutError
            )
        }

        if (showGroupNameDialog) {
            GroupNameDialog(
                groupName = groupName,
                onGroupNameChange = onGroupNameChange,
                onNextClick = onNextClick,
                onDismiss = onCloseGroupNameDialog,
                isLoading = isLoadingCreateGroup,
                errorMessage = groupNameError
            )
        }

        if (showGenrePreferencesScreen) {
            val uiGenres: List<Genre> = genres.map { dataGenre ->
                Genre(
                    id = dataGenre.id,
                    name = dataGenre.name
                )
            }
            GenrePreferencesScreen(
                genres = uiGenres,
                selectedGenres = selectedGenres,
                onGenreToggle = onGenreToggle,
                onCreateGroupClick = onCreateGroupClickFromGenres,
                onBackClick = onBackFromGenres,
                isLoading = isLoadingCreateGroup,
                isLoadingGenres = isLoadingGenres,
                errorMessage = genresError ?: createGroupError
            )
        }

        if (showInvitationCodeDialog) {
            InvitationCodeDialog(
                invitationCode = invitationCode,
                onInvitationCodeChange = onInvitationCodeChange,
                onNextClick = onInvitationCodeNextClick,
                onDismiss = onCloseInvitationCodeDialog,
                isLoading = isLoadingValidateCode,
                errorMessage = invitationCodeError
            )
        }

        if (showJoinGroupGenrePreferencesScreen) {
            val uiJoinGroupGenres: List<Genre> = joinGroupGenres.map { dataGenre ->
                Genre(
                    id = dataGenre.id,
                    name = dataGenre.name
                )
            }
            JoinGroupGenrePreferencesScreen(
                genres = uiJoinGroupGenres,
                selectedGenres = joinGroupSelectedGenres,
                onGenreToggle = onJoinGroupGenreToggle,
                onJoinClick = onConfirmJoinGroupClick,
                onBackClick = onBackFromJoinGroupGenres,
                isLoading = isLoadingJoin,
                isLoadingGenres = isLoadingJoinGroupGenres,
                errorMessage = joinGroupGenresError ?: joinGroupError,
                showRetryDialog = showRetryJoinGroupGenresDialog,
                onDismissRetryDialog = onDismissRetryJoinGroupGenresDialog,
                onRetryClick = onRetryLoadJoinGroupGenres
            )
        }
    }
}
