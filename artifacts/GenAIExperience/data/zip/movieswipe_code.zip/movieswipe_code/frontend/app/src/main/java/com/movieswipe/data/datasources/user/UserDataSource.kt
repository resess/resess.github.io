// User domain data sources

package com.movieswipe.data.datasources.user

import android.util.Log
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.movieswipe.utils.Constants
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.io.IOException

interface UserDataSource {
    suspend fun signIn(idToken: String): Result<AuthenticatedUser>
    suspend fun signOut(idToken: String): Result<Unit>
    suspend fun registerFcmToken(userId: String, fcmToken: String): Result<Unit>
}

data class AuthenticatedUser(
    val id: String,
    val email: String,
    val name: String,
    @SerializedName("profilePictureUrl")
    val profilePictureUrl: String?
)

data class SignInRequest(
    val idToken: String
)

data class SignOutRequest(
    val idToken: String
)

data class SignOutResponse(
    val message: String
)

data class RegisterFcmTokenRequest(
    val userId: String,
    val fcmToken: String
)

data class RegisterFcmTokenResponse(
    val message: String
)

data class ErrorResponse(
    val error: String
)

interface UserApiService {
    @POST("users/sign-in")
    suspend fun signIn(@Body request: SignInRequest): AuthenticatedUser
    
    @POST("users/sign-out")
    suspend fun signOut(@Body request: SignOutRequest): SignOutResponse
    
    @POST("users/register-fcm-token")
    suspend fun registerFcmToken(@Body request: RegisterFcmTokenRequest): RegisterFcmTokenResponse
}

class UserDataSourceImpl : UserDataSource {
    private val retrofit = Retrofit.Builder()
        .baseUrl(Constants.BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val apiService = retrofit.create(UserApiService::class.java)

    override suspend fun signIn(idToken: String): Result<AuthenticatedUser> {
        return try {
            val request = SignInRequest(idToken)
            val user = apiService.signIn(request)
            Result.success(user)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessage(e.code())
            } catch (parseException: Exception) {
                Log.e("UserDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessage(e.code())
            }
            Log.e("UserDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("UserDataSource", "Network error", e)
            Result.failure(Exception("Google authentication service temporarily unavailable. Please try again."))
        } catch (e: Exception) {
            Log.e("UserDataSource", "Unexpected error", e)
            Result.failure(Exception("Authentication service temporarily unavailable. Please try again."))
        }
    }

    override suspend fun signOut(idToken: String): Result<Unit> {
        return try {
            val request = SignOutRequest(idToken)
            apiService.signOut(request)
            Result.success(Unit)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultSignOutErrorMessage(e.code())
            } catch (parseException: Exception) {
                Log.e("UserDataSource", "Failed to parse error response", parseException)
                getDefaultSignOutErrorMessage(e.code())
            }
            Log.e("UserDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("UserDataSource", "Network error", e)
            Result.failure(Exception("Authentication service temporarily unavailable, cannot sign out. Please try again."))
        } catch (e: Exception) {
            Log.e("UserDataSource", "Unexpected error", e)
            Result.failure(Exception("Authentication service temporarily unavailable, cannot sign out. Please try again."))
        }
    }

    private fun getDefaultErrorMessage(code: Int): String {
        return when (code) {
            503 -> "Google authentication service temporarily unavailable. Please try again."
            401 -> "Authentication unsuccessful. Please try again."
            else -> "Authentication service temporarily unavailable. Please try again."
        }
    }

    private fun getDefaultSignOutErrorMessage(code: Int): String {
        return when (code) {
            503 -> "Authentication service temporarily unavailable, cannot sign out. Please try again."
            400 -> "Session not found or already revoked"
            else -> "Authentication service temporarily unavailable, cannot sign out. Please try again."
        }
    }

    override suspend fun registerFcmToken(userId: String, fcmToken: String): Result<Unit> {
        return try {
            val request = RegisterFcmTokenRequest(userId, fcmToken)
            apiService.registerFcmToken(request)
            Result.success(Unit)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: "Failed to register FCM token. Please try again."
            } catch (parseException: Exception) {
                Log.e("UserDataSource", "Failed to parse error response", parseException)
                "Failed to register FCM token. Please try again."
            }
            Log.e("UserDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("UserDataSource", "Network error", e)
            Result.failure(Exception("Failed to register FCM token. Please try again."))
        } catch (e: Exception) {
            Log.e("UserDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to register FCM token. Please try again."))
        }
    }
}
