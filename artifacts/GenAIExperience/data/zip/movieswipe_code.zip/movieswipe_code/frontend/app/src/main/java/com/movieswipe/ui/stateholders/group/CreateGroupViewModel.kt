// Group feature state holders - Create group

package com.movieswipe.ui.stateholders.group

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.movieswipe.data.datasources.movie.Genre
import com.movieswipe.data.repositories.movie.MovieRepository
import com.movieswipe.data.repositories.votinggroup.VotingGroupRepository
import com.movieswipe.data.repositories.user.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class CreateGroupUiState(
    val groupName: String = "",
    val showGroupNameDialog: Boolean = false,
    val showGenrePreferencesScreen: Boolean = false,
    val genres: List<Genre> = emptyList(),
    val selectedGenres: Set<Int> = emptySet(),
    val isLoadingGenres: Boolean = false,
    val isLoadingCreateGroup: Boolean = false,
    val groupNameError: String? = null,
    val genresError: String? = null,
    val createGroupError: String? = null,
    val userId: String? = null,
    val createdGroupId: String? = null
)

class CreateGroupViewModel(
    private val movieRepository: MovieRepository,
    private val votingGroupRepository: VotingGroupRepository,
    private val userRepository: UserRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(CreateGroupUiState())
    val uiState: StateFlow<CreateGroupUiState> = _uiState.asStateFlow()

    fun openGroupNameDialog() {
        _uiState.value = _uiState.value.copy(
            showGroupNameDialog = true,
            groupName = "",
            groupNameError = null
        )
    }

    fun closeGroupNameDialog() {
        _uiState.value = _uiState.value.copy(
            showGroupNameDialog = false,
            groupName = "",
            groupNameError = null
        )
    }

    fun updateGroupName(name: String) {
        _uiState.value = _uiState.value.copy(
            groupName = name,
            groupNameError = null
        )
    }

    fun validateAndProceedToGenres() {
        val trimmedName = _uiState.value.groupName.trim()
        
        if (trimmedName.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                groupNameError = "Group name is required and must be 3-30 alphanumeric characters."
            )
            return
        }
        
        if (trimmedName.length < 3 || trimmedName.length > 30) {
            _uiState.value = _uiState.value.copy(
                groupNameError = "Group name is required and must be 3-30 alphanumeric characters."
            )
            return
        }
        
        if (!trimmedName.matches(Regex("^[a-zA-Z0-9]+$"))) {
            _uiState.value = _uiState.value.copy(
                groupNameError = "Group name is required and must be 3-30 alphanumeric characters."
            )
            return
        }
        
        _uiState.value = _uiState.value.copy(
            showGroupNameDialog = false,
            showGenrePreferencesScreen = true,
            groupName = trimmedName,
            groupNameError = null,
            genresError = null
        )
        
        loadGenres()
    }

    fun loadGenres() {
        if (_uiState.value.genres.isNotEmpty()) {
            return
        }
        
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoadingGenres = true,
                genresError = null
            )
            
            try {
                val genresList = movieRepository.getGenres()
                _uiState.value = _uiState.value.copy(
                    genres = genresList,
                    isLoadingGenres = false,
                    genresError = null
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("Failed to load movie genres", ignoreCase = true) == true -> {
                        "Failed to load movie genres. Please try again."
                    }
                    else -> {
                        "Failed to load movie genres. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoadingGenres = false,
                    genresError = errorMessage
                )
            }
        }
    }

    fun retryLoadGenres() {
        _uiState.value = _uiState.value.copy(
            genres = emptyList(),
            genresError = null
        )
        loadGenres()
    }

    fun toggleGenreSelection(genreId: Int) {
        val currentSelected = _uiState.value.selectedGenres.toMutableSet()
        if (currentSelected.contains(genreId)) {
            currentSelected.remove(genreId)
        } else {
            currentSelected.add(genreId)
        }
        _uiState.value = _uiState.value.copy(
            selectedGenres = currentSelected,
            createGroupError = null
        )
    }

    fun goBackToGroupNameDialog() {
        _uiState.value = _uiState.value.copy(
            showGenrePreferencesScreen = false,
            showGroupNameDialog = true,
            createGroupError = null
        )
    }

    fun createGroup(userId: String) {
        if (_uiState.value.selectedGenres.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                createGroupError = "Genre selection is required. Please choose at least two preferred movie genres."
            )
            return
        }
        
        if (_uiState.value.selectedGenres.size < 2) {
            _uiState.value = _uiState.value.copy(
                createGroupError = "Genre selection is required. Please choose at least two preferred movie genres."
            )
            return
        }
        
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoadingCreateGroup = true,
                createGroupError = null,
                userId = userId
            )
            
            try {
                val genreList = _uiState.value.selectedGenres.toList()
                val createdGroup = votingGroupRepository.createGroup(
                    name = _uiState.value.groupName,
                    ownerId = userId,
                    genrePreferences = genreList
                )
                
                _uiState.value = _uiState.value.copy(
                    isLoadingCreateGroup = false,
                    showGenrePreferencesScreen = false,
                    groupName = "",
                    selectedGenres = emptySet(),
                    createGroupError = null,
                    createdGroupId = createdGroup.id
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("Group name is required", ignoreCase = true) == true -> {
                        "Group name is required and must be 3-30 alphanumeric characters."
                    }
                    e.message?.contains("Genre selection is required", ignoreCase = true) == true -> {
                        "Genre selection is required. Please choose at least two preferred movie genres."
                    }
                    e.message?.contains("Failed to create group", ignoreCase = true) == true -> {
                        "Failed to create group. Please try again."
                    }
                    else -> {
                        "Failed to create group. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoadingCreateGroup = false,
                    createGroupError = errorMessage
                )
            }
        }
    }

    fun retryCreateGroup() {
        val userId = _uiState.value.userId
        if (userId != null) {
            createGroup(userId)
        }
    }

    fun resetState() {
        _uiState.value = CreateGroupUiState()
    }

    fun clearGroupNameError() {
        _uiState.value = _uiState.value.copy(groupNameError = null)
    }

    fun clearGenresError() {
        _uiState.value = _uiState.value.copy(genresError = null)
    }

    fun clearCreateGroupError() {
        _uiState.value = _uiState.value.copy(createGroupError = null)
    }
}

