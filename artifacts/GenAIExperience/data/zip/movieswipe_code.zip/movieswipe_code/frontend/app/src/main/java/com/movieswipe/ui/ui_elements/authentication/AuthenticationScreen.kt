// Authentication feature UI elements

package com.movieswipe.ui.ui_elements.authentication

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.movieswipe.ui.theme.MovieSwipeTheme

@Composable
fun AuthenticationScreen(
    onSignInClick: () -> Unit,
    isLoading: Boolean = false,
    errorMessage: String? = null,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 400.dp)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "MovieSwipe",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Sign in to get started",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )

            if (errorMessage != null) {
                Text(
                    text = errorMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            Button(
                onClick = onSignInClick,
                enabled = !isLoading,
                modifier = Modifier
                    .widthIn(min = 200.dp)
                    .padding(top = 16.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.padding(end = 8.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
                Text(
                    text = if (isLoading) "Signing in..." else "Sign in with Google",
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AuthenticationScreenPreview() {
    MovieSwipeTheme {
        AuthenticationScreen(
            onSignInClick = {},
            isLoading = false,
            errorMessage = null
        )
    }
}

@Preview(showBackground = true)
@Composable
fun AuthenticationScreenLoadingPreview() {
    MovieSwipeTheme {
        AuthenticationScreen(
            onSignInClick = {},
            isLoading = true,
            errorMessage = null
        )
    }
}

@Preview(showBackground = true)
@Composable
fun AuthenticationScreenErrorPreview() {
    MovieSwipeTheme {
        AuthenticationScreen(
            onSignInClick = {},
            isLoading = false,
            errorMessage = "Authentication service temporarily unavailable. Please try again."
        )
    }
}

@Composable
fun SignOutButton(
    onSignOutClick: () -> Unit,
    isLoading: Boolean = false,
    enabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onSignOutClick,
        enabled = enabled && !isLoading,
        modifier = modifier
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.padding(end = 8.dp),
                color = MaterialTheme.colorScheme.onPrimary
            )
        }
        Text(
            text = if (isLoading) "Signing out..." else "Sign out",
            style = MaterialTheme.typography.labelLarge
        )
    }
}
