package com.movieswipe

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import android.util.Log
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import com.google.firebase.messaging.FirebaseMessaging
import com.movieswipe.data.datasources.movie.MovieDataSourceImpl
import com.movieswipe.data.datasources.user.UserDataSourceImpl
import com.movieswipe.data.datasources.votinggroup.VotingGroupDataSourceImpl
import com.movieswipe.data.repositories.movie.MovieRepository
import com.movieswipe.data.repositories.user.UserRepository
import com.movieswipe.data.repositories.votinggroup.VotingGroupRepository
import com.movieswipe.ui.navigation.AppNavigation
import com.movieswipe.ui.navigation.Screen
import com.movieswipe.ui.stateholders.authentication.AuthenticationViewModel
import com.movieswipe.ui.stateholders.group.CreateGroupViewModel
import com.movieswipe.ui.stateholders.group.GroupDetailViewModel
import com.movieswipe.ui.stateholders.group.GroupListViewModel
import com.movieswipe.ui.stateholders.group.JoinGroupViewModel
import com.movieswipe.ui.stateholders.voting.VotingViewModel
import com.movieswipe.ui.theme.MovieSwipeTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var googleSignInClient: GoogleSignInClient
    private var currentViewModel: AuthenticationViewModel? = null
    private lateinit var userRepository: UserRepository
    private var currentNavController: androidx.navigation.NavController? = null

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            Log.d("FCM", "Notification permission granted")
        } else {
            Log.w("FCM", "Notification permission denied")
        }
    }

    private val googleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        result.data?.let { intent ->
            val task = GoogleSignIn.getSignedInAccountFromIntent(intent)
            handleGoogleSignInResult(task)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Firebase
        FirebaseApp.initializeApp(this)
        
        // Create notification channel for Android 8.0+
        createNotificationChannel()
        
        // Request notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotificationPermission()
        }
        
        // Handle intent when app is opened from notification (including when already running)
        handleNotificationIntent(intent)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("466642966754-eds5l3rq51lvhhtlto0k9idthd1507eu.apps.googleusercontent.com")
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        val userDataSource = UserDataSourceImpl()
        userRepository = UserRepository(userDataSource)
        
        val movieDataSource = MovieDataSourceImpl()
        val movieRepository = MovieRepository(movieDataSource)
        
        val votingGroupDataSource = VotingGroupDataSourceImpl()
        val votingGroupRepository = VotingGroupRepository(votingGroupDataSource)

        enableEdgeToEdge()
        setContent {
            MovieSwipeTheme {
                val authViewModel = remember { AuthenticationViewModel(userRepository) }
                currentViewModel = authViewModel
                val authUiState by authViewModel.uiState.collectAsState()
                
                val createGroupViewModel = remember { 
                    CreateGroupViewModel(movieRepository, votingGroupRepository, userRepository) 
                }
                val createGroupUiState by createGroupViewModel.uiState.collectAsState()
                
                val groupListViewModel = remember { 
                    GroupListViewModel(votingGroupRepository) 
                }
                val groupListUiState by groupListViewModel.uiState.collectAsState()
                
                val groupDetailViewModel = remember {
                    GroupDetailViewModel(votingGroupRepository, movieRepository)
                }
                
                val joinGroupViewModel = remember {
                    JoinGroupViewModel(votingGroupRepository, movieRepository)
                }
                val joinGroupUiState by joinGroupViewModel.uiState.collectAsState()
                
                val votingViewModel = remember {
                    VotingViewModel(votingGroupRepository, movieRepository)
                }
                
                val scope = rememberCoroutineScope()
                val navController = rememberNavController()
                currentNavController = navController
                
                // Handle deep linking from notifications
                // Check intent extras when component is first created
                var handledNotificationNavigation by remember { mutableStateOf(false) }
                
                // Check for notification intent synchronously to determine if we should attempt silent sign-in
                val navigateTo = remember { intent.getStringExtra("navigateTo") }
                val notificationGroupId = remember { intent.getStringExtra("groupId") }
                val hasNotificationIntent = remember { 
                    (navigateTo == "groupDetails" && notificationGroupId != null) || navigateTo == "groupList"
                }
                var attemptingSilentSignIn by remember { mutableStateOf(hasNotificationIntent && !authUiState.isAuthenticated) }
                
                // Auto-sign in if user has a last signed-in Google account and notification intent exists
                LaunchedEffect(Unit) {
                    if (hasNotificationIntent && !authUiState.isAuthenticated && !authUiState.isLoading) {
                        // Try silent sign-in to get a fresh token
                        Log.d("FCM", "Attempting silent sign-in for notification navigation")
                        attemptingSilentSignIn = true
                        try {
                            val task = googleSignInClient.silentSignIn()
                            val account = suspendCancellableCoroutine<GoogleSignInAccount?> { continuation ->
                                task.addOnCompleteListener { task ->
                                    try {
                                        val result = task.getResult(ApiException::class.java)
                                        continuation.resume(result)
                                    } catch (e: ApiException) {
                                        continuation.resumeWithException(e)
                                    }
                                }
                            }
                            
                            val idToken = account?.idToken
                            if (idToken != null) {
                                Log.d("FCM", "Silent sign-in successful - account: ${account.email}")
                                authViewModel.signIn(idToken)
                            } else {
                                Log.d("FCM", "Silent sign-in returned account but no ID token")
                                attemptingSilentSignIn = false
                            }
                        } catch (e: Exception) {
                            Log.d("FCM", "Silent sign-in failed - user needs to sign in manually: ${e.message}")
                            attemptingSilentSignIn = false
                            // Silent sign-in failed - user will need to sign in manually
                            // They'll see the authentication screen
                        }
                    }
                }
                
                // Reset attemptingSilentSignIn when authentication completes
                LaunchedEffect(authUiState.isAuthenticated, authUiState.isLoading) {
                    if (authUiState.isAuthenticated) {
                        attemptingSilentSignIn = false
                    } else if (!authUiState.isLoading && !hasNotificationIntent) {
                        // Only reset if we're not waiting for silent sign-in
                        attemptingSilentSignIn = false
                    }
                }
                
                // Watch for route changes and ensure we're on the correct screen when notification intent exists
                LaunchedEffect(navController.currentDestination?.route, authUiState.isAuthenticated, authUiState.userId) {
                    val navigateTo = intent.getStringExtra("navigateTo")
                    val groupId = intent.getStringExtra("groupId")
                    val currentRoute = navController.currentDestination?.route
                    
                    if (navigateTo == "groupDetails" && groupId != null && authUiState.isAuthenticated && authUiState.userId != null) {
                        val expectedRoute = Screen.GroupDetails(groupId).createRoute(groupId)
                        
                        // If we're on GroupList or any other route when we should be on GroupDetails, navigate immediately
                        if (currentRoute != expectedRoute && currentRoute != null) {
                            Log.d("FCM", "Route mismatch detected - current: $currentRoute, expected: $expectedRoute. Navigating...")
                            try {
                                kotlinx.coroutines.delay(100) // Brief delay to avoid rapid navigation
                                navController.navigate(expectedRoute) {
                                    popUpTo(0) { inclusive = true }
                                    launchSingleTop = true
                                    restoreState = false
                                }
                                Log.d("FCM", "Corrected navigation to Group Details: $groupId")
                                handledNotificationNavigation = true
                            } catch (e: Exception) {
                                Log.e("FCM", "Failed to correct navigation: ${e.message}", e)
                            }
                        } else if (currentRoute == expectedRoute) {
                            // We're on the correct route
                            if (!handledNotificationNavigation) {
                                handledNotificationNavigation = true
                                intent.removeExtra("navigateTo")
                                intent.removeExtra("groupId")
                                Log.d("FCM", "Confirmed on Group Details: $groupId")
                            }
                        }
                    } else if (navigateTo == "groupList" && authUiState.isAuthenticated && authUiState.userId != null) {
                        val expectedRoute = Screen.GroupList.route
                        
                        // If we're not on GroupList, navigate immediately
                        if (currentRoute != expectedRoute && currentRoute != null) {
                            Log.d("FCM", "Route mismatch detected - current: $currentRoute, expected: $expectedRoute. Navigating...")
                            try {
                                kotlinx.coroutines.delay(100) // Brief delay to avoid rapid navigation
                                navController.navigate(expectedRoute) {
                                    popUpTo(0) { inclusive = true }
                                    launchSingleTop = true
                                    restoreState = false
                                }
                                Log.d("FCM", "Corrected navigation to Group List")
                                handledNotificationNavigation = true
                                // Refresh groups after navigation
                                authUiState.userId?.let { userId ->
                                    kotlinx.coroutines.delay(200)
                                    groupListViewModel.refreshGroups(userId)
                                }
                            } catch (e: Exception) {
                                Log.e("FCM", "Failed to correct navigation: ${e.message}", e)
                            }
                        } else if (currentRoute == expectedRoute) {
                            // We're on the correct route, refresh groups
                            if (!handledNotificationNavigation) {
                                handledNotificationNavigation = true
                                authUiState.userId?.let { userId ->
                                    groupListViewModel.refreshGroups(userId)
                                }
                                intent.removeExtra("navigateTo")
                                intent.removeExtra("groupId")
                                Log.d("FCM", "Confirmed on Group List - refreshing groups")
                            }
                        }
                    }
                }
                
                // Handle initial notification navigation
                LaunchedEffect(navController, authUiState.isAuthenticated, authUiState.userId) {
                    val navigateTo = intent.getStringExtra("navigateTo")
                    val groupId = intent.getStringExtra("groupId")
                    
                    if (navigateTo == "groupDetails" && groupId != null && !handledNotificationNavigation) {
                        Log.d("FCM", "Initial notification navigation - groupId: $groupId, authenticated: ${authUiState.isAuthenticated}")
                        
                        if (authUiState.isAuthenticated && authUiState.userId != null) {
                            // Wait for NavHost to initialize
                            kotlinx.coroutines.delay(700)
                            
                            val expectedRoute = Screen.GroupDetails(groupId).createRoute(groupId)
                            val currentRoute = navController.currentDestination?.route
                            
                            Log.d("FCM", "Initial navigation check - currentRoute: $currentRoute, expectedRoute: $expectedRoute")
                            
                            if (currentRoute != expectedRoute) {
                                try {
                                    navController.navigate(expectedRoute) {
                                        popUpTo(0) { inclusive = true }
                                        launchSingleTop = true
                                        restoreState = false
                                    }
                                    Log.d("FCM", "Initial navigation to Group Details: $groupId")
                                    handledNotificationNavigation = true
                                    kotlinx.coroutines.delay(100)
                                    intent.removeExtra("navigateTo")
                                    intent.removeExtra("groupId")
                                } catch (e: Exception) {
                                    Log.e("FCM", "Failed initial navigation: ${e.message}", e)
                                }
                            } else {
                                handledNotificationNavigation = true
                                intent.removeExtra("navigateTo")
                                intent.removeExtra("groupId")
                            }
                        }
                    } else if (navigateTo == "groupList" && !handledNotificationNavigation) {
                        Log.d("FCM", "Initial notification navigation - groupList, authenticated: ${authUiState.isAuthenticated}")
                        
                        if (authUiState.isAuthenticated && authUiState.userId != null) {
                            // Wait for NavHost to initialize
                            kotlinx.coroutines.delay(700)
                            
                            val expectedRoute = Screen.GroupList.route
                            val currentRoute = navController.currentDestination?.route
                            
                            Log.d("FCM", "Initial navigation check - currentRoute: $currentRoute, expectedRoute: $expectedRoute")
                            
                            if (currentRoute != expectedRoute) {
                                try {
                                    navController.navigate(expectedRoute) {
                                        popUpTo(0) { inclusive = true }
                                        launchSingleTop = true
                                        restoreState = false
                                    }
                                    Log.d("FCM", "Initial navigation to Group List")
                                    handledNotificationNavigation = true
                                    // Refresh groups after navigation
                                    kotlinx.coroutines.delay(200)
                                    authUiState.userId?.let { userId ->
                                        groupListViewModel.refreshGroups(userId)
                                    }
                                    kotlinx.coroutines.delay(100)
                                    intent.removeExtra("navigateTo")
                                    intent.removeExtra("groupId")
                                } catch (e: Exception) {
                                    Log.e("FCM", "Failed initial navigation: ${e.message}", e)
                                }
                            } else {
                                // Already on GroupList, refresh groups
                                handledNotificationNavigation = true
                                authUiState.userId?.let { userId ->
                                    groupListViewModel.refreshGroups(userId)
                                }
                                intent.removeExtra("navigateTo")
                                intent.removeExtra("groupId")
                            }
                        }
                    }
                }
                

                // Handle successful sign out - show confirmation and close app
                LaunchedEffect(authUiState.signOutSuccess) {
                    if (authUiState.signOutSuccess) {
                        // Show confirmation message
                        Toast.makeText(this@MainActivity, "Successfully signed out", Toast.LENGTH_SHORT).show()
                        
                        // Wait a bit for the toast to be visible, then close the app
                        kotlinx.coroutines.delay(1500)
                        
                        // Close the app
                        finishAffinity()
                    }
                }

                LaunchedEffect(authUiState.isAuthenticated, attemptingSilentSignIn, hasNotificationIntent) {
                    // IMPORTANT: If we have a notification intent and are attempting silent sign-in, do NOT navigate here
                    // Let the notification navigation LaunchedEffects handle it
                    if (hasNotificationIntent && attemptingSilentSignIn) {
                        Log.d("FCM", "Skipping default navigation - notification intent detected and attempting silent sign-in: $navigateTo")
                        return@LaunchedEffect
                    }
                    
                    // IMPORTANT: If we have a notification intent, do NOT navigate here
                    // Let the notification navigation LaunchedEffects handle it
                    if (hasNotificationIntent) {
                        Log.d("FCM", "Skipping default navigation - notification intent detected: $navigateTo")
                        return@LaunchedEffect
                    }
                    
                    if (authUiState.isAuthenticated) {
                        // Only navigate to GroupList if we're not handling a notification
                        if (!handledNotificationNavigation) {
                            // Only navigate if we're not already on the correct screen
                            val currentRoute = navController.currentDestination?.route
                            val isOnGroupDetails = currentRoute?.startsWith("group_details/") == true
                            if (currentRoute != Screen.GroupList.route && 
                                currentRoute != Screen.GroupDetails("{groupId}").route &&
                                !isOnGroupDetails) {
                                navController.navigate(Screen.GroupList.route) {
                                    popUpTo(Screen.Authentication.route) { inclusive = true }
                                }
                            }
                        }
                        // Register FCM token after successful sign-in
                        authUiState.userId?.let { userId ->
                            // Store userId in SharedPreferences for notification service access
                            val prefs = getSharedPreferences("movieswipe_prefs", Context.MODE_PRIVATE)
                            prefs.edit().putString("current_user_id", userId).apply()
                            Log.d("FCM", "Stored userId in SharedPreferences: $userId")
                            
                            registerFcmToken(userId)
                        }
                    } else if (!authUiState.isLoading && !attemptingSilentSignIn && !authUiState.signOutSuccess) {
                        // Only navigate to Authentication if we're not already there, not attempting silent sign-in, and not signing out successfully
                        // (when sign out succeeds, we close the app instead of navigating)
                        val currentRoute = navController.currentDestination?.route
                        if (currentRoute != Screen.Authentication.route) {
                            navController.navigate(Screen.Authentication.route) {
                                popUpTo(Screen.GroupList.route) { inclusive = true }
                            }
                        }
                    }
                }

                LaunchedEffect(createGroupUiState.createdGroupId) {
                    createGroupUiState.createdGroupId?.let { groupId ->
                        navController.navigate(Screen.GroupDetails(groupId).createRoute(groupId)) {
                            popUpTo(Screen.GroupList.route) { inclusive = false }
                        }
                        // Reset the createdGroupId to prevent re-navigation
                        createGroupViewModel.resetState()
                    }
                }

                LaunchedEffect(joinGroupUiState.joinedGroupId) {
                    joinGroupUiState.joinedGroupId?.let { groupId ->
                        val showMessage = joinGroupUiState.alreadyMemberMessage != null
                        val route = Screen.GroupDetails(groupId).createRoute(groupId)
                        
                        navController.navigate(route) {
                            popUpTo(Screen.GroupList.route) { inclusive = false }
                        }
                        
                        // Wait for navigation to complete, then set savedStateHandle
                        kotlinx.coroutines.delay(100)
                        navController.currentBackStackEntry?.savedStateHandle?.let { handle ->
                            if (showMessage) {
                                handle["showAlreadyMemberMessage"] = true
                            }
                        }
                        
                        // Reset the joinedGroupId to prevent re-navigation
                        joinGroupViewModel.resetState()
                    }
                }

                Scaffold(modifier = Modifier.fillMaxSize()) { paddingValues ->
                    // Determine start destination
                    // IMPORTANT: If we have a notification intent, ALWAYS start at the correct screen
                    // This prevents showing the wrong screen even briefly
                    val hasGroupDetailsIntent = navigateTo == "groupDetails" && notificationGroupId != null
                    val hasGroupListIntent = navigateTo == "groupList"
                    
                    val startDestination = when {
                        hasGroupDetailsIntent && notificationGroupId != null -> {
                            // Always start at GroupDetails when groupDetails notification intent exists
                            // Even if not authenticated yet - silent sign-in will handle authentication
                            Screen.GroupDetails(notificationGroupId).createRoute(notificationGroupId)
                        }
                        hasGroupListIntent -> {
                            // Always start at GroupList when groupList notification intent exists
                            // Even if not authenticated yet - silent sign-in will handle authentication
                            Screen.GroupList.route
                        }
                        authUiState.isAuthenticated -> {
                            Screen.GroupList.route
                        }
                        else -> {
                            Screen.Authentication.route
                        }
                    }
                    
                    Log.d("FCM", "Scaffold - startDestination: $startDestination, navigateTo: $navigateTo, hasGroupDetailsIntent: $hasGroupDetailsIntent, hasGroupListIntent: $hasGroupListIntent, groupId: $notificationGroupId, attemptingSilentSignIn: $attemptingSilentSignIn")
                    
                    AppNavigation(
                        navController = navController,
                        startDestination = startDestination,
                        onSignInClick = {
                            scope.launch {
                                startGoogleSignIn()
                            }
                        },
                        onSignOutClick = {
                            scope.launch {
                                handleSignOut(authViewModel)
                            }
                        },
                        onCreateGroupClick = {
                            createGroupViewModel.openGroupNameDialog()
                        },
                        createGroupViewModel = createGroupViewModel,
                        createGroupUiState = createGroupUiState,
                        groupListViewModel = groupListViewModel,
                        groupListUiState = groupListUiState,
                        groupDetailViewModel = groupDetailViewModel,
                        joinGroupViewModel = joinGroupViewModel,
                        joinGroupUiState = joinGroupUiState,
                        votingViewModel = votingViewModel,
                        userId = authUiState.userId,
                        isLoading = authUiState.isLoading,
                        isSigningOut = authUiState.isLoading && authUiState.isAuthenticated,
                        errorMessage = if (!authUiState.isAuthenticated) authUiState.errorMessage else null,
                        signOutError = if (authUiState.isAuthenticated) authUiState.errorMessage else null,
                        paddingValues = paddingValues
                    )
                }
            }
        }
    }

    private fun startGoogleSignIn() {
        val signInIntent = googleSignInClient.signInIntent
        googleSignInLauncher.launch(signInIntent)
    }

    private fun handleGoogleSignInResult(task: Task<GoogleSignInAccount>) {
        val authViewModel = currentViewModel ?: return
        try {
            val account = task.getResult(ApiException::class.java)
            val idToken = account?.idToken
            if (idToken != null) {
                authViewModel.signIn(idToken)
            } else {
                authViewModel.signIn("")
            }
        } catch (e: ApiException) {
            authViewModel.signIn("")
        }
    }

    private suspend fun handleSignOut(authViewModel: AuthenticationViewModel) {
        try {
            val account = GoogleSignIn.getLastSignedInAccount(this)
            val idToken = account?.idToken
            authViewModel.signOut(idToken)
            // Sign out from Google client after backend sign out completes
            // This is done in a try-catch to handle cases where it's already signed out
            try {
                // Clear userId from SharedPreferences on sign out
                val prefs = getSharedPreferences("movieswipe_prefs", Context.MODE_PRIVATE)
                prefs.edit().remove("current_user_id").apply()
                Log.d("FCM", "Cleared userId from SharedPreferences on sign out")
                
                googleSignInClient.signOut()
            } catch (e: Exception) {
                // Ignore errors from Google sign out as backend sign out is complete
            }
        } catch (e: Exception) {
            // If we can't get the account, try sign out with stored token
            // Clear userId from SharedPreferences on sign out
            val prefs = getSharedPreferences("movieswipe_prefs", Context.MODE_PRIVATE)
            prefs.edit().remove("current_user_id").apply()
            Log.d("FCM", "Cleared userId from SharedPreferences on sign out (fallback)")
            
            authViewModel.signOut(null)
        }
    }
    
    private fun handleNotificationIntent(intent: Intent?) {
        intent?.let {
            val navigateTo = it.getStringExtra("navigateTo")
            val groupId = it.getStringExtra("groupId")
            
            if (navigateTo != null || groupId != null) {
                Log.d("FCM", "Notification intent detected - navigateTo: $navigateTo, groupId: $groupId")
                // Navigation will be handled in the Compose code via LaunchedEffect
            }
        }
    }
    

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)
            
            // Check if channel already exists
            val existingChannel = notificationManager.getNotificationChannel("movieswipe_notifications")
            if (existingChannel != null) {
                Log.d("FCM", "Notification channel already exists")
                return
            }
            
            val channel = NotificationChannel(
                "movieswipe_notifications",
                "MovieSwipe Notifications",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for voting sessions and group updates"
                enableLights(true)
                enableVibration(true)
                setShowBadge(true)
            }
            
            notificationManager.createNotificationChannel(channel)
            Log.d("FCM", "Notification channel created successfully")
        }
    }
    
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) 
                != PackageManager.PERMISSION_GRANTED) {
                Log.d("FCM", "Requesting notification permission")
                requestNotificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            } else {
                Log.d("FCM", "Notification permission already granted")
            }
        }
    }
    
    private fun registerFcmToken(userId: String) {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w("FCM", "Fetching FCM registration token failed", task.exception)
                return@addOnCompleteListener
            }

            val token = task.result
            Log.d("FCM", "FCM Registration Token: $token")

            if (token != null && token.isNotBlank()) {
                lifecycleScope.launch {
                    try {
                        userRepository.registerFcmToken(userId, token)
                        Log.d("FCM", "FCM token registered successfully")
                    } catch (e: Exception) {
                        Log.e("FCM", "Failed to register FCM token", e)
                    }
                }
            }
        }
    }
}