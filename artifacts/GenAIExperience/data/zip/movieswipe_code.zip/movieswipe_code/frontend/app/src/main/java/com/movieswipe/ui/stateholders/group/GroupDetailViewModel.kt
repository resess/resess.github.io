// Group feature state holders - Group details

package com.movieswipe.ui.stateholders.group

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.movieswipe.data.datasources.votinggroup.StartVotingSessionException
import com.movieswipe.data.repositories.movie.MovieRepository
import com.movieswipe.data.repositories.votinggroup.VotingGroupRepository
import com.movieswipe.ui.ui_elements.group.GroupDetailsData
import com.movieswipe.ui.ui_elements.group.GroupMember
import com.movieswipe.ui.ui_elements.group.SelectedMovie
import com.movieswipe.ui.ui_elements.group.UserVotingProgress
import com.movieswipe.ui.ui_elements.group.VotingSessionData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class GroupDetailUiState(
    val groupDetails: GroupDetailsData? = null,
    val isLoading: Boolean = false,
    val isLoadingGenres: Boolean = false,
    val errorMessage: String? = null,
    val showErrorDialog: Boolean = false,
    val showDeleteConfirmationDialog: Boolean = false,
    val showDeleteSuccessDialog: Boolean = false,
    val deleteSuccessMessage: String? = null,
    val showLeaveConfirmationDialog: Boolean = false,
    val showLeaveSuccessDialog: Boolean = false,
    val leaveSuccessMessage: String? = null,
    val showEndVotingSessionConfirmationDialog: Boolean = false,
    val showEndVotingSessionSuccessDialog: Boolean = false,
    val endVotingSessionSuccessMessage: String? = null,
    val selectedMovieAfterEnding: SelectedMovie? = null,
    val isDeletingGroup: Boolean = false,
    val isLeavingGroup: Boolean = false,
    val isStartingVotingSession: Boolean = false,
    val isEndingVotingSession: Boolean = false,
    val showAlreadyMemberSnackbar: Boolean = false,
    val genres: Map<Int, String> = emptyMap()
)

class GroupDetailViewModel(
    private val votingGroupRepository: VotingGroupRepository,
    private val movieRepository: MovieRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(GroupDetailUiState())
    val uiState: StateFlow<GroupDetailUiState> = _uiState.asStateFlow()

    fun loadGenres() {
        if (_uiState.value.isLoadingGenres || _uiState.value.genres.isNotEmpty()) {
            return
        }

        _uiState.value = _uiState.value.copy(
            isLoadingGenres = true
        )

        viewModelScope.launch {
            try {
                val genresList = movieRepository.getGenres()
                val genresMap = genresList.associate { genre -> genre.id to genre.name }
                _uiState.value = _uiState.value.copy(
                    genres = genresMap,
                    isLoadingGenres = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoadingGenres = false
                )
            }
        }
    }

    fun loadGroupDetails(groupId: String, userId: String) {
        if (_uiState.value.isLoading) {
            return
        }

        _uiState.value = _uiState.value.copy(
            isLoading = true,
            errorMessage = null,
            showErrorDialog = false
        )

        viewModelScope.launch {
            try {
                val groupDetailsResponse = votingGroupRepository.getGroupDetails(groupId, userId)
                try {
                    val groupDetails = mapToGroupDetailsData(groupDetailsResponse)
                    _uiState.value = _uiState.value.copy(
                        groupDetails = groupDetails,
                        isLoading = false,
                        errorMessage = null,
                        showErrorDialog = false
                    )
                } catch (mappingException: Exception) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = "Failed to process group data. ${mappingException.message}",
                        showErrorDialog = true
                    )
                }
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                        "This group has been deleted."
                    }
                    e.message?.contains("You are no longer a member", ignoreCase = true) == true -> {
                        "You are no longer a member of this group."
                    }
                    e.message?.contains("Failed to load group information", ignoreCase = true) == true -> {
                        "Failed to load group information."
                    }
                    else -> {
                        "Failed to load group information."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun retryLoadGroupDetails(groupId: String, userId: String) {
        loadGroupDetails(groupId, userId)
    }

    fun refreshGroupDetails(groupId: String, userId: String) {
        // Force refresh by clearing loading state check
        _uiState.value = _uiState.value.copy(
            isLoading = true,
            errorMessage = null,
            showErrorDialog = false
        )

        viewModelScope.launch {
            try {
                val groupDetailsResponse = votingGroupRepository.getGroupDetails(groupId, userId)
                try {
                    val groupDetails = mapToGroupDetailsData(groupDetailsResponse)
                    _uiState.value = _uiState.value.copy(
                        groupDetails = groupDetails,
                        isLoading = false,
                        errorMessage = null,
                        showErrorDialog = false
                    )
                } catch (mappingException: Exception) {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = "Failed to process group data. ${mappingException.message}",
                        showErrorDialog = true
                    )
                }
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                        "This group has been deleted."
                    }
                    e.message?.contains("You are no longer a member", ignoreCase = true) == true -> {
                        "You are no longer a member of this group."
                    }
                    e.message?.contains("Failed to load group information", ignoreCase = true) == true -> {
                        "Failed to load group information."
                    }
                    else -> {
                        "Failed to load group information."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun silentlyRefreshGroupDetails(groupId: String, userId: String) {
        // Silent refresh without showing loading indicator
        viewModelScope.launch {
            try {
                val groupDetailsResponse = votingGroupRepository.getGroupDetails(groupId, userId)
                try {
                    val groupDetails = mapToGroupDetailsData(groupDetailsResponse)
                    // Update state while preserving isLoading and other UI states
                    _uiState.value = _uiState.value.copy(
                        groupDetails = groupDetails,
                        // Preserve isLoading state - don't change it for silent update
                        // Preserve error states - only clear if there was an error before
                        errorMessage = null,
                        showErrorDialog = false
                    )
                    android.util.Log.d("GroupDetailViewModel", "Silently refreshed group details for groupId: $groupId")
                } catch (mappingException: Exception) {
                    // Silently fail - don't show error dialog for background updates
                    android.util.Log.e("GroupDetailViewModel", "Error mapping group details during silent refresh", mappingException)
                }
            } catch (e: Exception) {
                // Silently fail - don't show error dialog for background updates
                android.util.Log.e("GroupDetailViewModel", "Error during silent refresh for groupId: $groupId", e)
            }
        }
    }

    fun dismissErrorDialog() {
        _uiState.value = _uiState.value.copy(
            showErrorDialog = false
        )
    }

    fun showDeleteConfirmationDialog() {
        _uiState.value = _uiState.value.copy(
            showDeleteConfirmationDialog = true
        )
    }

    fun dismissDeleteConfirmationDialog() {
        _uiState.value = _uiState.value.copy(
            showDeleteConfirmationDialog = false
        )
    }

    fun dismissDeleteSuccessDialog() {
        _uiState.value = _uiState.value.copy(
            showDeleteSuccessDialog = false,
            deleteSuccessMessage = null
        )
    }

    fun showLeaveConfirmationDialog() {
        _uiState.value = _uiState.value.copy(
            showLeaveConfirmationDialog = true
        )
    }

    fun dismissLeaveConfirmationDialog() {
        _uiState.value = _uiState.value.copy(
            showLeaveConfirmationDialog = false
        )
    }

    fun dismissLeaveSuccessDialog() {
        _uiState.value = _uiState.value.copy(
            showLeaveSuccessDialog = false,
            leaveSuccessMessage = null
        )
    }

    fun deleteGroup(groupId: String, userId: String) {
        _uiState.value = _uiState.value.copy(
            isDeletingGroup = true
        )

        viewModelScope.launch {
            try {
                val result = votingGroupRepository.deleteGroup(groupId, userId)
                val successMessage = result.message ?: "Group deleted successfully."
                
                _uiState.value = _uiState.value.copy(
                    isDeletingGroup = false,
                    showDeleteConfirmationDialog = false,
                    showDeleteSuccessDialog = true,
                    deleteSuccessMessage = successMessage
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                        "This group has been deleted."
                    }
                    e.message?.contains("Only the group owner", ignoreCase = true) == true -> {
                        "Only the group owner can delete the group."
                    }
                    e.message?.contains("Failed to delete group", ignoreCase = true) == true -> {
                        "Failed to delete group. Please try again."
                    }
                    else -> {
                        "Failed to delete group. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isDeletingGroup = false,
                    showDeleteConfirmationDialog = false,
                    errorMessage = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun leaveGroup(groupId: String, userId: String) {
        _uiState.value = _uiState.value.copy(
            isLeavingGroup = true
        )

        viewModelScope.launch {
            try {
                val result = votingGroupRepository.leaveGroup(groupId, userId)
                val successMessage = result.message ?: "You have successfully left the group."
                
                _uiState.value = _uiState.value.copy(
                    isLeavingGroup = false,
                    showLeaveConfirmationDialog = false,
                    showLeaveSuccessDialog = true,
                    leaveSuccessMessage = successMessage
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                        "This group has been deleted."
                    }
                    e.message?.contains("Group owners cannot leave", ignoreCase = true) == true -> {
                        "Group owners cannot leave the group. Please delete the group instead."
                    }
                    e.message?.contains("You are not a member", ignoreCase = true) == true -> {
                        "You are not a member of this group."
                    }
                    e.message?.contains("User not found", ignoreCase = true) == true -> {
                        "User not found."
                    }
                    e.message?.contains("Failed to leave group", ignoreCase = true) == true -> {
                        "Failed to leave group. Please try again."
                    }
                    else -> {
                        "Failed to leave group. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLeavingGroup = false,
                    showLeaveConfirmationDialog = false,
                    errorMessage = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun startVotingSession(groupId: String, userId: String) {
        if (_uiState.value.isStartingVotingSession) {
            return
        }

        _uiState.value = _uiState.value.copy(
            isStartingVotingSession = true,
            errorMessage = null,
            showErrorDialog = false
        )

        viewModelScope.launch {
            try {
                val groupDetailsResponse = votingGroupRepository.startVotingSession(groupId, userId)
                val groupDetails = mapToGroupDetailsData(groupDetailsResponse)
                
                _uiState.value = _uiState.value.copy(
                    isStartingVotingSession = false,
                    groupDetails = groupDetails,
                    errorMessage = null,
                    showErrorDialog = false
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e is StartVotingSessionException -> {
                        e.groupDetails?.let { groupDetails ->
                            val mappedGroupDetails = mapToGroupDetailsData(groupDetails)
                            _uiState.value = _uiState.value.copy(
                                isStartingVotingSession = false,
                                groupDetails = mappedGroupDetails,
                                errorMessage = e.message ?: "Failed to load movies. Please try again.",
                                showErrorDialog = true
                            )
                            return@launch
                        }
                        e.message ?: "Failed to load movies. Please try again."
                    }
                    e.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                        "This group has been deleted."
                    }
                    e.message?.contains("Only the group owner", ignoreCase = true) == true -> {
                        "Only the group owner can start a voting session."
                    }
                    e.message?.contains("A voting session is already in progress", ignoreCase = true) == true -> {
                        "A voting session is already in progress for this group."
                    }
                    e.message?.contains("Failed to load movies", ignoreCase = true) == true -> {
                        "Failed to load movies. Please try again."
                    }
                    e.message?.contains("Failed to start voting session", ignoreCase = true) == true -> {
                        "Failed to start voting session. Please try again."
                    }
                    else -> {
                        "Failed to start voting session. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isStartingVotingSession = false,
                    errorMessage = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun joinVotingSession(groupId: String, userId: String) {
        viewModelScope.launch {
            try {
                val groupDetailsResponse = votingGroupRepository.getGroupDetails(groupId, userId)
                val groupDetails = mapToGroupDetailsData(groupDetailsResponse)
                
                if (groupDetails.votingSession.state != "started") {
                    _uiState.value = _uiState.value.copy(
                        groupDetails = groupDetails,
                        errorMessage = "The voting session has ended.",
                        showErrorDialog = true
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        groupDetails = groupDetails,
                        errorMessage = null,
                        showErrorDialog = false
                    )
                }
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                        "This group has been deleted."
                    }
                    e.message?.contains("You are no longer a member", ignoreCase = true) == true -> {
                        "You are no longer a member of this group."
                    }
                    e.message?.contains("The voting session has ended", ignoreCase = true) == true -> {
                        "The voting session has ended."
                    }
                    else -> {
                        "Failed to join voting session. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    errorMessage = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun resumeVotingSession(groupId: String, userId: String) {
        viewModelScope.launch {
            try {
                val groupDetailsResponse = votingGroupRepository.getGroupDetails(groupId, userId)
                val groupDetails = mapToGroupDetailsData(groupDetailsResponse)
                
                if (groupDetails.votingSession.state != "started") {
                    _uiState.value = _uiState.value.copy(
                        groupDetails = groupDetails,
                        errorMessage = "The voting session has ended.",
                        showErrorDialog = true
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        groupDetails = groupDetails,
                        errorMessage = null,
                        showErrorDialog = false
                    )
                }
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                        "This group has been deleted."
                    }
                    e.message?.contains("You are no longer a member", ignoreCase = true) == true -> {
                        "You are no longer a member of this group."
                    }
                    e.message?.contains("The voting session has ended", ignoreCase = true) == true -> {
                        "The voting session has ended."
                    }
                    else -> {
                        "Failed to resume voting session. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    errorMessage = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    fun endVotingSession(groupId: String, userId: String) {
        if (_uiState.value.isEndingVotingSession) {
            return
        }

        _uiState.value = _uiState.value.copy(
            isEndingVotingSession = true,
            errorMessage = null,
            showErrorDialog = false
        )

        viewModelScope.launch {
            try {
                val groupDetailsResponse = votingGroupRepository.endVotingSession(groupId, userId)
                val groupDetails = mapToGroupDetailsData(groupDetailsResponse)
                
                val selectedMovie = groupDetails.votingSession.selectedMovie?.let { movie ->
                    SelectedMovie(
                        movieId = movie.movieId,
                        title = movie.title,
                        posterUrl = movie.posterUrl,
                        genres = movie.genres,
                        rating = movie.rating,
                        length = movie.length,
                        summary = movie.summary
                    )
                }
                
                val warningMessage = groupDetailsResponse.message
                
                _uiState.value = _uiState.value.copy(
                    isEndingVotingSession = false,
                    showEndVotingSessionConfirmationDialog = false,
                    groupDetails = groupDetails,
                    showEndVotingSessionSuccessDialog = true,
                    selectedMovieAfterEnding = selectedMovie,
                    endVotingSessionSuccessMessage = warningMessage
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("This group has been deleted", ignoreCase = true) == true -> {
                        "This group has been deleted."
                    }
                    e.message?.contains("Only the group owner", ignoreCase = true) == true -> {
                        "Only the group owner can end the voting session."
                    }
                    e.message?.contains("A voting session is not currently in progress", ignoreCase = true) == true -> {
                        "A voting session is not currently in progress for this group."
                    }
                    e.message?.contains("No movies available", ignoreCase = true) == true -> {
                        "No movies available in the voting session."
                    }
                    e.message?.contains("Failed to determine", ignoreCase = true) == true -> {
                        "Failed to determine the selected movie."
                    }
                    e.message?.contains("Failed to end", ignoreCase = true) == true -> {
                        "Failed to end the voting session. Please try again."
                    }
                    else -> {
                        "Failed to end the voting session. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isEndingVotingSession = false,
                    showEndVotingSessionConfirmationDialog = false,
                    errorMessage = errorMessage,
                    showErrorDialog = true
                )
            }
        }
    }

    private fun mapToGroupDetailsData(
        response: com.movieswipe.data.datasources.votinggroup.GroupDetails
    ): GroupDetailsData {
        val members = response.members?.map { member ->
            GroupMember(
                id = member.id,
                name = member.name,
                email = member.email,
                profilePictureUrl = member.profilePictureUrl
            )
        }

        val moviesToVoteOn = response.votingSession?.moviesToVoteOn?.map { movie ->
            SelectedMovie(
                movieId = movie.movieId,
                title = movie.title,
                posterUrl = movie.posterUrl,
                genres = movie.genres,
                rating = movie.rating,
                length = movie.length,
                summary = movie.summary
            )
        }

        val selectedMovie = response.votingSession?.selectedMovie?.let { movie ->
            SelectedMovie(
                movieId = movie.movieId,
                title = movie.title,
                posterUrl = movie.posterUrl,
                genres = movie.genres,
                rating = movie.rating,
                length = movie.length,
                summary = movie.summary
            )
        }

        val userVotingProgress = response.votingSession?.userVotingProgress?.let { progress ->
            UserVotingProgress(
                hasNotVoted = progress.hasNotVoted,
                hasVotedForSubset = progress.hasVotedForSubset,
                hasVotedForAll = progress.hasVotedForAll
            )
        } ?: UserVotingProgress(
            hasNotVoted = true,
            hasVotedForSubset = false,
            hasVotedForAll = false
        )

        val votingSession = VotingSessionData(
            state = response.votingSession?.state ?: "notStarted",
            userVotingProgress = userVotingProgress,
            moviesToVoteOn = moviesToVoteOn,
            selectedMovie = selectedMovie
        )

        return GroupDetailsData(
            id = response.id,
            name = response.name,
            role = response.role,
            invitationCode = response.invitationCode,
            members = members,
            votingSession = votingSession
        )
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(
            errorMessage = null,
            showErrorDialog = false
        )
    }

    fun resetState() {
        _uiState.value = GroupDetailUiState()
    }

    fun showAlreadyMemberMessage() {
        _uiState.value = _uiState.value.copy(
            showAlreadyMemberSnackbar = true
        )
    }

    fun dismissAlreadyMemberSnackbar() {
        _uiState.value = _uiState.value.copy(
            showAlreadyMemberSnackbar = false
        )
    }

    fun showEndVotingSessionConfirmationDialog() {
        _uiState.value = _uiState.value.copy(
            showEndVotingSessionConfirmationDialog = true
        )
    }

    fun dismissEndVotingSessionConfirmationDialog() {
        _uiState.value = _uiState.value.copy(
            showEndVotingSessionConfirmationDialog = false
        )
    }

    fun dismissEndVotingSessionSuccessDialog() {
        _uiState.value = _uiState.value.copy(
            showEndVotingSessionSuccessDialog = false,
            endVotingSessionSuccessMessage = null,
            selectedMovieAfterEnding = null
        )
    }
}
