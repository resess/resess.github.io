// Group feature state holders - Join group

package com.movieswipe.ui.stateholders.group

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.movieswipe.data.datasources.movie.Genre
import com.movieswipe.data.datasources.votinggroup.AlreadyMemberException
import com.movieswipe.data.repositories.movie.MovieRepository
import com.movieswipe.data.repositories.votinggroup.VotingGroupRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class JoinGroupUiState(
    val invitationCode: String = "",
    val showInvitationCodeDialog: Boolean = false,
    val showGenrePreferencesScreen: Boolean = false,
    val genres: List<Genre> = emptyList(),
    val selectedGenres: Set<Int> = emptySet(),
    val isLoadingValidateCode: Boolean = false,
    val isLoadingGenres: Boolean = false,
    val isLoadingJoin: Boolean = false,
    val invitationCodeError: String? = null,
    val genresError: String? = null,
    val joinGroupError: String? = null,
    val showRetryGenresDialog: Boolean = false,
    val userId: String? = null,
    val joinedGroupId: String? = null,
    val notificationWarning: String? = null,
    val alreadyMemberMessage: String? = null
)

class JoinGroupViewModel(
    private val votingGroupRepository: VotingGroupRepository,
    private val movieRepository: MovieRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(JoinGroupUiState())
    val uiState: StateFlow<JoinGroupUiState> = _uiState.asStateFlow()

    fun openInvitationCodeDialog() {
        _uiState.value = _uiState.value.copy(
            showInvitationCodeDialog = true,
            invitationCode = "",
            invitationCodeError = null,
            notificationWarning = null
        )
    }

    fun closeInvitationCodeDialog() {
        _uiState.value = _uiState.value.copy(
            showInvitationCodeDialog = false,
            invitationCode = "",
            invitationCodeError = null
        )
    }

    fun updateInvitationCode(code: String) {
        _uiState.value = _uiState.value.copy(
            invitationCode = code,
            invitationCodeError = null
        )
    }

    fun validateInvitationCode(userId: String) {
        val code = _uiState.value.invitationCode.trim()
        
        if (code.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                invitationCodeError = "Invalid invitation code. Please check the code and try again."
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoadingValidateCode = true,
                invitationCodeError = null
            )

            try {
                val result = votingGroupRepository.validateInvitationCode(code, userId)
                _uiState.value = _uiState.value.copy(
                    isLoadingValidateCode = false,
                    showInvitationCodeDialog = false,
                    showGenrePreferencesScreen = true,
                    invitationCode = code,
                    invitationCodeError = null,
                    genresError = null,
                    selectedGenres = emptySet(),
                    userId = userId
                )
                loadGroupGenres(code)
            } catch (e: Exception) {
                if (e is AlreadyMemberException) {
                    _uiState.value = _uiState.value.copy(
                        isLoadingValidateCode = false,
                        showInvitationCodeDialog = false,
                        invitationCode = "",
                        invitationCodeError = null,
                        joinedGroupId = e.groupId,
                        alreadyMemberMessage = "You are already a member of this group"
                    )
                } else {
                    val errorMessage = when {
                        e.message?.contains("Invalid invitation code", ignoreCase = true) == true -> {
                            "Invalid invitation code. Please check the code and try again."
                        }
                        e.message?.contains("already a member", ignoreCase = true) == true -> {
                            "You are already a member of this group"
                        }
                        else -> {
                            "Invalid invitation code. Please check the code and try again."
                        }
                    }
                    _uiState.value = _uiState.value.copy(
                        isLoadingValidateCode = false,
                        invitationCodeError = errorMessage
                    )
                }
            }
        }
    }

    fun loadGroupGenres(invitationCode: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoadingGenres = true,
                genresError = null,
                showRetryGenresDialog = false
            )

            try {
                val groupGenreIds = votingGroupRepository.getGroupGenres(invitationCode)
                val allGenres = movieRepository.getGenres()
                val availableGenres = allGenres.filter { genre ->
                    groupGenreIds.contains(genre.id)
                }
                _uiState.value = _uiState.value.copy(
                    genres = availableGenres,
                    isLoadingGenres = false,
                    genresError = null,
                    showRetryGenresDialog = false
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("Failed to load movie genres", ignoreCase = true) == true -> {
                        "Failed to load movie genres. Please try again."
                    }
                    e.message?.contains("Invalid invitation code", ignoreCase = true) == true -> {
                        "Invalid invitation code. Please check the code and try again."
                    }
                    else -> {
                        "Failed to load movie genres. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoadingGenres = false,
                    genresError = errorMessage,
                    showRetryGenresDialog = true
                )
            }
        }
    }

    fun retryLoadGenres() {
        val invitationCode = _uiState.value.invitationCode
        if (invitationCode.isNotEmpty()) {
            _uiState.value = _uiState.value.copy(
                genres = emptyList(),
                genresError = null,
                showRetryGenresDialog = false
            )
            loadGroupGenres(invitationCode)
        }
    }

    fun dismissRetryGenresDialog() {
        _uiState.value = _uiState.value.copy(
            showRetryGenresDialog = false
        )
    }

    fun toggleGenreSelection(genreId: Int) {
        val currentSelected = _uiState.value.selectedGenres.toMutableSet()
        if (currentSelected.contains(genreId)) {
            currentSelected.remove(genreId)
        } else {
            currentSelected.add(genreId)
        }
        _uiState.value = _uiState.value.copy(
            selectedGenres = currentSelected,
            joinGroupError = null
        )
    }

    fun goBackToInvitationCodeDialog() {
        _uiState.value = _uiState.value.copy(
            showGenrePreferencesScreen = false,
            showInvitationCodeDialog = true,
            genres = emptyList(),
            selectedGenres = emptySet(),
            joinGroupError = null,
            genresError = null
        )
    }

    fun joinGroup(userId: String) {
        if (_uiState.value.selectedGenres.isEmpty()) {
            _uiState.value = _uiState.value.copy(
                joinGroupError = "Genre selection is required. Please choose at least one preferred movie genre."
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isLoadingJoin = true,
                joinGroupError = null,
                notificationWarning = null
            )

            try {
                val invitationCode = _uiState.value.invitationCode
                val genreList = _uiState.value.selectedGenres.toList()
                val result = votingGroupRepository.joinGroup(
                    invitationCode = invitationCode,
                    userId = userId,
                    genrePreferences = genreList
                )

                val notificationWarningMessage = if (result.message?.contains("could not be notified", ignoreCase = true) == true) {
                    "You joined the group successfully but the owner could not be notified. You might want to contact them directly."
                } else {
                    null
                }

                _uiState.value = _uiState.value.copy(
                    isLoadingJoin = false,
                    showGenrePreferencesScreen = false,
                    invitationCode = "",
                    selectedGenres = emptySet(),
                    genres = emptyList(),
                    joinGroupError = null,
                    joinedGroupId = result.groupId,
                    notificationWarning = notificationWarningMessage
                )
            } catch (e: Exception) {
                if (e is AlreadyMemberException) {
                    _uiState.value = _uiState.value.copy(
                        isLoadingJoin = false,
                        showGenrePreferencesScreen = false,
                        invitationCode = "",
                        selectedGenres = emptySet(),
                        genres = emptyList(),
                        joinGroupError = null,
                        joinedGroupId = e.groupId,
                        alreadyMemberMessage = "You are already a member of this group"
                    )
                } else {
                    val errorMessage = when {
                        e.message?.contains("Invalid invitation code", ignoreCase = true) == true -> {
                            "Invalid invitation code. Please check the code and try again."
                        }
                        e.message?.contains("already a member", ignoreCase = true) == true -> {
                            "You are already a member of this group"
                        }
                        e.message?.contains("Genre selection is required", ignoreCase = true) == true -> {
                            "Genre selection is required. Please choose at least one preferred movie genre."
                        }
                        e.message?.contains("Invalid genre selection", ignoreCase = true) == true -> {
                            "Invalid genre selection. Please choose from the available genres."
                        }
                        e.message?.contains("Failed to join group", ignoreCase = true) == true -> {
                            "Failed to join group. Please try again."
                        }
                        else -> {
                            "Failed to join group. Please try again."
                        }
                    }
                    _uiState.value = _uiState.value.copy(
                        isLoadingJoin = false,
                        joinGroupError = errorMessage
                    )
                }
            }
        }
    }

    fun resetState() {
        _uiState.value = JoinGroupUiState()
    }

    fun clearInvitationCodeError() {
        _uiState.value = _uiState.value.copy(invitationCodeError = null)
    }

    fun clearGenresError() {
        _uiState.value = _uiState.value.copy(genresError = null)
    }

    fun clearJoinGroupError() {
        _uiState.value = _uiState.value.copy(joinGroupError = null)
    }

    fun clearNotificationWarning() {
        _uiState.value = _uiState.value.copy(notificationWarning = null)
    }
}

