// Group feature UI elements - Group details

package com.movieswipe.ui.ui_elements.group

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest

data class GroupMember(
    val id: String,
    val name: String,
    val email: String,
    val profilePictureUrl: String? = null
)

data class SelectedMovie(
    val movieId: Int,
    val title: String,
    val posterUrl: String? = null,
    val genres: List<Int>,
    val rating: Double,
    val length: Int,
    val summary: String
)

data class GroupDetailsData(
    val id: String,
    val name: String,
    val role: String, // "owner" or "member"
    val invitationCode: String? = null,
    val members: List<GroupMember>? = null,
    val votingSession: VotingSessionData
)

data class VotingSessionData(
    val state: String, // "notStarted", "started", "ended"
    val userVotingProgress: UserVotingProgress,
    val moviesToVoteOn: List<SelectedMovie>? = null,
    val selectedMovie: SelectedMovie? = null
)

data class UserVotingProgress(
    val hasNotVoted: Boolean,
    val hasVotedForSubset: Boolean,
    val hasVotedForAll: Boolean
)

@Composable
fun GroupDetailScreen(
    groupDetails: GroupDetailsData?,
    genres: Map<Int, String> = emptyMap(),
    isLoading: Boolean = false,
    errorMessage: String? = null,
    showErrorDialog: Boolean = false,
    showDeleteConfirmationDialog: Boolean = false,
    showDeleteSuccessDialog: Boolean = false,
    deleteSuccessMessage: String? = null,
    showLeaveConfirmationDialog: Boolean = false,
    showLeaveSuccessDialog: Boolean = false,
    leaveSuccessMessage: String? = null,
    showEndVotingSessionConfirmationDialog: Boolean = false,
    showEndVotingSessionSuccessDialog: Boolean = false,
    endVotingSessionSuccessMessage: String? = null,
    selectedMovieAfterEnding: SelectedMovie? = null,
    onRetryClick: () -> Unit,
    onDismissErrorDialog: () -> Unit,
    onBackClick: () -> Unit,
    onStartVotingSessionClick: () -> Unit,
    onJoinVotingSessionClick: () -> Unit,
    onResumeVotingSessionClick: () -> Unit,
    onEndVotingSessionClick: () -> Unit,
    onConfirmEndVotingSessionClick: () -> Unit,
    onDismissEndVotingSessionConfirmationDialog: () -> Unit,
    onDismissEndVotingSessionSuccessDialog: () -> Unit,
    onDeleteGroupClick: () -> Unit,
    onConfirmDeleteGroupClick: () -> Unit,
    onDismissDeleteConfirmationDialog: () -> Unit,
    onDismissDeleteSuccessDialog: () -> Unit,
    onLeaveGroupClick: () -> Unit,
    onConfirmLeaveGroupClick: () -> Unit,
    onDismissLeaveConfirmationDialog: () -> Unit,
    onDismissLeaveSuccessDialog: () -> Unit,
    isDeletingGroup: Boolean = false,
    isLeavingGroup: Boolean = false,
    isStartingVotingSession: Boolean = false,
    isEndingVotingSession: Boolean = false,
    showAlreadyMemberSnackbar: Boolean = false,
    onDismissAlreadyMemberSnackbar: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val snackbarHostState = remember { SnackbarHostState() }
    
    LaunchedEffect(showAlreadyMemberSnackbar) {
        if (showAlreadyMemberSnackbar) {
            snackbarHostState.showSnackbar("You are already a member of this group")
            onDismissAlreadyMemberSnackbar()
        }
    }
    
    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Scaffold(
            snackbarHost = {
                SnackbarHost(hostState = snackbarHostState)
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when {
                    isLoading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                CircularProgressIndicator()
                                Text(
                                    text = "Loading group details...",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    errorMessage != null && groupDetails == null -> {
                        ErrorState(
                            errorMessage = errorMessage,
                            onRetryClick = onRetryClick,
                            onBackClick = onBackClick
                        )
                    }
                    groupDetails != null -> {
                        GroupDetailsContent(
                            groupDetails = groupDetails,
                            genres = genres,
                            onBackClick = onBackClick,
                            onStartVotingSessionClick = onStartVotingSessionClick,
                            onJoinVotingSessionClick = onJoinVotingSessionClick,
                            onResumeVotingSessionClick = onResumeVotingSessionClick,
                            onEndVotingSessionClick = onEndVotingSessionClick,
                            onDeleteGroupClick = onDeleteGroupClick,
                            onLeaveGroupClick = onLeaveGroupClick,
                            isStartingVotingSession = isStartingVotingSession,
                            isEndingVotingSession = isEndingVotingSession
                        )
                    }
                }

                if (showErrorDialog) {
                    AlertDialog(
                        onDismissRequest = onDismissErrorDialog,
                        title = {
                            Text(text = "Error")
                        },
                        text = {
                            Text(text = errorMessage ?: "An error occurred")
                        },
                        confirmButton = {
                            TextButton(onClick = onDismissErrorDialog) {
                                Text("OK")
                            }
                        }
                    )
                }

                if (showDeleteConfirmationDialog) {
                    AlertDialog(
                        onDismissRequest = onDismissDeleteConfirmationDialog,
                        title = {
                            Text(text = "Delete Group")
                        },
                        text = {
                            Text(text = "Are you sure you want to permanently delete this group?")
                        },
                        confirmButton = {
                            Button(
                                onClick = onConfirmDeleteGroupClick,
                                enabled = !isDeletingGroup
                            ) {
                                if (isDeletingGroup) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                Text("Delete")
                            }
                        },
                        dismissButton = {
                            TextButton(
                                onClick = onDismissDeleteConfirmationDialog,
                                enabled = !isDeletingGroup
                            ) {
                                Text("Cancel")
                            }
                        }
                    )
                }

                if (showDeleteSuccessDialog) {
                    AlertDialog(
                        onDismissRequest = onDismissDeleteSuccessDialog,
                        title = {
                            Text(text = "Group Deleted")
                        },
                        text = {
                            Text(text = deleteSuccessMessage ?: "Group deleted successfully.")
                        },
                        confirmButton = {
                            TextButton(onClick = onDismissDeleteSuccessDialog) {
                                Text("OK")
                            }
                        }
                    )
                }

                if (showLeaveConfirmationDialog) {
                    AlertDialog(
                        onDismissRequest = onDismissLeaveConfirmationDialog,
                        title = {
                            Text(text = "Leave Group")
                        },
                        text = {
                            Text(text = "Are you sure you want to leave this group?")
                        },
                        confirmButton = {
                            Button(
                                onClick = onConfirmLeaveGroupClick,
                                enabled = !isLeavingGroup
                            ) {
                                if (isLeavingGroup) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                Text("Leave")
                            }
                        },
                        dismissButton = {
                            TextButton(
                                onClick = onDismissLeaveConfirmationDialog,
                                enabled = !isLeavingGroup
                            ) {
                                Text("Cancel")
                            }
                        }
                    )
                }

                if (showLeaveSuccessDialog) {
                    AlertDialog(
                        onDismissRequest = onDismissLeaveSuccessDialog,
                        title = {
                            Text(text = "Left Group")
                        },
                        text = {
                            Text(text = leaveSuccessMessage ?: "You have successfully left the group.")
                        },
                        confirmButton = {
                            TextButton(onClick = onDismissLeaveSuccessDialog) {
                                Text("OK")
                            }
                        }
                    )
                }

                if (showEndVotingSessionConfirmationDialog) {
                    AlertDialog(
                        onDismissRequest = onDismissEndVotingSessionConfirmationDialog,
                        title = {
                            Text(text = "End Voting Session")
                        },
                        text = {
                            Text(text = "Are you sure you want to end the voting session? The selected movie will be determined based on the votes.")
                        },
                        confirmButton = {
                            Button(
                                onClick = onConfirmEndVotingSessionClick,
                                enabled = !isEndingVotingSession
                            ) {
                                if (isEndingVotingSession) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                Text("End Session")
                            }
                        },
                        dismissButton = {
                            TextButton(
                                onClick = onDismissEndVotingSessionConfirmationDialog,
                                enabled = !isEndingVotingSession
                            ) {
                                Text("Cancel")
                            }
                        }
                    )
                }

                if (showEndVotingSessionSuccessDialog) {
                    AlertDialog(
                        onDismissRequest = onDismissEndVotingSessionSuccessDialog,
                        title = {
                            Text(text = "Voting Session Ended")
                        },
                        text = {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (selectedMovieAfterEnding != null) {
                                    Text(
                                        text = "The selected movie is:",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = selectedMovieAfterEnding.title,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                if (endVotingSessionSuccessMessage != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = endVotingSessionSuccessMessage,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = onDismissEndVotingSessionSuccessDialog) {
                                Text("OK")
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ErrorState(
    errorMessage: String,
    onRetryClick: () -> Unit,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Error",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(
            text = errorMessage,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 16.dp)
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = onBackClick) {
                Text("Go Back")
            }
            Button(onClick = onRetryClick) {
                Text("Retry")
            }
        }
    }
}

@Composable
fun GroupDetailsContent(
    groupDetails: GroupDetailsData,
    genres: Map<Int, String> = emptyMap(),
    onBackClick: () -> Unit,
    onStartVotingSessionClick: () -> Unit,
    onJoinVotingSessionClick: () -> Unit,
    onResumeVotingSessionClick: () -> Unit,
    onEndVotingSessionClick: () -> Unit,
    onDeleteGroupClick: () -> Unit,
    onLeaveGroupClick: () -> Unit,
    isStartingVotingSession: Boolean = false,
    isEndingVotingSession: Boolean = false
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "Group Details",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        GroupInformationSection(
            groupName = groupDetails.name,
            role = groupDetails.role,
            invitationCode = groupDetails.invitationCode,
            members = groupDetails.members,
            onDeleteGroupClick = onDeleteGroupClick,
            onLeaveGroupClick = onLeaveGroupClick
        )

        Spacer(modifier = Modifier.height(24.dp))

        VotingInformationSection(
            role = groupDetails.role,
            votingSession = groupDetails.votingSession,
            genres = genres,
            onStartVotingSessionClick = onStartVotingSessionClick,
            onJoinVotingSessionClick = onJoinVotingSessionClick,
            onResumeVotingSessionClick = onResumeVotingSessionClick,
            onEndVotingSessionClick = onEndVotingSessionClick,
            isStartingVotingSession = isStartingVotingSession,
            isEndingVotingSession = isEndingVotingSession
        )
    }
}

@Composable
fun GroupInformationSection(
    groupName: String,
    role: String,
    invitationCode: String?,
    members: List<GroupMember>?,
    onDeleteGroupClick: () -> Unit,
    onLeaveGroupClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Group Information",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Text(
                text = "Name: $groupName",
                style = MaterialTheme.typography.bodyLarge
            )

            Text(
                text = "Role: ${role.replaceFirstChar { it.uppercase() }}",
                style = MaterialTheme.typography.bodyLarge
            )

            if (role == "owner" && invitationCode != null) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Invitation Code:",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = invitationCode,
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (role == "owner" && members != null) {
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                Text(
                    text = "Members",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                if (members.isEmpty()) {
                    Text(
                        text = "No members yet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        members.forEach { member ->
                            MemberItem(member = member)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (role == "owner") {
                Button(
                    onClick = onDeleteGroupClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Delete Group")
                }
            } else {
                Button(
                    onClick = onLeaveGroupClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Leave Group")
                }
            }
        }
    }
}

@Composable
fun MemberItem(
    member: GroupMember
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = member.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = member.email,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun VotingInformationSection(
    role: String,
    votingSession: VotingSessionData,
    genres: Map<Int, String> = emptyMap(),
    onStartVotingSessionClick: () -> Unit,
    onJoinVotingSessionClick: () -> Unit,
    onResumeVotingSessionClick: () -> Unit,
    onEndVotingSessionClick: () -> Unit,
    isStartingVotingSession: Boolean = false,
    isEndingVotingSession: Boolean = false
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Voting Information",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            when {
                votingSession.state == "notStarted" -> {
                    if (role == "owner") {
                        Button(
                            onClick = onStartVotingSessionClick,
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !isStartingVotingSession
                        ) {
                            if (isStartingVotingSession) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text("Start Voting Session")
                        }
                    } else {
                        Text(
                            text = "Waiting for the owner to start the session",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
                votingSession.state == "started" -> {
                    VotingSessionStartedContent(
                        role = role,
                        userVotingProgress = votingSession.userVotingProgress,
                        onJoinVotingSessionClick = onJoinVotingSessionClick,
                        onResumeVotingSessionClick = onResumeVotingSessionClick,
                        onEndVotingSessionClick = onEndVotingSessionClick,
                        isEndingVotingSession = isEndingVotingSession
                    )
                }
                votingSession.state == "ended" -> {
                    if (votingSession.selectedMovie != null) {
                        SelectedMovieContent(
                            selectedMovie = votingSession.selectedMovie,
                            genres = genres
                        )
                    } else {
                        Text(
                            text = "Voting session has ended",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VotingSessionStartedContent(
    role: String,
    userVotingProgress: UserVotingProgress,
    onJoinVotingSessionClick: () -> Unit,
    onResumeVotingSessionClick: () -> Unit,
    onEndVotingSessionClick: () -> Unit,
    isEndingVotingSession: Boolean = false
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (role == "owner") {
            when {
                userVotingProgress.hasVotedForAll -> {
                    Button(
                        onClick = onEndVotingSessionClick,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isEndingVotingSession
                    ) {
                        if (isEndingVotingSession) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text("End Voting Session")
                    }
                }
                userVotingProgress.hasVotedForSubset -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onResumeVotingSessionClick,
                            modifier = Modifier.weight(1f),
                            enabled = !isEndingVotingSession
                        ) {
                            Text("Resume Voting Session")
                        }
                        Button(
                            onClick = onEndVotingSessionClick,
                            modifier = Modifier.weight(1f),
                            enabled = !isEndingVotingSession
                        ) {
                            if (isEndingVotingSession) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text("End Voting Session")
                        }
                    }
                }
                userVotingProgress.hasNotVoted -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onJoinVotingSessionClick,
                            modifier = Modifier.weight(1f),
                            enabled = !isEndingVotingSession
                        ) {
                            Text("Join Voting Session")
                        }
                        Button(
                            onClick = onEndVotingSessionClick,
                            modifier = Modifier.weight(1f),
                            enabled = !isEndingVotingSession
                        ) {
                            if (isEndingVotingSession) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text("End Voting Session")
                        }
                    }
                }
            }
        } else {
            when {
                userVotingProgress.hasNotVoted -> {
                    Button(
                        onClick = onJoinVotingSessionClick,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Join Voting Session")
                    }
                }
                userVotingProgress.hasVotedForSubset -> {
                    Button(
                        onClick = onResumeVotingSessionClick,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Resume Voting Session")
                    }
                }
                userVotingProgress.hasVotedForAll -> {
                    Text(
                        text = "Waiting for the owner to end the session",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun SelectedMovieContent(
    selectedMovie: SelectedMovie,
    genres: Map<Int, String> = emptyMap()
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Selected Movie",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        if (selectedMovie.posterUrl != null) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(selectedMovie.posterUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = selectedMovie.title,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp),
                contentScale = ContentScale.Crop
            )
        }

        Text(
            text = selectedMovie.title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Rating: ${String.format("%.1f", selectedMovie.rating)}",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "•",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Length: ${selectedMovie.length} min",
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Genres:",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Medium
            )
            if (selectedMovie.genres.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    selectedMovie.genres.forEach { genreId ->
                        val genreName = genres[genreId] ?: "Genre $genreId"
                        Card(
                            modifier = Modifier.padding(vertical = 4.dp),
                            colors = androidx.compose.material3.CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer
                            )
                        ) {
                            Text(
                                text = genreName,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            } else {
                Text(
                    text = "No genres available",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Text(
            text = "Summary:",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Medium
        )

        Text(
            text = selectedMovie.summary,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
