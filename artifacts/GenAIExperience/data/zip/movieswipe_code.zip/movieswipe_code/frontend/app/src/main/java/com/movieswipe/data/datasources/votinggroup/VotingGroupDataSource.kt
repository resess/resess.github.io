// VotingGroup domain data sources

package com.movieswipe.data.datasources.votinggroup

import android.util.Log
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.movieswipe.utils.Constants
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.io.IOException

interface VotingGroupDataSource {
    suspend fun createGroup(
        name: String,
        ownerId: String,
        genrePreferences: List<Int>
    ): Result<CreatedVotingGroup>

    suspend fun getGroupsList(userId: String): Result<List<GroupWithRole>>
    
    suspend fun getGroupDetails(groupId: String, userId: String): Result<GroupDetails>
    
    suspend fun deleteGroup(groupId: String, userId: String): Result<DeleteGroupResponse>

    suspend fun leaveGroup(groupId: String, userId: String): Result<LeaveGroupResponse>

    suspend fun validateInvitationCode(
        invitationCode: String,
        userId: String
    ): Result<ValidateInvitationCodeResponse>

    suspend fun getGroupGenres(invitationCode: String): Result<List<Int>>

    suspend fun joinGroup(
        invitationCode: String,
        userId: String,
        genrePreferences: List<Int>
    ): Result<JoinGroupResponse>

    suspend fun startVotingSession(groupId: String, userId: String): Result<GroupDetails>

    suspend fun endVotingSession(groupId: String, userId: String): Result<GroupDetails>

    suspend fun getNextMovieToVoteOn(
        groupId: String,
        userId: String
    ): Result<NextMovieToVoteOnResponse>

    suspend fun submitVote(
        groupId: String,
        userId: String,
        movieId: Int,
        voteType: String
    ): Result<SubmitVoteResponse>
}

data class CreatedVotingGroup(
    val id: String,
    val name: String,
    @SerializedName("ownerId")
    val ownerId: String,
    @SerializedName("genrePreferences")
    val genrePreferences: List<Int>,
    @SerializedName("createdAt")
    val createdAt: String,
    @SerializedName("updatedAt")
    val updatedAt: String
)

data class CreateGroupRequest(
    val name: String,
    @SerializedName("userId")
    val userId: String,
    @SerializedName("genrePreferences")
    val genrePreferences: List<Int>
)

data class ErrorResponse(
    val error: String,
    val groupId: String? = null
)

class AlreadyMemberException(message: String, val groupId: String) : Exception(message)

class StartVotingSessionException(
    message: String,
    val groupDetails: GroupDetails? = null
) : Exception(message)

data class DeleteGroupResponse(
    val message: String
)

data class LeaveGroupResponse(
    val message: String
)

data class ValidateInvitationCodeRequest(
    val invitationCode: String,
    @SerializedName("userId")
    val userId: String
)

data class ValidateInvitationCodeResponse(
    val groupId: String,
    val groupName: String
)

data class GroupGenresResponse(
    val genres: List<Int>
)

data class JoinGroupRequest(
    val invitationCode: String,
    @SerializedName("userId")
    val userId: String,
    @SerializedName("genrePreferences")
    val genrePreferences: List<Int>
)

data class JoinGroupResponse(
    val groupId: String,
    val message: String?
)

data class GroupWithRole(
    val id: String,
    val name: String,
    val role: String // "owner" or "member"
)

data class GroupMember(
    val id: String,
    val name: String,
    val email: String,
    @SerializedName("profilePictureUrl")
    val profilePictureUrl: String? = null
)

data class SelectedMovie(
    val movieId: Int,
    val title: String,
    @SerializedName("posterUrl")
    val posterUrl: String? = null,
    val genres: List<Int>,
    val rating: Double,
    val length: Int,
    val summary: String
)

data class UserVotingProgress(
    val hasNotVoted: Boolean,
    @SerializedName("hasVotedForSubset")
    val hasVotedForSubset: Boolean,
    @SerializedName("hasVotedForAll")
    val hasVotedForAll: Boolean
)

data class VotingSessionData(
    val state: String,
    @SerializedName("userVotingProgress")
    val userVotingProgress: UserVotingProgress,
    @SerializedName("moviesToVoteOn")
    val moviesToVoteOn: List<SelectedMovie>? = null,
    @SerializedName("selectedMovie")
    val selectedMovie: SelectedMovie? = null
)

data class GroupDetails(
    val id: String,
    val name: String,
    val role: String,
    @SerializedName("invitationCode")
    val invitationCode: String? = null,
    val members: List<GroupMember>? = null,
    @SerializedName("votingSession")
    val votingSession: VotingSessionData,
    val error: String? = null,
    val message: String? = null
)

data class NextMovieToVoteOnResponse(
    val movie: SelectedMovie?,
    @SerializedName("hasVotedOnAllMovies")
    val hasVotedOnAllMovies: Boolean
)

data class SubmitVoteRequest(
    val movieId: Int,
    @SerializedName("voteType")
    val voteType: String,
    @SerializedName("userId")
    val userId: String
)

data class SubmitVoteResponse(
    @SerializedName("hasVotedOnAllMovies")
    val hasVotedOnAllMovies: Boolean
)

interface VotingGroupApiService {
    @POST("voting-groups")
    suspend fun createGroup(@Body request: CreateGroupRequest): CreatedVotingGroup

    @GET("voting-groups")
    suspend fun getGroupsList(@Query("userId") userId: String): List<GroupWithRole>
    
    @GET("voting-groups/{groupId}")
    suspend fun getGroupDetails(
        @Path("groupId") groupId: String,
        @Query("userId") userId: String
    ): GroupDetails
    
    @DELETE("voting-groups/{groupId}")
    suspend fun deleteGroup(
        @Path("groupId") groupId: String,
        @Query("userId") userId: String
    ): DeleteGroupResponse

    @POST("voting-groups/{groupId}/leave")
    suspend fun leaveGroup(
        @Path("groupId") groupId: String,
        @Query("userId") userId: String
    ): LeaveGroupResponse

    @POST("voting-groups/validate-invitation-code")
    suspend fun validateInvitationCode(@Body request: ValidateInvitationCodeRequest): ValidateInvitationCodeResponse

    @GET("voting-groups/genres/by-invitation-code")
    suspend fun getGroupGenres(@Query("invitationCode") invitationCode: String): GroupGenresResponse

    @POST("voting-groups/join")
    suspend fun joinGroup(@Body request: JoinGroupRequest): JoinGroupResponse

    @POST("voting-groups/{groupId}/start-voting-session")
    suspend fun startVotingSession(
        @Path("groupId") groupId: String,
        @Query("userId") userId: String
    ): GroupDetails

    @POST("voting-groups/{groupId}/end-voting-session")
    suspend fun endVotingSession(
        @Path("groupId") groupId: String,
        @Query("userId") userId: String
    ): GroupDetails

    @GET("voting-groups/{groupId}/next-movie-to-vote-on")
    suspend fun getNextMovieToVoteOn(
        @Path("groupId") groupId: String,
        @Query("userId") userId: String
    ): NextMovieToVoteOnResponse

    @POST("voting-groups/{groupId}/vote")
    suspend fun submitVote(
        @Path("groupId") groupId: String,
        @Body request: SubmitVoteRequest
    ): SubmitVoteResponse
}

class VotingGroupDataSourceImpl : VotingGroupDataSource {
    private val retrofit = Retrofit.Builder()
        .baseUrl(Constants.BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val apiService = retrofit.create(VotingGroupApiService::class.java)

    override suspend fun createGroup(
        name: String,
        ownerId: String,
        genrePreferences: List<Int>
    ): Result<CreatedVotingGroup> {
        return try {
            val request = CreateGroupRequest(
                name = name,
                userId = ownerId,
                genrePreferences = genrePreferences
            )
            val group = apiService.createGroup(request)
            Result.success(group)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessage(e.code())
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessage(e.code())
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to create group. Please try again."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to create group. Please try again."))
        }
    }

    override suspend fun getGroupsList(userId: String): Result<List<GroupWithRole>> {
        return try {
            val groups = apiService.getGroupsList(userId)
            Result.success(groups)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessageForGetGroups(e.code())
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessageForGetGroups(e.code())
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to load groups. Please retry."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to load groups. Please retry."))
        }
    }

    private fun getDefaultErrorMessage(code: Int): String {
        return when (code) {
            400 -> "Group name is required and must be 3-30 alphanumeric characters."
            500 -> "Failed to create group. Please try again."
            else -> "Failed to create group. Please try again."
        }
    }

    private fun getDefaultErrorMessageForGetGroups(code: Int): String {
        return when (code) {
            401 -> "User authentication required"
            500 -> "Failed to load groups. Please retry."
            else -> "Failed to load groups. Please retry."
        }
    }

    override suspend fun getGroupDetails(groupId: String, userId: String): Result<GroupDetails> {
        return try {
            val groupDetails = apiService.getGroupDetails(groupId, userId)
            Result.success(groupDetails)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessageForGetGroupDetails(e.code())
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessageForGetGroupDetails(e.code())
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to load group information."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to load group information."))
        }
    }

    private fun getDefaultErrorMessageForGetGroupDetails(code: Int): String {
        return when (code) {
            401 -> "User authentication required"
            403 -> "You are no longer a member of this group."
            404 -> "This group has been deleted."
            500 -> "Failed to load group information."
            else -> "Failed to load group information."
        }
    }

    override suspend fun deleteGroup(groupId: String, userId: String): Result<DeleteGroupResponse> {
        return try {
            val response = apiService.deleteGroup(groupId, userId)
            Result.success(response)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessageForDeleteGroup(e.code())
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessageForDeleteGroup(e.code())
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to delete group. Please try again."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to delete group. Please try again."))
        }
    }

    private fun getDefaultErrorMessageForDeleteGroup(code: Int): String {
        return when (code) {
            401 -> "User authentication required"
            403 -> "Only the group owner can delete the group."
            404 -> "This group has been deleted."
            500 -> "Failed to delete group. Please try again."
            else -> "Failed to delete group. Please try again."
        }
    }

    override suspend fun leaveGroup(groupId: String, userId: String): Result<LeaveGroupResponse> {
        return try {
            val response = apiService.leaveGroup(groupId, userId)
            Result.success(response)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessageForLeaveGroup(e.code())
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessageForLeaveGroup(e.code())
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to leave group. Please try again."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to leave group. Please try again."))
        }
    }

    private fun getDefaultErrorMessageForLeaveGroup(code: Int): String {
        return when (code) {
            401 -> "User authentication required"
            403 -> "You are not a member of this group."
            404 -> "This group has been deleted."
            500 -> "Failed to leave group. Please try again."
            else -> "Failed to leave group. Please try again."
        }
    }

    override suspend fun validateInvitationCode(
        invitationCode: String,
        userId: String
    ): Result<ValidateInvitationCodeResponse> {
        return try {
            val request = ValidateInvitationCodeRequest(
                invitationCode = invitationCode,
                userId = userId
            )
            val response = apiService.validateInvitationCode(request)
            Result.success(response)
        } catch (e: HttpException) {
            val errorResult = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                val errorMessage = errorResponse.error ?: getDefaultErrorMessageForValidateInvitationCode(e.code())
                Pair(errorMessage, errorResponse.groupId)
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                Pair(getDefaultErrorMessageForValidateInvitationCode(e.code()), null)
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: ${errorResult.first}")
            if (errorResult.second != null && errorResult.first.contains("already a member", ignoreCase = true)) {
                Result.failure(AlreadyMemberException(errorResult.first, errorResult.second!!))
            } else {
                Result.failure(Exception(errorResult.first))
            }
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to validate invitation code. Please try again."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to validate invitation code. Please try again."))
        }
    }

    private fun getDefaultErrorMessageForValidateInvitationCode(code: Int): String {
        return when (code) {
            400 -> "Invalid invitation code. Please check the code and try again."
            401 -> "User authentication required"
            500 -> "Failed to validate invitation code. Please try again."
            else -> "Failed to validate invitation code. Please try again."
        }
    }

    override suspend fun getGroupGenres(invitationCode: String): Result<List<Int>> {
        return try {
            val response = apiService.getGroupGenres(invitationCode)
            Result.success(response.genres)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessageForGetGroupGenres(e.code())
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessageForGetGroupGenres(e.code())
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to load movie genres. Please try again."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to load movie genres. Please try again."))
        }
    }

    private fun getDefaultErrorMessageForGetGroupGenres(code: Int): String {
        return when (code) {
            400 -> "Invalid invitation code. Please check the code and try again."
            500 -> "Failed to load movie genres. Please try again."
            else -> "Failed to load movie genres. Please try again."
        }
    }

    override suspend fun joinGroup(
        invitationCode: String,
        userId: String,
        genrePreferences: List<Int>
    ): Result<JoinGroupResponse> {
        return try {
            val request = JoinGroupRequest(
                invitationCode = invitationCode,
                userId = userId,
                genrePreferences = genrePreferences
            )
            val response = apiService.joinGroup(request)
            Result.success(response)
        } catch (e: HttpException) {
            val errorResult = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                val errorMessage = errorResponse.error ?: getDefaultErrorMessageForJoinGroup(e.code())
                Pair(errorMessage, errorResponse.groupId)
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                Pair(getDefaultErrorMessageForJoinGroup(e.code()), null)
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: ${errorResult.first}")
            if (errorResult.second != null && errorResult.first.contains("already a member", ignoreCase = true)) {
                Result.failure(AlreadyMemberException(errorResult.first, errorResult.second!!))
            } else {
                Result.failure(Exception(errorResult.first))
            }
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to join group. Please try again."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to join group. Please try again."))
        }
    }

    private fun getDefaultErrorMessageForJoinGroup(code: Int): String {
        return when (code) {
            400 -> "Failed to join group. Please try again."
            401 -> "User authentication required"
            500 -> "Failed to join group. Please try again."
            else -> "Failed to join group. Please try again."
        }
    }

    override suspend fun startVotingSession(groupId: String, userId: String): Result<GroupDetails> {
        return try {
            val groupDetails = apiService.startVotingSession(groupId, userId)
            
            if (groupDetails.error != null) {
                Log.e("VotingGroupDataSource", "Error in response: ${groupDetails.error}")
                Result.failure(StartVotingSessionException(groupDetails.error, groupDetails))
            } else if (groupDetails.message != null) {
                Log.w("VotingGroupDataSource", "Warning message in response: ${groupDetails.message}")
                Result.success(groupDetails)
            } else {
                Result.success(groupDetails)
            }
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessageForStartVotingSession(e.code())
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessageForStartVotingSession(e.code())
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to start voting session. Please try again."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to start voting session. Please try again."))
        }
    }

    private fun getDefaultErrorMessageForStartVotingSession(code: Int): String {
        return when (code) {
            400 -> "A voting session is already in progress for this group."
            401 -> "User authentication required"
            403 -> "Only the group owner can start a voting session."
            404 -> "This group has been deleted."
            500 -> "Failed to start voting session. Please try again."
            else -> "Failed to start voting session. Please try again."
        }
    }

    override suspend fun endVotingSession(groupId: String, userId: String): Result<GroupDetails> {
        return try {
            val groupDetails = apiService.endVotingSession(groupId, userId)
            
            if (groupDetails.error != null) {
                Log.e("VotingGroupDataSource", "Error in response: ${groupDetails.error}")
                Result.failure(Exception(groupDetails.error))
            } else {
                Result.success(groupDetails)
            }
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessageForEndVotingSession(e.code())
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessageForEndVotingSession(e.code())
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to end the voting session. Please try again."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to end the voting session. Please try again."))
        }
    }

    private fun getDefaultErrorMessageForEndVotingSession(code: Int): String {
        return when (code) {
            400 -> "A voting session is not currently in progress for this group."
            401 -> "User authentication required"
            403 -> "Only the group owner can end the voting session."
            404 -> "This group has been deleted."
            500 -> "Failed to end the voting session. Please try again."
            else -> "Failed to end the voting session. Please try again."
        }
    }

    override suspend fun getNextMovieToVoteOn(
        groupId: String,
        userId: String
    ): Result<NextMovieToVoteOnResponse> {
        return try {
            val response = apiService.getNextMovieToVoteOn(groupId, userId)
            Result.success(response)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessageForGetNextMovie(e.code())
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessageForGetNextMovie(e.code())
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to load next movie. Please try again."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to load next movie. Please try again."))
        }
    }

    private fun getDefaultErrorMessageForGetNextMovie(code: Int): String {
        return when (code) {
            401 -> "User authentication required"
            403 -> "You are no longer a member of this group."
            404 -> "This group has been deleted."
            400 -> "The voting session has ended."
            500 -> "Failed to load next movie. Please try again."
            else -> "Failed to load next movie. Please try again."
        }
    }

    override suspend fun submitVote(
        groupId: String,
        userId: String,
        movieId: Int,
        voteType: String
    ): Result<SubmitVoteResponse> {
        return try {
            val request = SubmitVoteRequest(
                movieId = movieId,
                voteType = voteType,
                userId = userId
            )
            val response = apiService.submitVote(groupId, request)
            Result.success(response)
        } catch (e: HttpException) {
            val errorMessage = try {
                val errorBody = e.response()?.errorBody()?.string()
                val gson = Gson()
                val errorResponse = gson.fromJson(errorBody, ErrorResponse::class.java)
                errorResponse.error ?: getDefaultErrorMessageForSubmitVote(e.code())
            } catch (parseException: Exception) {
                Log.e("VotingGroupDataSource", "Failed to parse error response", parseException)
                getDefaultErrorMessageForSubmitVote(e.code())
            }
            Log.e("VotingGroupDataSource", "HTTP error: ${e.code()}, message: $errorMessage")
            Result.failure(Exception(errorMessage))
        } catch (e: IOException) {
            Log.e("VotingGroupDataSource", "Network error", e)
            Result.failure(Exception("Failed to submit vote. Please try again."))
        } catch (e: Exception) {
            Log.e("VotingGroupDataSource", "Unexpected error", e)
            Result.failure(Exception("Failed to submit vote. Please try again."))
        }
    }

    private fun getDefaultErrorMessageForSubmitVote(code: Int): String {
        return when (code) {
            400 -> {
                // Check if it's about invalid vote type or voting session ended
                // The backend should return specific error messages that we parse from error body
                "Swipe right for \"interested\" or left for \"not interested\". No other swiping gesture allowed."
            }
            401 -> "User authentication required"
            403 -> "You are no longer a member of this group."
            404 -> "This group has been deleted."
            500 -> "Failed to submit vote. Please try again."
            else -> "Failed to submit vote. Please try again."
        }
    }
}
