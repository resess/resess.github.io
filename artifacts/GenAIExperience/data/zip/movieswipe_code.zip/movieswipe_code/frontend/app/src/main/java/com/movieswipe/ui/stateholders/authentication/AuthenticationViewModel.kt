// Authentication feature state holders

package com.movieswipe.ui.stateholders.authentication

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.movieswipe.data.repositories.user.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthenticationUiState(
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val isAuthenticated: Boolean = false,
    val idToken: String? = null,
    val userId: String? = null,
    val signOutSuccess: Boolean = false
)

class AuthenticationViewModel(
    private val userRepository: UserRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(AuthenticationUiState())
    val uiState: StateFlow<AuthenticationUiState> = _uiState.asStateFlow()

    fun signIn(idToken: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            
            try {
                val user = userRepository.signIn(idToken)
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    isAuthenticated = true,
                    idToken = idToken,
                    userId = user.id,
                    signOutSuccess = false
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("temporarily unavailable", ignoreCase = true) == true -> {
                        "Authentication service temporarily unavailable. Please try again."
                    }
                    e.message?.contains("unsuccessful", ignoreCase = true) == true -> {
                        "Authentication unsuccessful. Please try again."
                    }
                    else -> {
                        "Authentication service temporarily unavailable. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = errorMessage,
                    isAuthenticated = false
                )
            }
        }
    }

    fun signOut(idToken: String?) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            
            val tokenToUse = idToken ?: _uiState.value.idToken
            if (tokenToUse.isNullOrBlank()) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "No authentication token available. Please sign in again.",
                    isAuthenticated = false
                )
                return@launch
            }
            
            try {
                userRepository.signOut(tokenToUse)
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    isAuthenticated = false,
                    idToken = null,
                    userId = null,
                    signOutSuccess = true
                )
            } catch (e: Exception) {
                val errorMessage = when {
                    e.message?.contains("temporarily unavailable", ignoreCase = true) == true ||
                    e.message?.contains("cannot sign out", ignoreCase = true) == true -> {
                        "Authentication service temporarily unavailable, cannot sign out. Please try again."
                    }
                    else -> {
                        "Authentication service temporarily unavailable, cannot sign out. Please try again."
                    }
                }
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = errorMessage,
                    isAuthenticated = true
                )
            }
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
