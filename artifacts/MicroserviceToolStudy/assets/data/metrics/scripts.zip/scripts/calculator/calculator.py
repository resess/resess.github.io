from models.decomposition_identifier import DecompositionIdentifier


class Calculator:
    def calculate_one(self, decomposition_identifier: DecompositionIdentifier):
        pass

    def calculate_all(self):
        pass
