This is the Python 2.7 runtime for ANTLR.
Visit the ANTLR web sites for more information:
http://www.antlr.org
https://raw.githubusercontent.com/antlr/antlr4/master/doc/python-target.md
