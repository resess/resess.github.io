public class Main
{
//    public static void main(String[] args)
//    {
//        TParser parser = new TParser(new CommonTokenStream(new TLexer(new ANTLRInputStream("b"))));
//        parser.addParseListener(new MyTBaseListener());
//
//		parser.a();
//
//		System.out.println("######################");
//		parser = new TParser(new CommonTokenStream(new TLexer(new ANTLRInputStream("x"))));
//		parser.addParseListener(new MyTBaseListener());
//		parser.b();
//    }
//
//	private static class MyTBaseListener extends TBaseListener {
//		@Override
//		public void enterAlt1(TParser.Alt1Context ctx)
//		{
//			System.out.println("entering alt1");
//		}
//
//		@Override
//		public void exitAlt1(TParser.Alt1Context ctx)
//		{
//			System.out.println("exiting alt1");
//		}
//
//		@Override
//		public void enterB(TParser.BContext ctx) {
//			System.out.println("enter b");
//		}
//
//		@Override
//		public void exitB(TParser.BContext ctx) {
//			System.out.println("exiting b");
//		}
//
//		@Override
//		public void enterEveryRule(ParserRuleContext ctx) {
//			System.out.println("enterEveryRule");
//		}
//	}
}
