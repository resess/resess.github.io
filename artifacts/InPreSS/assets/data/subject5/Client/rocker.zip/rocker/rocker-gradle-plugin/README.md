# A gradle plugin for Rocker.

This gradle plugin that creates `generateRockerTemplateSource` tasks that are 
run before `compileJava`. 

## Building the standalone plugin

This build has been tested in Eclipse and in Intellij Community addition.

By running `gradle publishToMavenLocal` you can make the plugin available
locally for testing.
