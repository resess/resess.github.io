var wasabiUIPlugins = [
    {
        "pluginType": "contributeDraftTab",
        "displayName": "Get/Set Priority",
        "ctrlName": "DemoPluginCtrl",
        "ctrl": "plugins/demo-plugin/ctrl.js",
        "templateUrl": "plugins/demo-plugin/template.html"
    },
    {
        "pluginType": "contributeDetailsTab",
        "displayName": "Get/Set Priority",
        "ctrlName": "DemoPluginDetailsCtrl",
        "ctrl": "plugins/demo-plugin/detailsCtrl.js",
        "templateUrl": "plugins/demo-plugin/detailsTemplate.html"
    }
];
