# Wasabi-Eye
This is a chrome extension which allows to view experiment elements on websites if they have an `abtest="<EXPERIMENT_ID>"` attribute.
To use it, just install it as an unpacked extension to your browser. Make sure that the developer mode is enabled.

# Credits

This chrome extension was a combined effort of the following people:

1. [Piyush Waradpande] (https://github.com/pi5)
2. [Ajith Rajeswari] (https://github.com/ajithkrajeswari)
3. [Diwakar Kumawat] (https://github.com/diwakarkumawat)
4. [Mary Farrow] (https://github.com/mffarrow)


Special thanks to [Sebastian Höffner](https://github.com/Faedrivin) for refactoring the code, making it generic and grooming it to make it open source.

