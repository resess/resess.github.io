#The AuditLogObjects module

The AuditLogObjects module holds classes, mainly POJOs, which are needed by the AuditLog module.
