# ab-simulation

A Python 2.7 library to simulate AB tests and analyze results.
