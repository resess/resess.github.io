---
name: Bug report
about: Create a report to help us improve

---

* **dble version：**  
* **preconditions ：**  
no
* **configs：** 

**schema.xml**  

```


```

**rule.xml**  

```


```

**server.xml**  

```


```

* **steps：**    
    step1.  
* **expect result：**  
    1.
* **real result：**  
    1.
* **supplements：**  
    1.
