package com.actiontech.dble.btrace.provider;

/**
 * Created by szf on 2019/1/7.
 */
public class ComplexQueryProvider {

    public void endRoute(long id) {
    }

    public void endComplexExecute(long id) {

    }

    public void firstComplexEof(long id) {

    }

}
