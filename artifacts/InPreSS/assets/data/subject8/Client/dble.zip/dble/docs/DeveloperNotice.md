VCS: git  
Dependency Management:maven  
IDE:IntelliJ IDEA  Community  

setting IDE code style:    
import dble_IntelliJ.xml into IntelliJ

![codestyle](./codestyle.png)
 
 

Checkstyle Plugin: check before commit  

setting:  
![checkstyle](./checkstyle.png)

FindBugs-IDEA:check before commit  

setting:  
![findbugs](./findbugs.png)  


copy config files to target before build( FOR windows )  

![copyResource1](./copyResource1.png)  

![copyResource2](./copyResource2.png)






 