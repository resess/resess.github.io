Change Log
==========

Version 1.0.1 *(2013-06-03)*
----------------------------

 * Explicitly forbid declaring `@Inject` on a class type (e.g., `@Inject class Foo {}`).
 * Update JavaWriter to 1.0.5.


Version 1.0.0 *(2013-05-07)*
----------------------------

Initial release.
