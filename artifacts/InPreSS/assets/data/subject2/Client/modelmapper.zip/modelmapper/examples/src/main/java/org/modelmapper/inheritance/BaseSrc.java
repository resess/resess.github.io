package org.modelmapper.inheritance;

public class BaseSrc {

  private String aString;
}
