package org.modelmapper.inheritance;

public class BaseDestB extends BaseDest {
}
