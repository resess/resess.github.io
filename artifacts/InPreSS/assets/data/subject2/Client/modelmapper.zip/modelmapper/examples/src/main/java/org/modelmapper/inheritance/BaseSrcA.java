package org.modelmapper.inheritance;

public class BaseSrcA extends BaseSrc {
}
