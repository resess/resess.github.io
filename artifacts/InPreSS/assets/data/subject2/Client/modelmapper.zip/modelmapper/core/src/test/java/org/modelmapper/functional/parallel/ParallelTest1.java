package org.modelmapper.functional.parallel;

import org.modelmapper.AbstractTest;
import org.testng.annotations.Test;

/**
 * @author Jonathan Halterman
 */
@Test(groups = "functional")
public class ParallelTest1 extends AbstractTest {
  
}
