/*
 * Copyright 2018 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.modelmapper.protobuf;

import com.google.protobuf.Message;
import com.google.protobuf.Message.Builder;
import org.modelmapper.spi.ConditionalConverter;
import org.modelmapper.spi.MappingContext;

/**
 * Converts {@link Message} to {@link Builder}
 *
 * @author Chun Han Hsiao
 */
public class MessageToBuilderConverter implements ConditionalConverter<Message, Builder> {
  @Override
  public MatchResult match(Class<?> sourceType, Class<?> destinationType) {
    boolean match = Message.class.isAssignableFrom(sourceType)
        && Builder.class.isAssignableFrom(destinationType)
        && sourceType.equals(ProtobufHelper.messageOfBuilder(destinationType));
    return match ? MatchResult.FULL : MatchResult.NONE;
  }

  @Override
  public Builder convert(MappingContext<Message, Builder> context) {
    return context.getSource().toBuilder();
  }
}
