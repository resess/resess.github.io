package org.modelmapper.inheritance;

public class BaseSrcB extends BaseSrc {
}
