package org.modelmapper.inheritance;

public class BaseDest {

  private String aString;
}
