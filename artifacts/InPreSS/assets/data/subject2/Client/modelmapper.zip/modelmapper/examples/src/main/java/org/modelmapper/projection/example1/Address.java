package org.modelmapper.projection.example1;

public class Address {
  private String street;

  public String getStreet() {
    return street;
  }

  public void setStreet(String street) {
    this.street = street;
  }
}
