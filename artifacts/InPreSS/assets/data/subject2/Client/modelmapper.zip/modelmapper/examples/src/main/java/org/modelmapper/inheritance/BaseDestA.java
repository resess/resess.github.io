package org.modelmapper.inheritance;

public class BaseDestA extends BaseDest {
}
