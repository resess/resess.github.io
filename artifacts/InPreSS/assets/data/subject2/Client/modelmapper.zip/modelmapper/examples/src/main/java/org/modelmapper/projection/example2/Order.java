package org.modelmapper.projection.example2;

public class Order {
  Address address;

  public Address getAddress() {
    return address;
  }

  public void setAddress(Address address) {
    this.address = address;
  }
}
