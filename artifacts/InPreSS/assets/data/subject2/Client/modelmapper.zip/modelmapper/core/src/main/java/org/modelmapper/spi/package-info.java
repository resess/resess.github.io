/**
 * Service Provider Interface
 */
package org.modelmapper.spi;