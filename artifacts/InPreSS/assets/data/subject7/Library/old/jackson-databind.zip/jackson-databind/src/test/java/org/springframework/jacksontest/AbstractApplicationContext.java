package org.springframework.jacksontest;

public class AbstractApplicationContext {

}
