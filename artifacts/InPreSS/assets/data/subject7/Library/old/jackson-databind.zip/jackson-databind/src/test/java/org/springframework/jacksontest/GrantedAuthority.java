package org.springframework.jacksontest;

public interface GrantedAuthority {

}
