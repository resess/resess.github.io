package com.mchange.v2.c3p0.jacksontest;

// test class for [databind#1931]
public class ComboPooledDataSource {

}
