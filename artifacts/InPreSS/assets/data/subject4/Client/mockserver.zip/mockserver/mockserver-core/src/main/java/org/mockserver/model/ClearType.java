package org.mockserver.model;

/**
 * @author jamesdbloom
 */
public enum ClearType {
    LOG,
    EXPECTATIONS,
    ALL
}
