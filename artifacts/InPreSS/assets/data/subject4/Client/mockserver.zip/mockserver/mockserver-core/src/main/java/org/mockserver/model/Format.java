package org.mockserver.model;

/**
 * @author jamesdbloom
 */
public enum Format {
    JAVA,
    JSON,
    LOG_ENTRIES
}
