package org.mockserver.matchers;

/**
 * @author jamesdbloom
 */
public enum MatchType {
    STRICT,
    ONLY_MATCHING_FIELDS
}
