name  | domain
:-----|:-------------------
[nb9hq](https://s3.console.aws.amazon.com/s3/buckets/aws-website-mockserver-nb9hq/?region=us-east-1) | mock-server.com
[f10aa](https://s3.console.aws.amazon.com/s3/buckets/aws-website-mockserver----f10aa/?region=us-east-1) | 5-6.mock-server.com
[9684b](https://s3.console.aws.amazon.com/s3/buckets/aws-website-mockserver----9684b/?region=us-east-1) | 5-5.mock-server.com
[mz777](https://s3.console.aws.amazon.com/s3/buckets/aws-website-mockserver----mz777/?region=us-east-1) | 5-4.mock-server.com
[l2i8l](https://s3.console.aws.amazon.com/s3/buckets/aws-website-mockserver----l2i8l/?region=us-east-1) | 5-3.mock-server.com
[azamg](https://s3.console.aws.amazon.com/s3/buckets/aws-website-mockserver----azamg/?region=us-east-1) | 5-2.mock-server.com
[pknro](https://s3.console.aws.amazon.com/s3/buckets/aws-website-mockserver----pknro/?region=us-east-1) | 5-1.mock-server.com
[8hyll](https://s3.console.aws.amazon.com/s3/buckets/aws-website-mockserver--8hyll/?region=us-east-1) | 5-0.mock-server.com
[mp81c](https://s3.console.aws.amazon.com/s3/buckets/aws-website-mockserver--mp81c/?region=us-east-1) | 4-0.mock-server.com
[r4wey](https://s3.console.aws.amazon.com/s3/buckets/aws-website-mockserver--r4wey/?region=us-east-1) | 4-1.mock-server.com
