package org.mockserver.matchers;

/**
 * @author jamesdbloom
 */
public abstract class BodyMatcher<MatchedType> extends NotMatcher<MatchedType> {

}
