MockServer Example
==================

This project includes a simple web site and service with example tests showing how to use MockServer for mocking and proxying requests.

For information on how to use the MockServer please see http://www.mock-server.com/