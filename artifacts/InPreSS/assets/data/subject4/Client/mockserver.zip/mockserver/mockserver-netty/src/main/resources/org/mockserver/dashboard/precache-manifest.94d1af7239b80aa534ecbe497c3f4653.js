self.__precacheManifest = [
  {
    "revision": "f9342069a89e4d4b67af",
    "url": "/mockserver/dashboard/static/js/runtime~main.f9342069.js"
  },
  {
    "revision": "411a4d36c81a0ad7c628",
    "url": "/mockserver/dashboard/static/js/main.411a4d36.chunk.js"
  },
  {
    "revision": "66a8a6fc99239e52e608",
    "url": "/mockserver/dashboard/static/js/1.66a8a6fc.chunk.js"
  },
  {
    "revision": "411a4d36c81a0ad7c628",
    "url": "/mockserver/dashboard/static/css/main.1cec58b8.chunk.css"
  },
  {
    "revision": "20f80933885cd894a5ee8b94304e4949",
    "url": "/mockserver/dashboard/index.html"
  }
];