package org.mockserver.character;

/**
 * @author jamesdbloom
 */
public class Character {

    public static final String NEW_LINE = System.getProperty("line.separator");
}
